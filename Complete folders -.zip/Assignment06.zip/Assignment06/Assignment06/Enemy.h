#pragma once
#include "Unit.h"

class Enemy : public Unit
{
private:
    int aggro_X;
    int aggro_Y;
public:
    Enemy();
    ~Enemy();
};
