#pragma once
#include "Enemy.h"

class EnemyTwo : public Enemy
{
public:
    EnemyTwo();
    ~EnemyTwo();
};
