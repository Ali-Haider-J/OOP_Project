#pragma once
#include "Object.h"

class MediKit : public Object
{
public:
    MediKit();
    ~MediKit();
    void healthUp();
};
