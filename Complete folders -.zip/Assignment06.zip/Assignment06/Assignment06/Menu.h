#pragma once
#include "Object.h"

class Menu : public Object
{
private:
    bool pause;
public:
    Menu();
    ~Menu();
    bool newGame();
    bool instructions();
    bool quit();
    bool load();
    bool gameOver();
};
