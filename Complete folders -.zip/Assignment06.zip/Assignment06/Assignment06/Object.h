#pragma once

class Object
{
private:
    int x;
    int y;
    int hitbox_X;
    int hitbox_Y;
    float speedX;
    float speedY;
    bool solid;
public:
    Object();
    ~Object();
    virtual void draw() = 0;
};
