#pragma once
#include "Unit.h"

class Player : public Unit
{
private:
    Player instance;
    bool active;
    int stamina;
    Player();
public:
    ~Player();
    Player getInstance();
    void getInput();
    void displayUI();
    void dash();
};
