#pragma once
#include "Object.h"

class Room : public Object
{
private:
    int roomNo;
public:
    Room();
    ~Room();
};
