#pragma once
#include "Object.h"

class Save : public Object
{
public:
    Save();
    ~Save();
    void save();
};
