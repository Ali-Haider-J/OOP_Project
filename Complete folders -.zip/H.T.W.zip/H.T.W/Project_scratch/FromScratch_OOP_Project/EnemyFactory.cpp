#include "EnemyFactory.h"

EnemyFactory::EnemyFactory()
{

}


EnemyFactory::~EnemyFactory()
{


}

Enemy* EnemyFactory::getEnemy(std::string type)
{
    if (type == "EnemyOne")
    {
        enemy = new EnemyOne();
        return enemy;
    }

    else if (type == "EnemyTwo")
    {
        enemy = new EnemyOne();
        return new EnemyTwo();
    }
    else if (type == "EnemyThree")
    {
        enemy = new EnemyOne();
        return new EnemyThree();
    }

    return NULL;
}
