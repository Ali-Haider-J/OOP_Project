#pragma once
#include "Enemy.h"

class EnemyOne : public Enemy
{
public:
    EnemyOne();
    ~EnemyOne();
    void draw();
    void Update(long int frame, SDL_Rect tempRect);

};
