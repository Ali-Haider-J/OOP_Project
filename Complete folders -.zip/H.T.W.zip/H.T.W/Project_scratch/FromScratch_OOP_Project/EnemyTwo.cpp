#include "EnemyTwo.h"

EnemyTwo::EnemyTwo()
{
    std::cout << "EnemyTwo spawned!" << std::endl;


}

void EnemyTwo::draw()
{

}

void EnemyTwo::Update()
{

}
