#pragma once
#include "Unit.h"

class Player : public Unit
{
private:
    static Player* instance;
    bool active;
    int stamina;
    Player(const char* textureSheet, int x, int y);
    bool rightMov = false;
    bool upMov = false;
    bool leftMov = false;
    bool idle = true;
    bool downMov = false;
    char lastMov;

    enum ANIMATION_FRAMES {FLYING_FRAMES = 12};
    SDL_Rect spriteClips[ FLYING_FRAMES ];
    SDL_Rect spriteClips_down[ FLYING_FRAMES ];
    SDL_Rect spriteClips_right[ FLYING_FRAMES ];
    SDL_Rect spriteClips_left[ FLYING_FRAMES ];

    SDL_Rect spriteClips_idle_up[ FLYING_FRAMES ];
    SDL_Rect spriteClips_idle_down[ FLYING_FRAMES ];
    SDL_Rect spriteClips_idle_right[ FLYING_FRAMES ];
    SDL_Rect spriteClips_idle_left[ FLYING_FRAMES ];

public:

    void hitWall(bool, bool, bool, bool);
    void setRightMov(bool right);
    void setLeftMov(bool left);
    void setDownMov(bool down);
    void setUpMov(bool up);
    bool getIdle();
    void setIdle(bool idle);
    SDL_Rect camera();
    ~Player();
    static Player* getInstance();
    void draw();
    void Update(long int frame, SDL_Rect tempRect);
    void attack();


    void move();
    void getInput();
    void displayUI();
    void dash();
};
