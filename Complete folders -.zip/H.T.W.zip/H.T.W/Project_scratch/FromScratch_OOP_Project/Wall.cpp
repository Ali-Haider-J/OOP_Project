#include "Wall.h"

Wall::Wall()
{
     x = 0;
     y = 0;

     wallTex =  TextureManager::LoadTexture("Images/1.png");
     hitU = false;
     hitL = false;
     hitD = false;
     hitR = false;
}


Wall::~Wall()
{


}


void Wall::draw()
{

     SDL_RenderCopyEx(Game::renderer, wallTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);

}

void Wall::Update(long int frame, SDL_Rect tempRect)
{
    x = tempRect.x;
    y = tempRect.y;

    if (destRect.x >= 361)
    {
        hitL = true;
    }
    else if (destRect.x >= -575 & destRect.x <= -100 & destRect.y >= -1830)
    {
        hitL = true;
    }
    else
        hitL = false;


    if (destRect.y >= -1721 and destRect.x >= -100)
    {
        hitU = true;
    }
    else if (destRect.x <= -30 & destRect.y >= -1850 & destRect.x >= -555)
    {
        hitU = true;
    }
    else
    {
        hitU = false;
    }


    if (destRect.y < -2000)
    {
        hitD = true;
    }
    else
        hitD = false;

    if (destRect.x <= 9 & destRect.y >= -1830 & destRect.x >= -100)
    {
        hitR = true;
    }
    else if (destRect.x <= -1050)
        hitR = true;
    else
        hitR = false;


    srcRect.h = 250;
    srcRect.w = 45;
    srcRect.x = 0;
    srcRect.y = 0;
    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x = destRect.x + x;
    destRect.y = destRect.y + y;

    std::cout << "HitU is: " << hitU << std::endl;
    std::cout << "HitL is: " << hitL << std::endl;
    std::cout << "Wall x is:" << destRect.x << std::endl;

    std::cout << "Wall y is:" << destRect.y << std::endl;


   /* if (speedX == 0)
    {
        destRect.x = 20;
    }
    if (speedX == 0)
    {
        destRect.x = -20;
    }*/
    //destRect = camera(x, y, 2, speedX, speedY);
}
