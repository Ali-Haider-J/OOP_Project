#pragma once
#include "Unit.h"

class Enemy : protected Unit
{
protected:
    int aggro_X;
    int aggro_Y;
    SDL_Texture* enemyTex;

public:
    Enemy();
    ~Enemy();
    virtual void draw();
    virtual void Update(long int frame, SDL_Rect tempRect);
    virtual void attack();
    virtual void move();

};
