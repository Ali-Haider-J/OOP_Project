#include "EnemyThree.h"

EnemyThree::EnemyThree()
{
    std::cout << "EnemyThree spawned!" << std::endl;


}

void EnemyThree::draw()
{


}

void EnemyThree::Update()
{

}
