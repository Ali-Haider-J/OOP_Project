#pragma once
#include "Node.h"
#include "Object.h"

class Queue
{
private:
    static Queue instance;
    Node* head;
    Node* tail;
    Queue();
public:
    ~Queue();
    Queue getInstance();
    void Move();
    void Clean();
    void enqueue(Object*);
};
