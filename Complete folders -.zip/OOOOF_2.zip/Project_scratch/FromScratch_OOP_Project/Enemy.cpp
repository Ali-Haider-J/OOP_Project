#include "Enemy.h"

Enemy::Enemy()
{


}

Enemy::~Enemy()
{


}

void Enemy::draw()
{

}
void Enemy::Update(long int frame, SDL_Rect spriteClips_animation, int a, int b)
{
//    //SPAWN_ANIMATION
//    //frame 0
//    spriteClips_spawn_animation[0].x = 0;
//    spriteClips_spawn_animation[0].y = 787;
//    spriteClips_spawn_animation[0].w = 50;
//    spriteClips_spawn_animation[0].h = 42;
//
//    //frame 1
//    spriteClips_spawn_animation[1].x = 50;
//    spriteClips_spawn_animation[1].y = 787;
//    spriteClips_spawn_animation[1].w = 50;
//    spriteClips_spawn_animation[1].h = 42;
//
//    //frame 2
//    spriteClips_spawn_animation[2].x = 100;
//    spriteClips_spawn_animation[2].y = 787;
//    spriteClips_spawn_animation[2].w = 50;
//    spriteClips_spawn_animation[2].h = 42;
//
//    //frame 3
//    spriteClips_spawn_animation[3].x = 150;
//    spriteClips_spawn_animation[3].y = 787;
//    spriteClips_spawn_animation[3].w = 50;
//    spriteClips_spawn_animation[3].h = 42;
//
//    //frame 4
//    spriteClips_spawn_animation[4].x = 200;
//    spriteClips_spawn_animation[4].y = 787;
//    spriteClips_spawn_animation[4].w = 50;
//    spriteClips_spawn_animation[4].h = 42;
//
//    //frame 5
//    spriteClips_spawn_animation[5].x = 250;
//    spriteClips_spawn_animation[5].y = 787;
//    spriteClips_spawn_animation[5].w = 50;
//    spriteClips_spawn_animation[5].h = 42;
//
//    //frame 6
//    spriteClips_spawn_animation[6].x = 300;
//    spriteClips_spawn_animation[6].y = 787;
//    spriteClips_spawn_animation[6].w = 50;
//    spriteClips_spawn_animation[6].h = 42;
//
//    //frame 7
//    spriteClips_spawn_animation[7].x = 350;
//    spriteClips_spawn_animation[7].y = 787;
//    spriteClips_spawn_animation[7].w = 50;
//    spriteClips_spawn_animation[7].h = 42;
//
//    //frame 8
//    spriteClips_spawn_animation[8].x = 400;
//    spriteClips_spawn_animation[8].y = 787;
//    spriteClips_spawn_animation[8].w = 50;
//    spriteClips_spawn_animation[8].h = 42;
}

void Enemy::attack(int, int)
{

}
void Enemy::move()
{

}
