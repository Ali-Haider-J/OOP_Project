#include "Game.h"
#include "TextureManager.h"
#include "Player.h"
#include "Room.h"
#include "EnemyFactory.h"
#include "Wall.h"

//Object* objPlayer;
Player* player;
Player* Player::instance = NULL;
//Room* room = NULL;
EnemyFactory* enemyFactory = NULL;
Enemy* enemy = NULL;
Object* objEnemy = NULL;
Object* objRoom = NULL;
Object* objWall = NULL;
SDL_Event e;
long int frame = 0;
SDL_Renderer* Game::renderer = NULL;


Game::Game()
{

}
Game::~Game()
{


}

void Game::init(const char* title, int xpos, int ypos, int width, int height, bool fullscreen)
{
    int flags = 0;

    if (fullscreen)
    {
        flags =  SDL_WINDOW_FULLSCREEN;
    }

    if ( SDL_Init(SDL_INIT_EVERYTHING) == 0 )
    {
        std::cout << "Subsystems initialized!" << std::endl;
        window = SDL_CreateWindow( title, xpos, ypos, width, height, fullscreen );
        {
            std::cout << "Window created!" << std::endl;
        }
        renderer = SDL_CreateRenderer(window, -1, 0);
        if (renderer)
        {
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            std::cout << "Renderer created!" << std::endl;

        }
        isRunning = true;
    }

    else
    {
        isRunning = false;
    }


   player = Player::getInstance();
   objRoom = new Room();
   enemyFactory = new EnemyFactory();

   objWall = new Wall();
  // enemy = enemyFactory->getEnemy("EnemyOne", -160, -1800);
    enemy = new EnemyOne(60, 2020);
}

void Game::handleEvents()
{

    SDL_RenderPresent(renderer);
    SDL_Event event;
    SDL_PollEvent(&event);

    player->setIdle(true);
    player->setRightMov(false);
    player->setLeftMov(false);
    player->setUpMov(false);
    player->setDownMov(false);

    while( SDL_PollEvent( &e ) != 0 )   //Handle events on queue
    {
        //User requests quit
        if( e.type == SDL_QUIT )
        {
            isRunning = false;
        }


    }
    const Uint8* currentKeyStates = SDL_GetKeyboardState( NULL );

        if(currentKeyStates[ SDL_SCANCODE_RIGHT ])
        {
            player->setIdle(false);

            player->setRightMov(true);
            player->setDownMov(false);
            player->setUpMov(false);
            player->setLeftMov(false);

        }

        if(currentKeyStates[ SDL_SCANCODE_LEFT ])
        {
            player->setIdle(false);

            player->setLeftMov(true);
            player->setDownMov(false);
            player->setRightMov(false);
            player->setUpMov(false);


        }

        if(currentKeyStates[ SDL_SCANCODE_UP ])
        {
            //plane->downRight = true;
            player->setIdle(false);

            player->setUpMov(true);
            player->setDownMov(false);
            player->setLeftMov(false);
            player->setRightMov(false);
            //cout << plane->up << endl;

        }

        if(currentKeyStates[ SDL_SCANCODE_DOWN ])
        {
            //plane->upLeft = true;
            player->setIdle(false);
            player->setDownMov(true);
            player->setLeftMov(false);
            player->setUpMov(false);
            player->setRightMov(false);
            //cout << plane->up << endl;

        }

        if(currentKeyStates[ SDL_SCANCODE_UP ] & currentKeyStates[ SDL_SCANCODE_RIGHT ])
        {
            //plane->upLeft = true;
            player->setIdle(false);

            player->setLeftMov(false);
            player->setUpMov(true);
            player->setRightMov(true);
            player->setDownMov(false);
            //cout << plane->up << endl;

        }
        if(currentKeyStates[ SDL_SCANCODE_UP ] & currentKeyStates[ SDL_SCANCODE_LEFT ])
        {
            //plane->upLeft = true;
            player->setIdle(false);

            player->setLeftMov(true);
            player->setUpMov(true);
            player->setRightMov(false);
            player->setDownMov(false);
            //cout << plane->up << endl;

        }
        if(currentKeyStates[ SDL_SCANCODE_DOWN ] & currentKeyStates[ SDL_SCANCODE_LEFT ])
        {
            //plane->upLeft = true;
            player->setIdle(false);
            player->setDownMov(true);
            player->setLeftMov(true);
            player->setUpMov(false);
            player->setRightMov(false);
            //cout << plane->up << endl;

        }
        if(currentKeyStates[ SDL_SCANCODE_DOWN ] & currentKeyStates[ SDL_SCANCODE_RIGHT ])
        {
            //plane->upLeft = true;
            player->setIdle(false);
            player->setDownMov(true);
            player->setLeftMov(false);
            player->setUpMov(false);
            player->setRightMov(true);
            //cout << plane->up << endl;

        }

}

void Game::update()
{

    SDL_RenderPresent(renderer);

    SDL_Rect tempRect;
    tempRect = player->camera();
        objWall->Update(frame, tempRect, player->newX, player->newY);
                player->hitWall(objWall->hitL, objWall->hitU, objWall->hitR, objWall->hitD);
    player->Update(frame, tempRect,  player->newX, player->newY);
    objRoom->Update(frame, tempRect, player->newX, player->newY);
    SDL_Rect forPlayer;
    forPlayer.x = player->getX();
    forPlayer.y = player->getY();
    forPlayer.h = 2;
    enemy->Update(frame, tempRect, player->getX(), player->getY());
    frame++;
}

void Game::render()
{
    SDL_RenderClear(renderer);
    objRoom->draw();
    player->draw();
    objWall->draw();
    enemy->draw();
}

void Game::clean()
{
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
    SDL_Quit();
    std::cout << "Game cleaned" << std::endl;
}

Game* Game::getInstance()
{
    if (instance == NULL)
        instance = new Game();
    return instance;
}

