#include "Save.h"

Save::Save()
{

}

Save::~Save()
{

}

void Save::save()
{

}

void Save::draw()
{

}
void Save::Update()
{
//ANIMATION
//frame 0
spriteClips_animation[0].x = 63;
spriteClips_animation[0].y = 1184;
spriteClips_animation[0].w = 16;
spriteClips_animation[0].h = 13;

//frame 1
spriteClips_animation[1].x = 79;
spriteClips_animation[1].y = 1184;
spriteClips_animation[1].w = 16;
spriteClips_animation[1].h = 13;

//frame 2
spriteClips_animation[2].x = 95;
spriteClips_animation[2].y = 1184;
spriteClips_animation[2].w = 16;
spriteClips_animation[2].h = 13;

//frame 3
spriteClips_animation[3].x = 111;
spriteClips_animation[3].y = 1184;
spriteClips_animation[3].w = 16;
spriteClips_animation[3].h = 13;

//frame 4
spriteClips_animation[4].x = 127;
spriteClips_animation[4].y = 1184;
spriteClips_animation[4].w = 16;
spriteClips_animation[4].h = 13;

//frame 5
spriteClips_animation[5].x = 143;
spriteClips_animation[5].y = 1184;
spriteClips_animation[5].w = 16;
spriteClips_animation[5].h = 13;

//frame 6
spriteClips_animation[6].x = 63;
spriteClips_animation[6].y = 1197;
spriteClips_animation[6].w = 16;
spriteClips_animation[6].h = 13;

//frame 7
spriteClips_animation[7].x = 79;
spriteClips_animation[7].y = 1197;
spriteClips_animation[7].w = 16;
spriteClips_animation[7].h = 13;

//frame 8
spriteClips_animation[8].x = 95;
spriteClips_animation[8].y = 1197;
spriteClips_animation[8].w = 16;
spriteClips_animation[8].h = 13;

//frame 9
spriteClips_animation[9].x = 111;
spriteClips_animation[9].y = 1197;
spriteClips_animation[9].w = 16;
spriteClips_animation[9].h = 13;

//frame 10
spriteClips_animation[10].x = 127;
spriteClips_animation[10].y = 1197;
spriteClips_animation[10].w = 16;
spriteClips_animation[10].h = 13;

//frame 11
spriteClips_animation[11].x = 143;
spriteClips_animation[11].y = 1197;
spriteClips_animation[11].w = 16;
spriteClips_animation[11].h = 13;

//frame 12
spriteClips_animation[12].x = 127;
spriteClips_animation[12].y = 1197;
spriteClips_animation[12].w = 16;
spriteClips_animation[12].h = 13;

//frame 13
spriteClips_animation[13].x = 111;
spriteClips_animation[13].y = 1197;
spriteClips_animation[13].w = 16;
spriteClips_animation[13].h = 13;

//frame 14
spriteClips_animation[14].x = 95;
spriteClips_animation[14].y = 1197;
spriteClips_animation[14].w = 16;
spriteClips_animation[14].h = 13;

//frame 15
spriteClips_animation[15].x = 79;
spriteClips_animation[15].y = 1197;
spriteClips_animation[15].w = 16;
spriteClips_animation[15].h = 13;

//frame 16
spriteClips_animation[16].x = 63;
spriteClips_animation[16].y = 1197;
spriteClips_animation[16].w = 16;
spriteClips_animation[16].h = 13;

//frame 17
spriteClips_animation[17].x = 143;
spriteClips_animation[17].y = 1184;
spriteClips_animation[17].w = 16;
spriteClips_animation[17].h = 13;

//frame 18
spriteClips_animation[18].x = 127;
spriteClips_animation[18].y = 1184;
spriteClips_animation[18].w = 16;
spriteClips_animation[18].h = 13;

//frame 19
spriteClips_animation[19].x = 111;
spriteClips_animation[19].y = 1184;
spriteClips_animation[19].w = 16;
spriteClips_animation[19].h = 13;

//frame 20
spriteClips_animation[20].x = 95;
spriteClips_animation[20].y = 1184;
spriteClips_animation[20].w = 16;
spriteClips_animation[20].h = 13;

//frame 21
spriteClips_animation[21].x = 79;
spriteClips_animation[21].y = 1184;
spriteClips_animation[21].w = 16;
spriteClips_animation[21].h = 13;
}
