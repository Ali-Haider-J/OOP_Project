#pragma once
#include "Unit.h"

class Player : public Unit
{
private:
    float speedX;
    float speedY;
    float speedD;
    int playerX;
    int playerY;
    static Player* instance;
    bool active;
    int stamina;
    Player(const char* textureSheet, int x, int y);
    bool rightMov = false;
    bool upMov = false;
    bool leftMov = false;
    bool idle = true;
    bool downMov = false;
    bool attacking = false;
    char lastMov;
    SDL_Rect hitbox;

    enum ANIMATION_FRAMES {FLYING_FRAMES = 12};
    SDL_Rect spriteClips[ FLYING_FRAMES ];
    SDL_Rect spriteClips_down[ FLYING_FRAMES ];
    SDL_Rect spriteClips_right[ FLYING_FRAMES ];
    SDL_Rect spriteClips_left[ FLYING_FRAMES ];

    SDL_Rect spriteClips_idle_up[ 1 ];
    SDL_Rect spriteClips_idle_down[ 1 ];
    SDL_Rect spriteClips_idle_right[ 1 ];
    SDL_Rect spriteClips_idle_left[ 1 ];

    SDL_Rect spriteClips_attack_right[7];
    SDL_Rect spriteClips_attack_right_alt[6];
    SDL_Rect spriteClips_attack_left[7];
    SDL_Rect spriteClips_attack_left_alt[6];
    SDL_Rect spriteClips_attack_up[7];
    SDL_Rect spriteClips_attack_up_alt[7];
    SDL_Rect spriteClips_attack_down[7];
    SDL_Rect spriteClips_attack_down_alt[7];

    SDL_Rect spriteClips_dodge_right[8];
    SDL_Rect spriteClips_dodge_left[8];
    SDL_Rect spriteClips_dodge_down[8];
    SDL_Rect spriteClips_dodge_up[8];

    SDL_Rect spriteClips_get_hit_right[4];
    SDL_Rect spriteClips_get_hit_left[4];

    SDL_Rect spriteClips_death[10];

public:
 int newX;
    int newY;
    void setX(float);
    void setY(float);
    int getX();
    int getY();
    void hitWall(bool, bool, bool, bool);
    void setRightMov(bool right);
    void setLeftMov(bool left);
    void setDownMov(bool down);
    void setUpMov(bool up);
    void setAttack(bool attack);
    bool getIdle();
    void setIdle(bool idle);
    SDL_Rect camera();
    ~Player();
    static Player* getInstance();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int);
    void attack(int, int);


    void move();
    void getInput();
    void displayUI();
    void dash();
};
