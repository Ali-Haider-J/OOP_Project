#pragma once
#include "Unit.h"

class Enemy : protected Unit
{
protected:
//    int aggro_X;
//    int aggro_Y;
//    SDL_Texture* enemyTex;
//    SDL_Rect spriteClips_spawn_animation[9];

public:
    Enemy();
    ~Enemy();
    virtual void draw() = 0;
    virtual void Update(long int frame, SDL_Rect tempRect, int, int) = 0;
    virtual void attack(int, int) = 0;
    void move() ;

};
