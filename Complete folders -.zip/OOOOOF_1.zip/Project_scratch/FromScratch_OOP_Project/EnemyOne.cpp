#include "EnemyOne.h"

EnemyOne::EnemyOne(int posx, int posy)
{
//    this->newX = this->newY = 0;
    enemyX = posx;
    enemyX = posy;
    destRect.x = destRect.y = 0;
    attack_state = 0;
    EnemyOneTex =  TextureManager::LoadTexture("Images/main_ss.png");
}


EnemyOne::~EnemyOne()
{


}


void EnemyOne::draw()
{
     SDL_RenderCopyEx(Game::renderer, EnemyOneTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);
}

void EnemyOne::Update(long int frame, SDL_Rect tempRect, int xpos, int ypos)
{


    std::cout << "enemyX      " << enemyX << std::endl;
    {
    //SPAWN_ANIMATION
    //frame 0
    spriteClips_spawn_animation[0].x = 0;
    spriteClips_spawn_animation[0].y = 787;
    spriteClips_spawn_animation[0].w = 50;
    spriteClips_spawn_animation[0].h = 42;

    //frame 1
    spriteClips_spawn_animation[1].x = 50;
    spriteClips_spawn_animation[1].y = 787;
    spriteClips_spawn_animation[1].w = 50;
    spriteClips_spawn_animation[1].h = 42;

    //frame 2
    spriteClips_spawn_animation[2].x = 100;
    spriteClips_spawn_animation[2].y = 787;
    spriteClips_spawn_animation[2].w = 50;
    spriteClips_spawn_animation[2].h = 42;

    //frame 3
    spriteClips_spawn_animation[3].x = 150;
    spriteClips_spawn_animation[3].y = 787;
    spriteClips_spawn_animation[3].w = 50;
    spriteClips_spawn_animation[3].h = 42;

    //frame 4
    spriteClips_spawn_animation[4].x = 200;
    spriteClips_spawn_animation[4].y = 787;
    spriteClips_spawn_animation[4].w = 50;
    spriteClips_spawn_animation[4].h = 42;

    //frame 5
    spriteClips_spawn_animation[5].x = 250;
    spriteClips_spawn_animation[5].y = 787;
    spriteClips_spawn_animation[5].w = 50;
    spriteClips_spawn_animation[5].h = 42;

    //frame 6
    spriteClips_spawn_animation[6].x = 300;
    spriteClips_spawn_animation[6].y = 787;
    spriteClips_spawn_animation[6].w = 50;
    spriteClips_spawn_animation[6].h = 42;

    //frame 7
    spriteClips_spawn_animation[7].x = 350;
    spriteClips_spawn_animation[7].y = 787;
    spriteClips_spawn_animation[7].w = 50;
    spriteClips_spawn_animation[7].h = 42;

    //frame 8
    spriteClips_spawn_animation[8].x = 400;
    spriteClips_spawn_animation[8].y = 787;
    spriteClips_spawn_animation[8].w = 50;
    spriteClips_spawn_animation[8].h = 42;
    }
    srcRect = spriteClips_spawn_animation[frame % 9];

    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x =  tempRect.x;
    destRect.y = tempRect.y + 2020;

//    this->newX += tempRect.x;
//    this->newY += tempRect.y;
//    this->x = tempRect.x;
//    this->y = tempRect.y;

    std::cout << "EnemyOne x is:" << tempRect.x << std::endl;

    std::cout << "EnemyOne y is:" << tempRect.y << std::endl;

    std::cout << "EnemyOne attack_state is:" << attack_state << std::endl;

    if (frame % 8 == 0)
    {
        attack_state++;
    }
    if (attack_state == 5)
    {
        attack(xpos,ypos);
    }
}

void EnemyOne::attack(int targetX, int targetY)
{
    std::cout << "------------------------------------------Enemy X is : " << targetX << std::endl;

    std::cout << "---------------------------------Enemy Y is : " << targetY << std::endl;
    this->enemyX += 0;//(24 * ((targetX - newX) / ((targetX - newX) + (targetY - newY))));
    this->enemyY -= 0;//targetY*0.04;//(24 * ((targetY - newY) / ((targetX - newX) + (targetY - newY))));
    attack_state = 0;
}
