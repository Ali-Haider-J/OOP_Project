#include "Enemy.h"

Enemy::Enemy()
{


}

Enemy::~Enemy()
{


}

void Enemy::draw()
{


}
void Enemy::Update(long int frame, SDL_Rect tempRect)
{

}

void Enemy::attack()
{

}
void Enemy::move()
{

}

