#include "EnemyOne.h"

EnemyOne::EnemyOne()
{
    std::cout << "EnemyOne spawned!" << std::endl;
    enemyTex =  TextureManager::LoadTexture("Images/spritesheet_new_no_BG.png");
    x = 0;
    y = 0;
}

EnemyOne::~EnemyOne()
{

}

void EnemyOne::draw()
{
    SDL_RenderCopyEx(Game::renderer, enemyTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);
}

void EnemyOne::Update(long int frame, SDL_Rect tempRect)
{
    srcRect.h = 25;
    srcRect.w = 25;
    srcRect.x = 0;
    srcRect.y = 66;
    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x =  500;
    destRect.y =  500;
}



void EnemyOne::setUpMov(bool up)
{

}
void EnemyOne::setDownMov(bool down)
{

}
