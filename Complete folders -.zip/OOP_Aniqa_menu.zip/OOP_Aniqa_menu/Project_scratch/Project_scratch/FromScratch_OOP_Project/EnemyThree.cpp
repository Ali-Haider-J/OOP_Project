#include "EnemyThree.h"

EnemyThree::EnemyThree()
{
    std::cout << "EnemyThree spawned!" << std::endl;


}

void EnemyThree::draw()
{


}

void EnemyThree::Update()
{

}


void EnemyThree::setUpMov(bool up)
{

}
void EnemyThree::setDownMov(bool down)
{

}
