#include "EnemyTwo.h"

EnemyTwo::EnemyTwo()
{
    std::cout << "EnemyTwo spawned!" << std::endl;


}

void EnemyTwo::draw()
{

}

void EnemyTwo::Update()
{

}

void EnemyTwo::setUpMov(bool up)
{

}
void EnemyTwo::setDownMov(bool down)
{

}
