#include "Game.h"
#include "TextureManager.h"
#include "Player.h"
#include "Room.h"
#include "EnemyFactory.h"
#include "Wall.h"
#include "Queue.h"
#include "Button.h"
//Object* objPlayer;
Player* player;
Queue* MainQueue;
Player* Player::instance = NULL;
Queue* Queue::instance = NULL;
//Room* room = NULL;
EnemyFactory* enemyFactory = NULL;
//Enemy* enemy = NULL;
Object* objEnemy = NULL;
Object* objRoom = NULL;
Object* objWall = NULL;
Object* objButton = NULL;
Object* objButton2 = NULL;
Object* objButton3 = NULL;
Object* objButton4 = NULL;
Object* objButtonHover = NULL;

SDL_Event e;
long int frame = 0;
SDL_Renderer* Game::renderer = NULL;


Game::Game()
{

}
Game::~Game()
{


}

void Game::init(const char* title, int xpos, int ypos, int width, int height, bool fullscreen)
{
    int flags = 0;

    if (fullscreen)
    {
        flags =  SDL_WINDOW_FULLSCREEN;
    }

    if ( SDL_Init(SDL_INIT_EVERYTHING) == 0 )
    {
        std::cout << "Subsystems initialized!" << std::endl;
        window = SDL_CreateWindow( title, xpos, ypos, width, height, fullscreen );
        {
            std::cout << "Window created!" << std::endl;
        }
        renderer = SDL_CreateRenderer(window, -1, 0);
        if (renderer)
        {
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            std::cout << "Renderer created!" << std::endl;

        }
        isRunning = true;
    }

    else
    {
        isRunning = false;
    }

   objRoom = new Room();
   enemyFactory = new EnemyFactory();

   objWall = new Wall();
   objButton = new Button(0,(1024/2)-100,(768/2)-60);
   objButton2 = new Button(1,(1024/2)-100,768/2);
   objButton3 = new Button(2,(1024/2)-100,(768/2)+60);
   objButton4 = new Button(3,(1024/2)-100,(768/2)+120);
   objButtonHover = new Button (4,(1024/2)-150,(768/2)-90);


   player = Player::getInstance();
   MainQueue = Queue::getInstance();


   MainQueue->Enqueue(objButton);
   MainQueue->Enqueue(objButton2);
   MainQueue->Enqueue(objButton3);
   MainQueue->Enqueue(objButton4);
   MainQueue->Enqueue(objButtonHover);
   //objRoom = new Room();

   //enemy = enemyFactory->getEnemy("EnemyOne");

}

void Game::handleEvents()
{

    SDL_RenderPresent(renderer);
    SDL_Event event;
    SDL_PollEvent(&event);

    player->setIdle(true);
    player->setRightMov(false);
    player->setLeftMov(false);
    player->setUpMov(false);
    player->setDownMov(false);
    objButtonHover->setUpMov(false);
    objButtonHover->setDownMov(false);


    while( SDL_PollEvent( &e ) != 0 )   //Handle events on queue
    {
        //User requests quit
        if( e.type == SDL_QUIT )
        {
            isRunning = false;
        }



    }
    const Uint8* currentKeyStates = SDL_GetKeyboardState( NULL );

        if(currentKeyStates[ SDL_SCANCODE_RIGHT ])
        {
            player->setIdle(false);

            player->setRightMov(true);
            player->setDownMov(false);
            player->setUpMov(false);
            player->setLeftMov(false);

        }

        if(currentKeyStates[ SDL_SCANCODE_LEFT ])
        {
            player->setIdle(false);

            player->setLeftMov(true);
            player->setDownMov(false);
            player->setRightMov(false);
            player->setUpMov(false);


        }

        if(currentKeyStates[ SDL_SCANCODE_UP ])
        {
            //plane->downRight = true;
            player->setIdle(false);

            player->setUpMov(true);
            player->setDownMov(false);
            player->setLeftMov(false);
            player->setRightMov(false);
            //cout << plane->up << endl;
            objButtonHover->setDownMov(false);
            objButtonHover->setUpMov(true);

        }

        if(currentKeyStates[ SDL_SCANCODE_DOWN ])
        {
            //plane->upLeft = true;
            player->setIdle(false);
            player->setDownMov(true);
            player->setLeftMov(false);
            player->setUpMov(false);
            player->setRightMov(false);
            //cout << plane->up << endl;
            objButtonHover->setUpMov(false);
            objButtonHover->setDownMov(true);

        }

        else if(currentKeyStates[ SDL_SCANCODE_UP ] & currentKeyStates[ SDL_SCANCODE_RIGHT ])
        {
            //plane->upLeft = true;
            player->setIdle(false);

            player->setLeftMov(false);
            player->setUpMov(true);
            player->setRightMov(true);
            player->setDownMov(false);
            //cout << plane->up << endl;
            //objButtonHover->setUpMov(true);

        }
        else if(currentKeyStates[ SDL_SCANCODE_UP ] & currentKeyStates[ SDL_SCANCODE_LEFT ])
        {
            //plane->upLeft = true;
            player->setIdle(false);

            player->setLeftMov(true);
            player->setUpMov(true);
            player->setRightMov(false);
            player->setDownMov(false);
            //cout << plane->up << endl;

        }
        else if(currentKeyStates[ SDL_SCANCODE_DOWN ] & currentKeyStates[ SDL_SCANCODE_LEFT ])
        {
            //plane->upLeft = true;
            player->setIdle(false);
            player->setDownMov(true);
            player->setLeftMov(true);
            player->setUpMov(false);
            player->setRightMov(false);
            //cout << plane->up << endl;

        }
        else if(currentKeyStates[ SDL_SCANCODE_DOWN ] & currentKeyStates[ SDL_SCANCODE_RIGHT ])
        {
            //plane->upLeft = true;
            player->setIdle(false);
            player->setDownMov(true);
            player->setLeftMov(false);
            player->setUpMov(false);
            player->setRightMov(true);
            //cout << plane->up << endl;

        }

}

void Game::update()
{

    SDL_RenderPresent(renderer);
    SDL_Rect tempRect;



    tempRect = player->camera();

        //objWall->Update(frame, tempRect);
    //player->hitWall(objWall->hit);
    //player->Update(frame, tempRect);

    MainQueue->Move(frame, tempRect);

    //objRoom->Update(frame, tempRect);

    //objButton->Update(frame, tempRect);
    //player->Update(frame, tempRect);


    //enemy->Update(frame, tempRect);
    frame++;
}

void Game::render()
{
    SDL_RenderClear(renderer);
  //objRoom->draw();

    //objWall->draw();
    //objButton->draw();
    MainQueue->Draw();
    //player->draw();

    //enemy->draw();
}

void Game::clean()
{
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
    SDL_Quit();
    std::cout << "Game cleaned" << std::endl;
}

Game* Game::getInstance()
{
    if (instance == NULL)
        instance = new Game();
    return instance;
}

