
#pragma once
#include "Menu.h"
/*
class Menu : public Object
{
private:
    bool pause;

Menu::Menu()
{

}
Menu::~Menu()
{

}
void Menu::draw()
{

}
    void Update();
    bool newGame();
    bool instructions();
    bool quit();
    bool load();
    bool gameOver();
};
*/
