#pragma once
#include "SDL.h"

class Object
{
protected:
    float x;
    float y;
    float hitbox_X;
    float hitbox_Y;
    float speedX;
    float speedY;
    bool solidX;
    bool solidY;
    bool solidL;
    bool solidD;
    SDL_Texture* objTexture;
    SDL_Rect srcRect, destRect;

public:
    bool near;
    bool hit;
    //bool getSolid();
    Object();
    ~Object();
    float getX();
    float getY();
    void setSpeedX(float x);
    void setSpeedY(float y);
    float getSpeedX();
    float getSpeedY();
    void setX(float x);
    void setY(float y);
    //SDL_Rect camera(int x, int y, int zoom, int speedx, int speedy);
    virtual void draw() = 0;
    virtual void setDownMov(bool)=0;
    virtual void setUpMov(bool)=0;


    virtual void Update(long int frame, SDL_Rect tempRect) = 0;


};
