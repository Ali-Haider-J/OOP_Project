#pragma once
#include "Enemy.h"
#include "EnemyOne.h"
#include "EnemyTwo.h"
#include "EnemyThree.h"

class EnemyFactory
{
private:
    Enemy* enemy;
public:
    EnemyFactory();
    ~EnemyFactory();
    Enemy* getEnemy(std::string);
};
