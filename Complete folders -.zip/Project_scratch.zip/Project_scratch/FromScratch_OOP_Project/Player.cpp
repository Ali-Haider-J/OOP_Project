#include "Player.h"

using namespace std;

Player::Player(const char* textureSheet, int x, int y)
{
    lastMov = 'D';
    upMov = false;
    downMov = true;
    rightMov = false;
    leftMov = false;

    objTexture = TextureManager::LoadTexture(textureSheet);
    this->x = x;
    this->y = y;
    speedX = 6;
    speedY = 6;


}


void Player::hitWall()
{
    cout << "speedX si"  << speedX << endl;
    if (x <= -210)
    {
        x = -210;
        cout << "X is true" << endl;
        solidX = true;
    }
    else
        solidX = false;
    if (y <= -86)// and x <= 190)
    {
        y = -86;
         cout << "Y is true" << endl;
        solidY = true;
    }
    else
        solidY = false;
    if (x >= 138)
    {
        x = 138;
        cout << "L is true" << endl;
        solidL = true;
    }
    else
        solidL = false;
    if (y >= 216)
    {
        y = 216;
         cout << "D is true" << endl;
        solidD = true;
    }
    else
        solidD = false;
}

void Player::Update(long int frame, SDL_Rect tempRect)
{

    x += tempRect.x;
    y -= tempRect.y;


        if (rightMov & upMov)
        {
//            if (speedX >= 450)
//            {
//                speedX = 450;
//                speedY += 8.4853;
//            }
//            else
            {
                x += speedX;
                y += speedY;
            }

        }
        else if (leftMov & upMov)
        {
//            if (speedX <= -450)
//            {
//                speedX = -450;
//                speedY += 8.4853;
//            }
//            else
            {
                x -= speedX;
                y += speedY;
            }

        }
        else if (rightMov & downMov)
        {
//            if (speedX >= 450)
//            {
//                speedX = 450;
//                speedY -= 8.4853;
//            }
//            else
            {
                x += speedX;
                y -= speedY;
            }

        }
        else if (leftMov & downMov)
        {

//            if (speedX >= 450)
//            {
//                speedX = 450;
//                speedY -= 8.4853;
//            }
//            else
            {
                x -= speedX;
                y -= speedY;
            }

        }

        else if (rightMov)
        {
//            if (speedX >= 450)
//            {
//                speedX = 450;
//            }
//            else
            {
                x += speedX;//10;
            }

        }

        else if (leftMov)
        {
//            if (speedX <= -450)
//            {
//                speedX = -450;
//            }
//            else
            {
                x -= speedX;//-10;

            }
        }

        else if (upMov)
        {
//            if ( speedY >= 350)
//            {
//               speedY = 362;
//            }
//            else
            {
                y += speedY;//-10;
            }
        }
        else if (downMov)
        {
//            if ( speedY < -300)
//            {
//               speedY = -318;
//            }
//            else
            {
                y -= speedY;//-10;
            }
        }

        {
        //UP movement
        //Frame 0
        spriteClips[ 0 ].x =  2;
        spriteClips[ 0 ].y =  0;
        spriteClips[ 0 ].w = 17;
        spriteClips[ 0 ].h = 31;

        //Frame 1
        spriteClips[ 1 ].x =  24;
        spriteClips[ 1 ].y =  0;
        spriteClips[ 1 ].w = 17;
        spriteClips[ 1 ].h = 31;

        //Frame 2
        spriteClips[ 2 ].x = 46;
        spriteClips[ 2 ].y =  0;
        spriteClips[ 2 ].w = 17;
        spriteClips[ 2 ].h = 31;

        //Frame 3
        spriteClips[ 3 ].x = 68;
        spriteClips[ 3 ].y =  0;
        spriteClips[ 3 ].w = 17;
        spriteClips[ 3 ].h = 31;

        //Frame 4
        spriteClips[ 4 ].x = 90;
        spriteClips[ 4 ].y = 0;
        spriteClips[ 4 ].w = 17;
        spriteClips[ 4 ].h = 31;

        //Frame 5
        spriteClips[ 5 ].x = 112;
        spriteClips[ 5 ].y = 0;
        spriteClips[ 5 ].w = 17;
        spriteClips[ 5 ].h = 31;

        //Frame 6
        spriteClips[ 6 ].x = 134;
        spriteClips[ 6 ].y = 0;
        spriteClips[ 6 ].w = 17 ;
        spriteClips[ 6 ].h = 31;


        //Frame 7
        spriteClips[ 7 ].x = 156;
        spriteClips[ 7 ].y = 0;
        spriteClips[ 7 ].w = 17;
        spriteClips[ 7 ].h = 31;

        //Frame 8
        spriteClips[ 8 ].x = 178;
        spriteClips[ 8 ].y = 0;
        spriteClips[ 8 ].w = 17;
        spriteClips[ 8 ].h = 31;

        //Frame 9
        spriteClips[ 9 ].x = 200;
        spriteClips[ 9 ].y = 0;
        spriteClips[ 9 ].w = 17;
        spriteClips[ 9 ].h = 31;

        //Frame 10
        spriteClips[ 10 ].x = 222;
        spriteClips[ 10 ].y = 0;
        spriteClips[ 10 ].w = 17;
        spriteClips[ 10 ].h = 31;

        //Frame 11
        spriteClips[ 11 ].x = 244;
        spriteClips[ 11 ].y =  0;
        spriteClips[ 11 ].w = 17;
        spriteClips[ 11 ].h = 31;

        //DOWN movement
        //Frame 0
        spriteClips_down[ 0 ].x =   2;
        spriteClips_down[ 0 ].y =  36;
        spriteClips_down[ 0 ].w = 19;
        spriteClips_down[ 0 ].h = 34;

        //Frame 1
        spriteClips_down[ 1 ].x =  26;
        spriteClips_down[ 1 ].y =  36;
        spriteClips_down[ 1 ].w = 19;
        spriteClips_down[ 1 ].h = 34;

        //Frame 2
        spriteClips_down[ 2 ].x = 50;
        spriteClips_down[ 2 ].y =  36;
        spriteClips_down[ 2 ].w = 19;
        spriteClips_down[ 2 ].h = 34;

        //Frame 3
        spriteClips_down[ 3 ].x = 74;
        spriteClips_down[ 3 ].y = 36;
        spriteClips_down[ 3 ].w = 19;
        spriteClips_down[ 3 ].h = 34;

        //Frame 4
        spriteClips_down[ 4 ].x = 98;
        spriteClips_down[ 4 ].y = 36;
        spriteClips_down[ 4 ].w = 19;
        spriteClips_down[ 4 ].h = 34;

        //Frame 5
        spriteClips_down[ 5 ].x = 122;
        spriteClips_down[ 5 ].y = 36;
        spriteClips_down[ 5 ].w = 19;
        spriteClips_down[ 5 ].h = 34;

        //Frame 6
        spriteClips_down[ 6 ].x = 146;
        spriteClips_down[ 6 ].y = 36;
        spriteClips_down[ 6 ].w = 19;
        spriteClips_down[ 6 ].h = 34;


        //Frame 7
        spriteClips_down[ 7 ].x = 170;
        spriteClips_down[ 7 ].y = 36;
        spriteClips_down[ 7 ].w = 19;
        spriteClips_down[ 7 ].h = 34;

        //Frame 8
        spriteClips_down[ 8 ].x = 194;
        spriteClips_down[ 8 ].y = 36;
        spriteClips_down[ 8 ].w = 19;
        spriteClips_down[ 8 ].h = 34;

        //Frame 9
        spriteClips_down[ 9 ].x = 218;
        spriteClips_down[ 9 ].y = 36;
        spriteClips_down[ 9 ].w = 19;
        spriteClips_down[ 9 ].h = 34;

        //Frame 10
        spriteClips_down[ 10 ].x = 242;
        spriteClips_down[ 10 ].y = 36;
        spriteClips_down[ 10 ].w = 19;
        spriteClips_down[ 10 ].h = 34;

        //Frame 11
        spriteClips_down[ 11 ].x = 266;
        spriteClips_down[ 11 ].y =  36;
        spriteClips_down[ 11 ].w = 19;
        spriteClips_down[ 11 ].h = 34;

        //RIGHT movement
        //Frame 0
        spriteClips_right[ 0 ].x = 290;
        spriteClips_right[ 0 ].y =  2;
        spriteClips_right[ 0 ].w = 25;
        spriteClips_right[ 0 ].h = 31;

        //Frame 1
        spriteClips_right[ 1 ].x =  320;
        spriteClips_right[ 1 ].y =  2;
        spriteClips_right[ 1 ].w = 25;
        spriteClips_right[ 1 ].h = 31;

        //Frame 2
        spriteClips_right[ 2 ].x = 350;
        spriteClips_right[ 2 ].y =  2;
        spriteClips_right[ 2 ].w = 25;
        spriteClips_right[ 2 ].h = 31;

        //Frame 3
        spriteClips_right[ 3 ].x = 380;
        spriteClips_right[ 3 ].y =  2;
        spriteClips_right[ 3 ].w = 25;
        spriteClips_right[ 3 ].h = 31;

        //Frame 4
        spriteClips_right[ 4 ].x = 410;
        spriteClips_right[ 4 ].y = 2;
        spriteClips_right[ 4 ].w = 25;
        spriteClips_right[ 4 ].h = 31;

        //Frame 5
        spriteClips_right[ 5 ].x = 441;
        spriteClips_right[ 5 ].y = 2;
        spriteClips_right[ 5 ].w = 25;
        spriteClips_right[ 5 ].h = 31;

        //Frame 6
        spriteClips_right[ 6 ].x = 471;
        spriteClips_right[ 6 ].y = 2;
        spriteClips_right[ 6 ].w = 25;
        spriteClips_right[ 6 ].h = 31;


        //Frame 7
        spriteClips_right[ 7 ].x = 501;
        spriteClips_right[ 7 ].y = 2;
        spriteClips_right[ 7 ].w = 25;
        spriteClips_right[ 7 ].h = 31;

        //Frame 8
        spriteClips_right[ 8 ].x = 531;
        spriteClips_right[ 8 ].y = 2;
        spriteClips_right[ 8 ].w = 25;
        spriteClips_right[ 8 ].h = 31;

        //Frame 9
        spriteClips_right[ 9 ].x = 562;
        spriteClips_right[ 9 ].y = 2;
        spriteClips_right[ 9 ].w = 25;
        spriteClips_right[ 9 ].h = 31;

        //Frame 10
        spriteClips_right[ 10 ].x = 592;
        spriteClips_right[ 10 ].y = 2;
        spriteClips_right[ 10 ].w = 25;
        spriteClips_right[ 10 ].h = 31;

        //Frame 11
        spriteClips_right[ 11 ].x = 622;
        spriteClips_right[ 11 ].y =  2;
        spriteClips_right[ 11 ].w = 25;
        spriteClips_right[ 11 ].h = 31;

        //LEFT movement
        //Frame 0
        spriteClips_left[ 0 ].x = 290;
        spriteClips_left[ 0 ].y =  38;
        spriteClips_left[ 0 ].w = 25;
        spriteClips_left[ 0 ].h = 31;

        //Frame 1
        spriteClips_left[ 1 ].x =  320;
        spriteClips_left[ 1 ].y =  38;
        spriteClips_left[ 1 ].w = 25;
        spriteClips_left[ 1 ].h = 31;

        //Frame 2
        spriteClips_left[ 2 ].x = 350;
        spriteClips_left[ 2 ].y =  38;
        spriteClips_left[ 2 ].w = 25;
        spriteClips_left[ 2 ].h = 31;

        //Frame 3
        spriteClips_left[ 3 ].x = 380;
        spriteClips_left[ 3 ].y =  38;
        spriteClips_left[ 3 ].w = 25;
        spriteClips_left[ 3 ].h = 31;

        //Frame 4
        spriteClips_left[ 4 ].x = 410;
        spriteClips_left[ 4 ].y = 38;
        spriteClips_left[ 4 ].w = 25;
        spriteClips_left[ 4 ].h = 31;

        //Frame 5
        spriteClips_left[ 5 ].x = 441;
        spriteClips_left[ 5 ].y = 38;
        spriteClips_left[ 5 ].w = 25;
        spriteClips_left[ 5 ].h = 31;

        //Frame 6
        spriteClips_left[ 6 ].x = 471;
        spriteClips_left[ 6 ].y = 38;
        spriteClips_left[ 6 ].w = 25;
        spriteClips_left[ 6 ].h = 31;


        //Frame 7
        spriteClips_left[ 7 ].x = 501;
        spriteClips_left[ 7 ].y = 38;
        spriteClips_left[ 7 ].w = 25;
        spriteClips_left[ 7 ].h = 31;

        //Frame 8
        spriteClips_left[ 8 ].x = 531;
        spriteClips_left[ 8 ].y = 38;
        spriteClips_left[ 8 ].w = 25;
        spriteClips_left[ 8 ].h = 31;

        //Frame 9
        spriteClips_left[ 9 ].x = 562;
        spriteClips_left[ 9 ].y = 38;
        spriteClips_left[ 9 ].w = 25;
        spriteClips_left[ 9 ].h = 31;

        //Frame 10
        spriteClips_left[ 10 ].x = 592;
        spriteClips_left[ 10 ].y = 38;
        spriteClips_left[ 10 ].w = 25;
        spriteClips_left[ 10 ].h = 31;

        //Frame 11
        spriteClips_left[ 11 ].x = 622;
        spriteClips_left[ 11 ].y = 38;
        spriteClips_left[ 11 ].w = 25;
        spriteClips_left[ 11 ].h = 31;

        //IDLE
        //IDLE_LEFT
        //frame 0
        spriteClips_idle_left[ 0 ].x = 652;
        spriteClips_idle_left[ 0 ].y = 2;
        spriteClips_idle_left[ 0 ].w = 14;
        spriteClips_idle_left[ 0 ].h = 30;

        //frame 1
        spriteClips_idle_left[ 1 ].x = 652;
        spriteClips_idle_left[ 1 ].y = 2;
        spriteClips_idle_left[ 1 ].w = 14;
        spriteClips_idle_left[ 1 ].h = 30;

        //frame 2
        spriteClips_idle_left[ 2 ].x = 652;
        spriteClips_idle_left[ 2 ].y = 2;
        spriteClips_idle_left[ 2 ].w = 14;
        spriteClips_idle_left[ 2 ].h = 30;

        //frame3
        spriteClips_idle_left[ 3 ].x = 652;
        spriteClips_idle_left[ 3 ].y = 2;
        spriteClips_idle_left[ 3 ].w = 14;
        spriteClips_idle_left[ 3 ].h = 30;

        //frame 4
        spriteClips_idle_left[ 4 ].x = 652;
        spriteClips_idle_left[ 4 ].y = 2;
        spriteClips_idle_left[ 4 ].w = 14;
        spriteClips_idle_left[ 4 ].h = 30;

        //frame 5
        spriteClips_idle_left[ 5 ].x = 652;
        spriteClips_idle_left[ 5 ].y = 2;
        spriteClips_idle_left[ 5 ].w = 14;
        spriteClips_idle_left[ 5 ].h = 30;

        //frame 6
        spriteClips_idle_left[ 6 ].x = 652;
        spriteClips_idle_left[ 6 ].y = 2;
        spriteClips_idle_left[ 6 ].w = 14;
        spriteClips_idle_left[ 6 ].h = 30;

        //frame 7
        spriteClips_idle_left[ 7 ].x = 652;
        spriteClips_idle_left[ 7 ].y = 2;
        spriteClips_idle_left[ 7 ].w = 14;
        spriteClips_idle_left[ 7 ].h = 30;

        //frame 8
        spriteClips_idle_left[ 8 ].x = 652;
        spriteClips_idle_left[ 8 ].y = 2;
        spriteClips_idle_left[ 8 ].w = 14;
        spriteClips_idle_left[ 8 ].h = 30;

        //frame 9
        spriteClips_idle_left[ 9 ].x = 652;
        spriteClips_idle_left[ 9 ].y = 2;
        spriteClips_idle_left[ 9 ].w = 14;
        spriteClips_idle_left[ 9 ].h = 30;

        //frame 10
        spriteClips_idle_left[ 10 ].x = 652;
        spriteClips_idle_left[ 10 ].y = 2;
        spriteClips_idle_left[ 10 ].w = 14;
        spriteClips_idle_left[ 10 ].h = 30;

        //frame 11
        spriteClips_idle_left[ 11 ].x = 652;
        spriteClips_idle_left[ 11 ].y = 2;
        spriteClips_idle_left[ 11 ].w = 14;
        spriteClips_idle_left[ 11 ].h = 30;

        //IDLE_RIGHT
        //frame 0
        spriteClips_idle_right[ 0 ].x = 652;
        spriteClips_idle_right[ 0 ].y = 36;
        spriteClips_idle_right[ 0 ].w = 14;
        spriteClips_idle_right[ 0 ].h = 32;

        //frame 1
        spriteClips_idle_right[ 1 ].x = 652;
        spriteClips_idle_right[ 1 ].y = 36;
        spriteClips_idle_right[ 1 ].w = 14;
        spriteClips_idle_right[ 1 ].h = 32;

        //frame 2
        spriteClips_idle_right[ 2 ].x = 652;
        spriteClips_idle_right[ 2 ].y = 36;
        spriteClips_idle_right[ 2 ].w = 14;
        spriteClips_idle_right[ 2 ].h = 32;

        //frame3
        spriteClips_idle_right[ 3 ].x = 652;
        spriteClips_idle_right[ 3 ].y = 36;
        spriteClips_idle_right[ 3 ].w = 14;
        spriteClips_idle_right[ 3 ].h = 32;

        //frame 4
        spriteClips_idle_right[ 4 ].x = 652;
        spriteClips_idle_right[ 4 ].y = 36;
        spriteClips_idle_right[ 4 ].w = 14;
        spriteClips_idle_right[ 4 ].h = 32;

        //frame 5
        spriteClips_idle_right[ 5 ].x = 652;
        spriteClips_idle_right[ 5 ].y = 36;
        spriteClips_idle_right[ 5 ].w = 14;
        spriteClips_idle_right[ 5 ].h = 32;

        //frame 6
        spriteClips_idle_right[ 6 ].x = 652;
        spriteClips_idle_right[ 6 ].y = 36;
        spriteClips_idle_right[ 6 ].w = 14;
        spriteClips_idle_right[ 6 ].h = 32;

        //frame 7
        spriteClips_idle_right[ 7 ].x = 652;
        spriteClips_idle_right[ 7 ].y = 36;
        spriteClips_idle_right[ 7 ].w = 14;
        spriteClips_idle_right[ 7 ].h = 32;

        //frame 8
        spriteClips_idle_right[ 8 ].x = 652;
        spriteClips_idle_right[ 8 ].y = 36;
        spriteClips_idle_right[ 8 ].w = 14;
        spriteClips_idle_right[ 8 ].h = 32;

        //frame 9
        spriteClips_idle_right[ 9 ].x = 652;
        spriteClips_idle_right[ 9 ].y = 36;
        spriteClips_idle_right[ 9 ].w = 14;
        spriteClips_idle_right[ 9 ].h = 32;

        //frame 10
        spriteClips_idle_right[ 10 ].x = 652;
        spriteClips_idle_right[ 10 ].y = 36;
        spriteClips_idle_right[ 10 ].w = 14;
        spriteClips_idle_right[ 10 ].h = 32;

        //frame 11
        spriteClips_idle_right[ 11 ].x = 652;
        spriteClips_idle_right[ 11 ].y = 36;
        spriteClips_idle_right[ 11 ].w = 14;
        spriteClips_idle_right[ 11 ].h = 32;

        //IDLE_UP
        //frame 0
        spriteClips_idle_up[ 0 ].x = 671;
        spriteClips_idle_up[ 0 ].y = 2;
        spriteClips_idle_up[ 0 ].w = 15;
        spriteClips_idle_up[ 0 ].h = 30;

        //frame 1
        spriteClips_idle_up[ 1 ].x = 671;
        spriteClips_idle_up[ 1 ].y = 2;
        spriteClips_idle_up[ 1 ].w = 15;
        spriteClips_idle_up[ 1 ].h = 30;

        //frame 2
        spriteClips_idle_up[ 2 ].x = 671;
        spriteClips_idle_up[ 2 ].y = 2;
        spriteClips_idle_up[ 2 ].w = 15;
        spriteClips_idle_up[ 2 ].h = 30;

        //frame3
        spriteClips_idle_up[ 3 ].x = 671;
        spriteClips_idle_up[ 3 ].y = 2;
        spriteClips_idle_up[ 3 ].w = 15;
        spriteClips_idle_up[ 3 ].h = 30;

        //frame 4
        spriteClips_idle_up[ 4 ].x = 671;
        spriteClips_idle_up[ 4 ].y = 2;
        spriteClips_idle_up[ 4 ].w = 15;
        spriteClips_idle_up[ 4 ].h = 30;

        //frame 5
        spriteClips_idle_up[ 5 ].x = 671;
        spriteClips_idle_up[ 5 ].y = 2;
        spriteClips_idle_up[ 5 ].w = 15;
        spriteClips_idle_up[ 5 ].h = 30;

        //frame 6
        spriteClips_idle_up[ 6 ].x = 671;
        spriteClips_idle_up[ 6 ].y = 2;
        spriteClips_idle_up[ 6 ].w = 15;
        spriteClips_idle_up[ 6 ].h = 30;

        //frame 7
        spriteClips_idle_up[ 7 ].x = 671;
        spriteClips_idle_up[ 7 ].y = 2;
        spriteClips_idle_up[ 7 ].w = 15;
        spriteClips_idle_up[ 7 ].h = 30;

        //frame 8
        spriteClips_idle_up[ 8 ].x = 671;
        spriteClips_idle_up[ 8 ].y = 2;
        spriteClips_idle_up[ 8 ].w = 15;
        spriteClips_idle_up[ 8 ].h = 30;

        //frame 9
        spriteClips_idle_up[ 9 ].x = 671;
        spriteClips_idle_up[ 9 ].y = 2;
        spriteClips_idle_up[ 9 ].w = 15;
        spriteClips_idle_up[ 9 ].h = 30;

        //frame 10
        spriteClips_idle_up[ 10 ].x = 671;
        spriteClips_idle_up[ 10 ].y = 2;
        spriteClips_idle_up[ 10 ].w = 15;
        spriteClips_idle_up[ 10 ].h = 30;

        //frame 11
        spriteClips_idle_up[ 11 ].x = 671;
        spriteClips_idle_up[ 11 ].y = 2;
        spriteClips_idle_up[ 11 ].w = 15;
        spriteClips_idle_up[ 11 ].h = 30;

        //IDLE_DOWN
        //frame 0
        spriteClips_idle_down[ 0 ].x = 671;
        spriteClips_idle_down[ 0 ].y = 36;
        spriteClips_idle_down[ 0 ].w = 15;
        spriteClips_idle_down[ 0 ].h = 32;

        //frame 1
        spriteClips_idle_down[ 1 ].x = 671;
        spriteClips_idle_down[ 1 ].y = 36;
        spriteClips_idle_down[ 1 ].w = 15;
        spriteClips_idle_down[ 1 ].h = 32;

        //frame 2
        spriteClips_idle_down[ 2 ].x = 671;
        spriteClips_idle_down[ 2 ].y = 36;
        spriteClips_idle_down[ 2 ].w = 15;
        spriteClips_idle_down[ 2 ].h = 32;

        //frame3
        spriteClips_idle_down[ 3 ].x = 671;
        spriteClips_idle_down[ 3 ].y = 36;
        spriteClips_idle_down[ 3 ].w = 15;
        spriteClips_idle_down[ 3 ].h = 32;

        //frame 4
        spriteClips_idle_down[ 4 ].x = 671;
        spriteClips_idle_down[ 4 ].y = 36;
        spriteClips_idle_down[ 4 ].w = 15;
        spriteClips_idle_down[ 4 ].h = 32;

        //frame 5
        spriteClips_idle_down[ 5 ].x = 671;
        spriteClips_idle_down[ 5 ].y = 36;
        spriteClips_idle_down[ 5 ].w = 15;
        spriteClips_idle_down[ 5 ].h = 32;

        //frame 6
        spriteClips_idle_down[ 6 ].x = 671;
        spriteClips_idle_down[ 6 ].y = 36;
        spriteClips_idle_down[ 6 ].w = 15;
        spriteClips_idle_down[ 6 ].h = 32;

        //frame 7
        spriteClips_idle_down[ 7 ].x = 671;
        spriteClips_idle_down[ 7 ].y = 36;
        spriteClips_idle_down[ 7 ].w = 15;
        spriteClips_idle_down[ 7 ].h = 32;

        //frame 8
        spriteClips_idle_down[ 8 ].x = 671;
        spriteClips_idle_down[ 8 ].y = 36;
        spriteClips_idle_down[ 8 ].w = 15;
        spriteClips_idle_down[ 8 ].h = 32;

        //frame 9
        spriteClips_idle_down[ 9 ].x = 671;
        spriteClips_idle_down[ 9 ].y = 36;
        spriteClips_idle_down[ 9 ].w = 15;
        spriteClips_idle_down[ 9 ].h = 32;

        //frame 10
        spriteClips_idle_down[ 10 ].x = 671;
        spriteClips_idle_down[ 10 ].y = 36;
        spriteClips_idle_down[ 10 ].w = 15;
        spriteClips_idle_down[ 10 ].h = 32;

        //frame 11
        spriteClips_idle_down[ 11 ].x = 671;
        spriteClips_idle_down[ 11 ].y = 36;
        spriteClips_idle_down[ 11 ].w = 15;
        spriteClips_idle_down[ 11 ].h = 32;
        }

    //hitWall();
    if (!idle)
    {
        if (upMov)
            lastMov = 'U';
        else if (downMov)
            lastMov = 'D';
        else if (rightMov)
            lastMov = 'R';
        else if (leftMov)
            lastMov = 'L';
    }

    if (idle)
    {
        if (lastMov == 'U')
        {
            srcRect = spriteClips_idle_up[frame % FLYING_FRAMES];
        }
        else if (lastMov == 'R')
        {
            srcRect = spriteClips_idle_right[frame % FLYING_FRAMES];
        }
        else if (lastMov == 'L')
        {
            srcRect = spriteClips_idle_left[frame % FLYING_FRAMES];
        }

        else if (lastMov == 'D')
        {
            srcRect = spriteClips_idle_down[frame % FLYING_FRAMES];
        }

    }
    else if (upMov)
    {
        srcRect = spriteClips[frame % FLYING_FRAMES];
    }
    else if (downMov)
    {
        srcRect = spriteClips_down[frame % FLYING_FRAMES];
    }
    else if (rightMov)
    {
        srcRect = spriteClips_right[frame % FLYING_FRAMES];
    }

    else if (leftMov)
    {
        srcRect = spriteClips_left[frame % FLYING_FRAMES];
    }

//
//    if (rightMov and upMov)
//    {
//        x += 8.4853;
//        y -= 8.4853;
//    }
//    else if (rightMov and downMov)
//    {
//        x += 8.4853;
//        y += 8.4853;
//    }
//    else if (leftMov and upMov)
//    {
//        x -= 8.4853;
//        y -= 8.4853;
//    }
//    else if (leftMov and downMov)
//    {
//        x -= 8.4853;
//        y += 8.4853;
//    }
//    else if (rightMov)
//        x += 12;
//    else if (leftMov)
//        x -= 12;
//    else if (upMov)
//        y -= 12;
//    else if (downMov)
//        y += 12;


    std::cout << "X   " << x << std::endl;
    std::cout << "Y   " << y << std::endl;

    if (solidX & leftMov)
    {
        if (upMov or downMov)
            speedX += 8.4853;
        else
            speedX += 12;
    }

    if (solidL & rightMov)
    {
        if (upMov or downMov)
            speedX -= 8.4853;
        else
            speedX -= 12;
    }
    if (solidY & upMov)
    {
        if (rightMov or leftMov)
            speedY -= 8.4853;
        else
            speedY -= 12;
    }
    if (solidD & downMov)
    {
        if (rightMov or leftMov)
            speedY += 8.4853;
        else
            speedY += 12;
    }
    destRect.h = srcRect.h * tempRect.h;
    destRect.w = srcRect.w * tempRect.h;
    destRect.x = 1024/2 + x;

    destRect.y = 768/2 - y;


}

void Player::draw()
{

    SDL_RenderCopyEx(Game::renderer, objTexture, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);

}

void Player::attack()
{


}

void Player::move()
{


}

Player* Player::getInstance()
{
    if (instance == NULL)
        instance = new Player("Images/main_grid_spritesheet.png", 0, 0);
    return instance;
}

void Player::setRightMov(bool right)
{
    rightMov = right;
}

bool Player::getIdle()
{
    return idle;
}

void Player::setIdle(bool idle)
{
    this->idle = idle;

}

SDL_Rect Player::camera()
{

    int x_disp = 0;
    int y_disp = 0;

    if (1024/2 + destRect.x < 0 or (1024/2 + destRect.x > 10))
           x_disp = (1024/2 - destRect.x)*0.1;
//
//    if (1024/2 - destRect.x > 10)
//            speedx = (1024/2 - destRect.x);

    if (768/2 + destRect.y > 10 or (768/2 + destRect.y < 0))
            y_disp = (768/2 - destRect.y)*0.1;

//    if (768/2 - destRect.y < 0)
//            speedy = (768/2 - destRect.y);

    SDL_Rect tempRect;
    tempRect.x = x_disp;
    tempRect.y = y_disp;
    tempRect.h = 2;

   return tempRect;
}

void Player::setUpMov(bool up)
{
    upMov = up;

}


void Player::setLeftMov(bool left)
{
    leftMov = left;
}

void Player::setDownMov(bool down)
{
    downMov = down;
}

