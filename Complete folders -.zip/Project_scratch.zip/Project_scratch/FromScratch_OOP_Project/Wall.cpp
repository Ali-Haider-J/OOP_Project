#include "Wall.h"

Wall::Wall()
{
     x = 60;
     y = 2020;
     wallTex =  TextureManager::LoadTexture("Images/1.png");
}


Wall::~Wall()
{


}


void Wall::draw()
{

     SDL_RenderCopyEx(Game::renderer, wallTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);

}

void Wall::Update(long int frame, SDL_Rect tempRect)
{


    srcRect.h = 250;
    srcRect.w = 45;
    srcRect.x = 0;
    srcRect.y = 0;
    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x = destRect.x + x;
    destRect.y = destRect.y + y;

    x = tempRect.x;
    y = tempRect.y;


    std::cout << "Wall x is:" << destRect.x << std::endl;

    std::cout << "Wall y is:" << destRect.y << std::endl;

   /* if (speedX == 0)
    {
        destRect.x = 20;
    }
    if (speedX == 0)
    {
        destRect.x = -20;
    }*/
    //destRect = camera(x, y, 2, speedX, speedY);
}
