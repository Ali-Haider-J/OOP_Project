#pragma once
#include "Enemy.h"

class EnemyThree : public Enemy
{
public:
    EnemyThree();
    ~EnemyThree();
};
