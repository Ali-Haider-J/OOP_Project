#pragma once
#include "Enemy.h"
#include "Player.h"

class EnemyOne : public Enemy
{
private:
    SDL_Texture* EnemyOneTex;
    SDL_Rect spriteClips_spawn_animation[9];
public:
    EnemyOne(int, int);
    ~EnemyOne();
    void draw();
    void Update(long int frame, SDL_Rect tempRect);
    int attack_state;
    void attack(int, int);
};
