#pragma once
#include "Enemy.h"

class EnemyTwo : public Enemy
{
public:
    EnemyTwo(int x, int y);
    ~EnemyTwo();
    void draw();
    void Update(long int frame, SDL_Rect tempRect);
    void attack(int, int);
};
