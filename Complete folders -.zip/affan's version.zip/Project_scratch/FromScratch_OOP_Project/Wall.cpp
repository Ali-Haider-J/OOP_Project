#include "Wall.h"

Wall::Wall()
{
     x = 0;
     y = 0;
     destRect.x = destRect.y = 0;
     wallTex =  TextureManager::LoadTexture("Images/boundary_hidden.png");
     hit = false;
}


Wall::~Wall()
{


}


void Wall::draw()
{

     SDL_RenderCopyEx(Game::renderer, wallTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);

}

void Wall::Update(long int frame, SDL_Rect tempRect)
{

    x = tempRect.x;
    y = tempRect.y;

    if (destRect.x >= 345)
        hit = true;
    else
        hit = false;


    srcRect.h = 250;
    srcRect.w = 45;
    srcRect.x = 0;
    srcRect.y = 0;
    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x = destRect.x + x;
    destRect.y = destRect.y + y;



    std::cout << "Wall x is:" << destRect.x << std::endl;

    std::cout << "Wall y is:" << destRect.y << std::endl;

}
