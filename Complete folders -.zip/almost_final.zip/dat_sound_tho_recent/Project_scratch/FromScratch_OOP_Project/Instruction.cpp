#include "Instruction.h"

Instruction::Instruction()
{
    this->x = x;
    this->y = y;
    instructionTex =  TextureManager::LoadTexture("Images/main_ss.png");
    keysTex =  TextureManager::LoadTexture("Images/keys.png");
    tipsTex = TextureManager::LoadTexture("Images/instructions.png");
    altAttack = false;
    counter = 0;

}

Instruction::~Instruction()
{


}

void Instruction::draw()
{


        SDL_RenderCopyEx(Game::renderer, instructionTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);
        SDL_RenderCopyEx(Game::renderer, keysTex, &keysSrcRect, &keysDestRect, 0.0, NULL, SDL_FLIP_NONE);
        SDL_RenderCopyEx(Game::renderer, instructionTex, &attackSrcRect, &attackDestRect, 0.0, NULL, SDL_FLIP_NONE);
        SDL_RenderCopyEx(Game::renderer, keysTex, &keyZSrcRect, &keyZDestRect, 0.0, NULL, SDL_FLIP_NONE);
        SDL_RenderCopyEx(Game::renderer, keysTex, &keyXSrcRect, &keyXDestRect, 0.0, NULL, SDL_FLIP_NONE);
        SDL_RenderCopyEx(Game::renderer, instructionTex, &dodgeSrcRect, &dodgeDestRect, 0.0, NULL, SDL_FLIP_NONE);
        SDL_RenderCopyEx(Game::renderer, tipsTex, &tipsSrcRect, &tipsDestRect, 0.0, NULL, SDL_FLIP_NONE);
}

void Instruction::Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target)
{
    {
        //UP movement
        //frame 0
        spriteClips[ 0 ].x =  0;
        spriteClips[ 0 ].y =  0;
        spriteClips[ 0 ].w = 16;
        spriteClips[ 0 ].h = 30;

        //Frame 1
        spriteClips[ 1 ].x =  16;
        spriteClips[ 1 ].y =  0;
        spriteClips[ 1 ].w = 16;
        spriteClips[ 1 ].h = 30;

        //Frame 2
        spriteClips[ 2 ].x =  32;
        spriteClips[ 2 ].y =  0;
        spriteClips[ 2 ].w = 16;
        spriteClips[ 2 ].h = 30;

        //Frame 3
        spriteClips[ 3 ].x =  48;
        spriteClips[ 3 ].y =  0;
        spriteClips[ 3 ].w = 16;
        spriteClips[ 3 ].h = 30;


        //Frame 4
        spriteClips[ 4 ].x = 64;
        spriteClips[ 4 ].y = 0;
        spriteClips[ 4 ].w = 16;
        spriteClips[ 4 ].h = 30;

        //Frame 5
        spriteClips[ 5 ].x = 80;
        spriteClips[ 5 ].y = 0;
        spriteClips[ 5 ].w = 16;
        spriteClips[ 5 ].h = 30;

        //Frame 6
        spriteClips[ 6 ].x = 96;
        spriteClips[ 6 ].y = 0;
        spriteClips[ 6 ].w = 16 ;
        spriteClips[ 6 ].h = 30;


        //Frame 7
        spriteClips[ 7 ].x = 112;
        spriteClips[ 7 ].y = 0;
        spriteClips[ 7 ].w = 16;
        spriteClips[ 7 ].h = 30;

        //Frame 8
        spriteClips[ 8 ].x = 128;
        spriteClips[ 8 ].y = 0;
        spriteClips[ 8 ].w = 16;
        spriteClips[ 8 ].h = 30;

        //Frame 9
        spriteClips[ 9 ].x = 144;
        spriteClips[ 9 ].y = 0;
        spriteClips[ 9 ].w = 16;
        spriteClips[ 9 ].h = 30;

        //Frame 10
        spriteClips[ 10 ].x = 160;
        spriteClips[ 10 ].y = 0;
        spriteClips[ 10 ].w = 16;
        spriteClips[ 10 ].h = 30;

        //Frame 11
        spriteClips[ 11 ].x = 176;
        spriteClips[ 11 ].y =  0;
        spriteClips[ 11 ].w = 16;
        spriteClips[ 11 ].h = 30;

        //DOWN movement
        //Frame 0
        spriteClips_down[ 0 ].x =   0;
        spriteClips_down[ 0 ].y =  30;
        spriteClips_down[ 0 ].w = 18;
        spriteClips_down[ 0 ].h = 31;

        //Frame 1
        spriteClips_down[ 1 ].x =  18;
        spriteClips_down[ 1 ].y =  30;
        spriteClips_down[ 1 ].w = 18;
        spriteClips_down[ 1 ].h = 31;

        //Frame 2
        spriteClips_down[ 2 ].x =  36;
        spriteClips_down[ 2 ].y =  30;
        spriteClips_down[ 2 ].w = 18;
        spriteClips_down[ 2 ].h = 31;

        //Frame 3
        spriteClips_down[ 3 ].x =  54;
        spriteClips_down[ 3 ].y =  30;
        spriteClips_down[ 3 ].w = 18;
        spriteClips_down[ 3 ].h = 31;

        //Frame 4
        spriteClips_down[ 4 ].x =  72;
        spriteClips_down[ 4 ].y =  30;
        spriteClips_down[ 4 ].w = 18;
        spriteClips_down[ 4 ].h = 31;

        //Frame 5
        spriteClips_down[ 5 ].x =  90;
        spriteClips_down[ 5 ].y =  30;
        spriteClips_down[ 5 ].w = 18;
        spriteClips_down[ 5 ].h = 31;

        //Frame 6
        spriteClips_down[ 6 ].x =  108;
        spriteClips_down[ 6 ].y =  30;
        spriteClips_down[ 6 ].w = 18;
        spriteClips_down[ 6 ].h = 31;


        //Frame 7
        spriteClips_down[ 7 ].x =  126;
        spriteClips_down[ 7 ].y =  30;
        spriteClips_down[ 7 ].w = 18;
        spriteClips_down[ 7 ].h = 31;

        //Frame 8
        spriteClips_down[ 8 ].x =  144;
        spriteClips_down[ 8 ].y =  30;
        spriteClips_down[ 8 ].w = 18;
        spriteClips_down[ 8 ].h = 31;

        //Frame 9
        spriteClips_down[ 9 ].x =  162;
        spriteClips_down[ 9 ].y =  30;
        spriteClips_down[ 9 ].w = 18;
        spriteClips_down[ 9 ].h = 31;

        //Frame 10
        spriteClips_down[ 10 ].x =  180;
        spriteClips_down[ 10 ].y =  30;
        spriteClips_down[ 10 ].w = 18;
        spriteClips_down[ 10 ].h = 31;

        //Frame 11
        spriteClips_down[ 11 ].x =  198;
        spriteClips_down[ 11 ].y =  30;
        spriteClips_down[ 11 ].w = 18;
        spriteClips_down[ 11 ].h = 31;

        //RIGHT movement
        //Frame 0
        spriteClips_right[ 0 ].x = 0;
        spriteClips_right[ 0 ].y =  61;
        spriteClips_right[ 0 ].w = 25;
        spriteClips_right[ 0 ].h = 30;

        //Frame 1
        spriteClips_right[ 1 ].x = 25;
        spriteClips_right[ 1 ].y =  61;
        spriteClips_right[ 1 ].w = 25;
        spriteClips_right[ 1 ].h = 30;

        //Frame 2
        spriteClips_right[ 2 ].x = 50;
        spriteClips_right[ 2 ].y =  61;
        spriteClips_right[ 2 ].w = 25;
        spriteClips_right[ 2 ].h = 30;

        //Frame 3
        spriteClips_right[ 3 ].x = 75;
        spriteClips_right[ 3 ].y =  61;
        spriteClips_right[ 3 ].w = 25;
        spriteClips_right[ 3 ].h = 30;

        //Frame 4
        spriteClips_right[ 4 ].x = 100;
        spriteClips_right[ 4 ].y = 61;
        spriteClips_right[ 4 ].w = 25;
        spriteClips_right[ 4 ].h = 30;

        //Frame 5
        spriteClips_right[ 5 ].x = 125;
        spriteClips_right[ 5 ].y = 61;
        spriteClips_right[ 5 ].w = 25;
        spriteClips_right[ 5 ].h = 30;

        //Frame 6
        spriteClips_right[ 6 ].x = 150;
        spriteClips_right[ 6 ].y = 61;
        spriteClips_right[ 6 ].w = 25;
        spriteClips_right[ 6 ].h = 30;


        //Frame 7
        spriteClips_right[ 7 ].x = 175;
        spriteClips_right[ 7 ].y = 61;
        spriteClips_right[ 7 ].w = 25;
        spriteClips_right[ 7 ].h = 30;

        //Frame 8
        spriteClips_right[ 8 ].x = 200;
        spriteClips_right[ 8 ].y = 61;
        spriteClips_right[ 8 ].w = 25;
        spriteClips_right[ 8 ].h = 30;

        //Frame 9
        spriteClips_right[ 9 ].x = 225;
        spriteClips_right[ 9 ].y = 61;
        spriteClips_right[ 9 ].w = 25;
        spriteClips_right[ 9 ].h = 30;

        //Frame 10
        spriteClips_right[ 10 ].x = 250;
        spriteClips_right[ 10 ].y = 61;
        spriteClips_right[ 10 ].w = 25;
        spriteClips_right[ 10 ].h = 30;

        //Frame 11
        spriteClips_right[ 11 ].x = 275;
        spriteClips_right[ 11 ].y =  61;
        spriteClips_right[ 11 ].w = 25;
        spriteClips_right[ 11 ].h = 30;

        //LEFT movement
        //Frame 0
        spriteClips_left[ 0 ].x = 275;
        spriteClips_left[ 0 ].y =  91;
        spriteClips_left[ 0 ].w = 25;
        spriteClips_left[ 0 ].h = 30;

        //Frame 1
        spriteClips_left[ 1 ].x =  250;
        spriteClips_left[ 1 ].y =  91;
        spriteClips_left[ 1 ].w = 25;
        spriteClips_left[ 1 ].h = 30;

        //Frame 2
        spriteClips_left[ 2 ].x =  225;
        spriteClips_left[ 2 ].y =  91;
        spriteClips_left[ 2 ].w = 25;
        spriteClips_left[ 2 ].h = 30;

        //Frame 3
        spriteClips_left[ 3 ].x =  200;
        spriteClips_left[ 3 ].y =  91;
        spriteClips_left[ 3 ].w = 25;
        spriteClips_left[ 3 ].h = 30;

        //Frame 4
        spriteClips_left[ 4 ].x = 175;
        spriteClips_left[ 4 ].y = 91;
        spriteClips_left[ 4 ].w = 25;
        spriteClips_left[ 4 ].h = 30;

        //Frame 5
        spriteClips_left[ 5 ].x = 150;
        spriteClips_left[ 5 ].y = 91;
        spriteClips_left[ 5 ].w = 25;
        spriteClips_left[ 5 ].h = 30;

        //Frame 6
        spriteClips_left[ 6 ].x = 125;
        spriteClips_left[ 6 ].y = 91;
        spriteClips_left[ 6 ].w = 25;
        spriteClips_left[ 6 ].h = 30;


        //Frame 7
        spriteClips_left[ 7 ].x = 100;
        spriteClips_left[ 7 ].y = 91;
        spriteClips_left[ 7 ].w = 25;
        spriteClips_left[ 7 ].h = 30;

        //Frame 8
        spriteClips_left[ 8 ].x = 75;
        spriteClips_left[ 8 ].y = 91;
        spriteClips_left[ 8 ].w = 25;
        spriteClips_left[ 8 ].h = 30;

        //Frame 9
        spriteClips_left[ 9 ].x = 50;
        spriteClips_left[ 9 ].y = 91;
        spriteClips_left[ 9 ].w = 25;
        spriteClips_left[ 9 ].h = 30;

        //Frame 10
        spriteClips_left[ 10 ].x = 25;
        spriteClips_left[ 10 ].y = 91;
        spriteClips_left[ 10 ].w = 25;
        spriteClips_left[ 10 ].h = 30;

        //Frame 11
        spriteClips_left[ 11 ].x = 0;
        spriteClips_left[ 11 ].y = 91;
        spriteClips_left[ 11 ].w = 25;
        spriteClips_left[ 11 ].h = 30;

        //KEYS
        //frame 0
        spriteClips_keys[ 0 ].x = 22;
        spriteClips_keys[ 0 ].y = 40;
        spriteClips_keys[ 0 ].w = 168;
        spriteClips_keys[ 0 ].h = 116;

        //ATTACK_RIGHT
        //frame 0
        spriteClips_attack_right[ 0 ].x = 0;
        spriteClips_attack_right[ 0 ].y = 190;
        spriteClips_attack_right[ 0 ].w = 65;
        spriteClips_attack_right[ 0 ].h = 39;

         //frame 1
        spriteClips_attack_right[ 1 ].x = 65;
        spriteClips_attack_right[ 1 ].y = 190;
        spriteClips_attack_right[ 1 ].w = 65;
        spriteClips_attack_right[ 1 ].h = 39;

         //frame 2
        spriteClips_attack_right[ 2 ].x = 130;
        spriteClips_attack_right[ 2 ].y = 190;
        spriteClips_attack_right[ 2 ].w = 65;
        spriteClips_attack_right[ 2 ].h = 39;

        //frame 3
        spriteClips_attack_right[ 3 ].x = 195;
        spriteClips_attack_right[ 3 ].y = 190;
        spriteClips_attack_right[ 3 ].w = 65;
        spriteClips_attack_right[ 3 ].h = 39;

        //frame 4
        spriteClips_attack_right[ 4 ].x = 260;
        spriteClips_attack_right[ 4 ].y = 190;
        spriteClips_attack_right[ 4 ].w = 65;
        spriteClips_attack_right[ 4 ].h = 39;

        //frame 5
        spriteClips_attack_right[ 5 ].x = 325;
        spriteClips_attack_right[ 5 ].y = 190;
        spriteClips_attack_right[ 5 ].w = 65;
        spriteClips_attack_right[ 5 ].h = 39;

        //frame 6
        spriteClips_attack_right[ 6 ].x = 390;
        spriteClips_attack_right[ 6 ].y = 190;
        spriteClips_attack_right[ 6 ].w = 65;
        spriteClips_attack_right[ 6 ].h = 39;

        //ATTACK_RIGHT_ALT
        //frame 0
        spriteClips_attack_right_alt[ 0 ].x = 0;
        spriteClips_attack_right_alt[ 0 ].y = 229;
        spriteClips_attack_right_alt[ 0 ].w = 65;
        spriteClips_attack_right_alt[ 0 ].h = 39;

         //frame 1
        spriteClips_attack_right_alt[ 1 ].x = 65;
        spriteClips_attack_right_alt[ 1 ].y = 229;
        spriteClips_attack_right_alt[ 1 ].w = 65;
        spriteClips_attack_right_alt[ 1 ].h = 39;

         //frame 2
        spriteClips_attack_right_alt[ 2 ].x = 130;
        spriteClips_attack_right_alt[ 2 ].y = 229;
        spriteClips_attack_right_alt[ 2 ].w = 65;
        spriteClips_attack_right_alt[ 2 ].h = 39;

        //frame 3
        spriteClips_attack_right_alt[ 3 ].x = 195;
        spriteClips_attack_right_alt[ 3 ].y = 229;
        spriteClips_attack_right_alt[ 3 ].w = 65;
        spriteClips_attack_right_alt[ 3 ].h = 39;

        //frame 4
        spriteClips_attack_right_alt[ 4 ].x = 260;
        spriteClips_attack_right_alt[ 4 ].y = 229;
        spriteClips_attack_right_alt[ 4 ].w = 65;
        spriteClips_attack_right_alt[ 4 ].h = 39;

        //frame 5
        spriteClips_attack_right_alt[ 5 ].x = 325;
        spriteClips_attack_right_alt[ 5 ].y = 229;
        spriteClips_attack_right_alt[ 5 ].w = 65;
        spriteClips_attack_right_alt[ 5 ].h = 39;

        //Z_KEY
        //frame 0
        spriteClips_z_key[ 0 ].x = 40;
        spriteClips_z_key[ 0 ].y = 180;
        spriteClips_z_key[ 0 ].w = 65;
        spriteClips_z_key[ 0 ].h = 60;

        //X_KEY
        //frame 0
        spriteClips_x_key[ 0 ].x = 185;
        spriteClips_x_key[ 0 ].y = 177;
        spriteClips_x_key[ 0 ].w = 65;
        spriteClips_x_key[ 0 ].h = 70;

        //DODGE_RIGHT
        //frame 0
        spriteClips_dodge_right[0].x = 0;
        spriteClips_dodge_right[0].y = 571;
        spriteClips_dodge_right[0].w = 36;
        spriteClips_dodge_right[0].h = 30;

        //frame 1
        spriteClips_dodge_right[1].x = 36;
        spriteClips_dodge_right[1].y = 571;
        spriteClips_dodge_right[1].w = 36;
        spriteClips_dodge_right[1].h = 30;

        //frame 2
        spriteClips_dodge_right[2].x = 72;
        spriteClips_dodge_right[2].y = 571;
        spriteClips_dodge_right[2].w = 36;
        spriteClips_dodge_right[2].h = 30;

        //frame 3
        spriteClips_dodge_right[3].x = 108;
        spriteClips_dodge_right[3].y = 571;
        spriteClips_dodge_right[3].w = 36;
        spriteClips_dodge_right[3].h = 30;

        //frame 4
        spriteClips_dodge_right[4].x = 144;
        spriteClips_dodge_right[4].y = 571;
        spriteClips_dodge_right[4].w = 36;
        spriteClips_dodge_right[4].h = 30;

        //frame 5
        spriteClips_dodge_right[5].x = 180;
        spriteClips_dodge_right[5].y = 571;
        spriteClips_dodge_right[5].w = 36;
        spriteClips_dodge_right[5].h = 30;

        //frame 6
        spriteClips_dodge_right[6].x = 216;
        spriteClips_dodge_right[6].y = 571;
        spriteClips_dodge_right[6].w = 36;
        spriteClips_dodge_right[6].h = 30;

        //frame 7
        spriteClips_dodge_right[7].x = 252;
        spriteClips_dodge_right[7].y = 571;
        spriteClips_dodge_right[7].w = 36;
        spriteClips_dodge_right[7].h = 30;

        //TIPS
        //frame 0
        spriteClips_tips.x = 0;
        spriteClips_tips.y = 0;
        spriteClips_tips.w = 400;
        spriteClips_tips.h = 550;


    }





    srcRect = spriteClips_right[frame % 12];
    keysSrcRect = spriteClips_keys[frame % 1];
    keyZSrcRect = spriteClips_z_key[frame % 1];
    keyXSrcRect = spriteClips_x_key[frame % 1];
    dodgeSrcRect = spriteClips_dodge_right[frame % 8];
    tipsSrcRect = spriteClips_tips;
    std::cout << "counter is" << counter << std::endl;

    if (!altAttack)
    {
        if (counter < 7)
        {
            attackSrcRect = spriteClips_attack_right[counter % 7];
            counter++;
        }
        if (counter == 6)
        {
            counter = 0;
            altAttack = true;
        }
    }


    else if (altAttack)
    {

        if (counter < 6)
        {
            attackSrcRect = spriteClips_attack_right_alt[counter % 6];
            counter++;
        }
        if (counter == 5)
       {
           counter = 0;
           altAttack = false;
       }
    }

    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x = 100;
    destRect.y = 100;


    keysDestRect.h = keysSrcRect.h * 1;
    keysDestRect.w = keysSrcRect.w * 1;
    keysDestRect.x = 200;
    keysDestRect.y = 50;


    attackDestRect.h = attackSrcRect.h * 2;
    attackDestRect.w = attackSrcRect.w * 2;
    attackDestRect.x = 74;
    attackDestRect.y = 200;


    keyZDestRect.h = keyZSrcRect.h * 1;
    keyZDestRect.w = keyZSrcRect.w * 1;
    keyZDestRect.x = 250;
    keyZDestRect.y = 210;


    keyXDestRect.h = keyXSrcRect.h * 1;
    keyXDestRect.w = keyXSrcRect.w * 1;
    keyXDestRect.x = 250;
    keyXDestRect.y = 320;


    dodgeDestRect.h = dodgeSrcRect.h * 2;
    dodgeDestRect.w = dodgeSrcRect.w * 2;
    dodgeDestRect.x = 74;
    dodgeDestRect.y = 315;

    tipsDestRect.h = tipsSrcRect.h ;
    tipsDestRect.w = tipsSrcRect.w ;
    tipsDestRect.x = 500;
    tipsDestRect.y = 200;
}

