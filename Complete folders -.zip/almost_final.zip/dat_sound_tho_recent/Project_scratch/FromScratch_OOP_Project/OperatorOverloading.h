#pragma once
#include "Object.h"

inline bool operator==(SDL_Rect a, SDL_Rect b)
{

    if ((a.x == b.x) & (a.y == b.y) & (a.w == b.w) & (a.h & b.h))
        return true;
    return false;


}

inline Object** sortedArray(Object** arrayObjects, int NoOfObjects )
{
    //arrayObjects = new int[NoOfObjects];

    int i;
    int j;
    Object* temp;
    Object* tempArray[NoOfObjects];

    for (i=0; i<NoOfObjects; i++)
    {
        for (j=i+1; j<NoOfObjects; j++)
        {
            if (arrayObjects[j]->getY() < arrayObjects[i]->getY())
            {
                temp = arrayObjects[i];
                arrayObjects[i] = arrayObjects[j];
                arrayObjects[j] = temp;
            }
        }
    }


    for (int i = 0; i < NoOfObjects; i++)
    {
         tempArray[i] = arrayObjects[i];
         std::cout << "TEMPP ARRAY " << i << "IS " << tempArray[i]->getY() << std::endl;
    }

    return arrayObjects;

}
