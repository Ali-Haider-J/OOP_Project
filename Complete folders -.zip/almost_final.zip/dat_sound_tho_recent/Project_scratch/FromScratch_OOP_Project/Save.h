#pragma once
#include "Object.h"
#include <fstream>
#include "TextureManager.h"
//#include "OperatorOverloading.h"
class Save : public Object
{

private:
    bool hit;
    int savePos;
       Mix_Chunk *gsave = NULL;
public:
    Save(int, int, int);
    Save();
    ~Save();
    void save();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int, SDL_Rect Target);
    SDL_Rect spriteClips_animation[22];
    bool getHit();
};
