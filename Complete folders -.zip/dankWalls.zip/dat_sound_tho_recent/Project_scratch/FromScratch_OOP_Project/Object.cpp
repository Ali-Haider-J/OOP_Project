#include "Object.h"

Object::Object()
{


}

Object::~Object()
{


}

int Object::getX()
{


}

int Object::getY()
{

}

void Object::setX(float x)
{

}

void Object::setY(float y)
{

}

void Object::setUpMov(bool)
{

}

void Object::setDownMov(bool)
{

}

void Object::setRightMov(bool)
{


}

void Object::setLeftMov(bool)
{

}

void Object::setIdle(bool)
{

}

bool Object::getActive()
{

}

void Object::setAttack(bool)
{

}

void Object::setDodge(bool)
{

}

int Object::getStamina()
{

}

SDL_Rect Object::camera()
{

}

void Object::Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target)
{

}

void Object::hitWall(bool a, bool b, bool c, bool d)
{

}

void Object::draw()
{

}

void Object::setClicked(bool clicked)
{

}

bool Object::getNewGame()
{

}

bool Object::getQuit()
{

}

bool Object::getInstruction()
{

}

void Object::setInstruction(bool instruction)
{

}

SDL_Rect Object::getHitbox()
{

}

bool Object::getHit()
{

}

void Object::setHit(bool hit)
{

}
