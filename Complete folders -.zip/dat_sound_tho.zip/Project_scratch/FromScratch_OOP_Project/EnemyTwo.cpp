#include "EnemyTwo.h"

EnemyTwo::EnemyTwo(int posx, int posy)
{
    std::cout << "EnemyTwo spawned!" << std::endl;
    enemyTwoX = posx;
    enemyTwoX = posy;

}

void EnemyTwo::draw()
{

}

void EnemyTwo::Update(long int frame, SDL_Rect tempRect, int a, int b)
{

}

void EnemyTwo::attack(int, int)
{

}
