#pragma once
#include "Object.h"
#include "TextureManager.h"

class Wall : public Object
{
protected:
    int wallX;
    int wallY;
     SDL_Texture* wallTex;
     SDL_Rect hitbox;
public:
     Wall();
    ~Wall();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int);
};
