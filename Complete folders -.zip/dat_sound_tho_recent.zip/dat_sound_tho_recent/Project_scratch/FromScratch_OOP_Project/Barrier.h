#pragma once
#include "Object.h"
#include "TextureManager.h"

class Barrier : public Object
{
public:
    Barrier(int, int, int);
    ~Barrier();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int, SDL_Rect Target);
    SDL_Rect spriteClips_locked[1];
    SDL_Rect spriteClips_open[1];
    bool getHitL();
    bool getHitU();

private:
    bool hitU;
    bool hitL;
    int type;
};
