#pragma once
#include "Object.h"

#include "TextureManager.h"


class Bullet : public Object
{
private:
    int indFrame;
     SDL_Texture* bulletTex;

public:
    Bullet(int, int);
    ~Bullet();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int, SDL_Rect Target);
    SDL_Rect spriteBullets[20];
    bool getHit();

};
