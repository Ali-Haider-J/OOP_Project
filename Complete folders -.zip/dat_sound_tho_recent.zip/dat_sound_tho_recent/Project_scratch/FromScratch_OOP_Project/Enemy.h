#pragma once
#include "Unit.h"

class Enemy : public Unit
{

protected:

     bool hit;
public:
         static int enemyNo;
    Enemy();
    virtual ~Enemy();
    virtual void draw();
    virtual void Update(long int frame, SDL_Rect tempRect, int, int, SDL_Rect Target);
    virtual void attack(int, int);
    virtual void gotAttacked(SDL_Rect);
};
