#pragma once
#include <math.h>
#include <stdlib.h>
#include "SDL.h"


class Object
{
protected:
    bool solidX;
    bool solidY;
    bool solidL;
    bool solidD;
    SDL_Texture* objTexture;
    SDL_Rect srcRect, destRect;
    int x;
    int y;
    SDL_Rect hitbox;


public:

    bool hitD;  //need to make getter and setter for these 4
    bool hitL;
    bool hitR;
    bool hitU;
    bool hitBL;
    bool hitBU;
    bool hit;
    Object();
    virtual ~Object();
    virtual int getX();
    virtual int getY();
    virtual void setX(float x);
    virtual void setY(float y);
    virtual void setUpMov(bool);
    virtual void setDownMov(bool);
    virtual void setRightMov(bool);
    virtual void setLeftMov(bool);
    virtual void setIdle(bool);
     virtual int getStamina();
    virtual bool getActive();
    virtual void setAttack(bool);
    virtual void setDodge(bool);
    virtual SDL_Rect camera();
    virtual void draw();
    virtual void Update(long int frame, SDL_Rect tempRect, int, int, SDL_Rect Target);
    virtual void hitWall(bool, bool, bool, bool);
    virtual void setClicked(bool);
    virtual bool getNewGame();
    virtual bool getInstruction();
    virtual bool getQuit();
    virtual void setInstruction(bool);
    virtual SDL_Rect getHitbox();
    virtual bool getHit();
    virtual void setHit(bool);
    virtual SDL_Rect getAttackbox();
    virtual void save();
    virtual bool getLoad();
    virtual void setLoad(bool);
    virtual void setNewGame(bool);
    virtual void hitBarrier(bool, bool);
    virtual bool getHitL();
    virtual bool getHitU();
    virtual void gotAttacked(SDL_Rect);
    virtual bool getAlive();
    virtual bool getBarrierTrigger();
    virtual void setBarrierTrigger(bool);
    virtual bool enemyChecker(bool);
};
