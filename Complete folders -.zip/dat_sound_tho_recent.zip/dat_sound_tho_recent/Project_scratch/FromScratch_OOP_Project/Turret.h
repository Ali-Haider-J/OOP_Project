#pragma once
#include "Object.h"

#include "TextureManager.h"

class Turret : public Object
{
private:

public:
    Turret(int, int);
    Turret();
    ~Turret();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int, SDL_Rect Target);
    SDL_Rect spriteTurret;

};
