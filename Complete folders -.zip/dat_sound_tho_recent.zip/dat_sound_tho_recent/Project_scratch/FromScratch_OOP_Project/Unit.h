#pragma once
#include "Object.h"
#include "TextureManager.h"

class Unit : public Object
{
protected:
    int HP;
    char direction;
    bool ally;
    bool alive;
public:
    Unit();
    virtual ~Unit();
    virtual bool GetAlive();
    virtual void attack(int, int);

};
