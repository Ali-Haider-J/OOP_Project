#pragma once
#include "Object.h"
#include "TextureManager.h"

class Elevator : public Object
{
public:
     Elevator(int,int);
    ~Elevator();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int, SDL_Rect Target);
private:
    SDL_Rect elevator[ 1 ];
    bool active;
protected:
    SDL_Texture* elevatorTex;
};

