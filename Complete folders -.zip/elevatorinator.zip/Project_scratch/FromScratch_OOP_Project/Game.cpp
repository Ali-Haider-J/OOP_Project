#include "Game.h"
#include "TextureManager.h"
#include "Player.h"
#include "Room.h"
#include "EnemyFactory.h"
#include "Wall.h"
#include "SDL_mixer.h"
#include "Queue.h"
#include "Button.h"
#include "Instruction.h"
#include "Elevator.h"

Object* player = NULL;
Player* Player::instance = NULL;
EnemyFactory* enemyFactory = NULL;
//Object* objEnemy = NULL;
Object* objRoom = NULL;
Object* objButton = NULL;
Object* objButton2 = NULL;
Object* objButton3 = NULL;
Object* objButton4 = NULL;
Object* objButtonHover = NULL;
Object* objInstruction = NULL;
Object* objElevator = NULL;

SDL_Event e;
long int frame = 0;
bool ESC = false;

SDL_Renderer* Game::renderer = NULL;
Queue* q = NULL;
Queue* Queue::instance = NULL;


Game::Game()
{

}
Game::~Game()
{


}

void Game::init(const char* title, int xpos, int ypos, int width, int height, bool fullscreen)
{

    if ( SDL_Init(SDL_INIT_EVERYTHING) == 0 )
    {
        std::cout << "Subsystems initialized!" << std::endl;
        window = SDL_CreateWindow( title, xpos, ypos, width, height, false );
        {
            std::cout << "Window created!" << std::endl;
        }
        renderer = SDL_CreateRenderer(window, -1, 0);
        if (renderer)
        {
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            std::cout << "Renderer created!" << std::endl;

        }
        isRunning = true;
    }

    else
    {
        isRunning = false;
    }


   player = Player::getInstance();
   objRoom = new Room();
   enemyFactory = new EnemyFactory();
   q = Queue::getInstance();

   Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 4, 2048 );
    gMusic = Mix_LoadMUS( "sound/battle.wav" );
    if( gMusic == NULL )
    {
        std::cout << "Failed to load music! SDL_mixer Error: %s\n" << Mix_GetError() << std::endl;
    }
    Mix_PlayMusic( gMusic, -1 );

   //objEnemy = enemyFactory->getEnemy("EnemyOne", 200, 2200);

   objButton = new Button(0,(1024/2)-100,(768/2)-60);
   objButton2 = new Button(1,(1024/2)-100,768/2);
   objButton3 = new Button(2,(1024/2)-100,(768/2)+60);
   objButton4 = new Button(3,(1024/2)-100,(768/2)+120);
   objButtonHover = new Button (4,(1024/2)-150,(768/2)-90);
   objInstruction = new Instruction ();

    q->Enqueue(objRoom);
    objElevator = new Elevator(1254, 2080);
   // enemy = new EnemyOne(200, 2200);
}

void Game::handleEvents()
{

    SDL_RenderPresent(renderer);
    SDL_Event event;
    SDL_PollEvent(&event);

    player->setIdle(true);
    player->setRightMov(false);
    player->setLeftMov(false);
    player->setUpMov(false);
    player->setDownMov(false);
    objButtonHover->setUpMov(false);
    objButtonHover->setDownMov(false);
    objButtonHover->setClicked(false);
   // player->setAttack(false);

    while( SDL_PollEvent( &e ) != 0 )   //Handle events on queue
    {
        //User requests quit
        if( e.type == SDL_QUIT)
        {
            isRunning = false;
        }
    }


    const Uint8* currentKeyStates = SDL_GetKeyboardState( NULL );

        if(currentKeyStates[ SDL_SCANCODE_RIGHT ] & player->getActive())
        {
            player->setIdle(false);
            player->setRightMov(true);
            player->setDownMov(false);
            player->setUpMov(false);
            player->setLeftMov(false);
        }

        if(currentKeyStates[ SDL_SCANCODE_LEFT ] & player->getActive())
        {
            player->setIdle(false);
            player->setLeftMov(true);
            player->setDownMov(false);
            player->setRightMov(false);
            player->setUpMov(false);
        }

        if(currentKeyStates[ SDL_SCANCODE_UP ] & player->getActive())
        {
            player->setIdle(false);
            player->setUpMov(true);
            player->setDownMov(false);
            player->setLeftMov(false);
            player->setRightMov(false);
            objButtonHover->setUpMov(true);
            objButtonHover->setDownMov(false);
        }

        if(currentKeyStates[ SDL_SCANCODE_DOWN ] & player->getActive())
        {
            player->setIdle(false);
            player->setDownMov(true);
            player->setLeftMov(false);
            player->setUpMov(false);
            player->setRightMov(false);
            objButtonHover->setUpMov(false);
            objButtonHover->setDownMov(true);
        }

        if(currentKeyStates[ SDL_SCANCODE_UP ] & currentKeyStates[ SDL_SCANCODE_RIGHT ] & player->getActive())
        {
            player->setIdle(false);
            player->setLeftMov(false);
            player->setUpMov(true);
            player->setRightMov(true);
            player->setDownMov(false);
        }
        if(currentKeyStates[ SDL_SCANCODE_UP ] & currentKeyStates[ SDL_SCANCODE_LEFT ] & player->getActive())
        {
            player->setIdle(false);
            player->setLeftMov(true);
            player->setUpMov(true);
            player->setRightMov(false);
            player->setDownMov(false);
        }
        if(currentKeyStates[ SDL_SCANCODE_DOWN ] & currentKeyStates[ SDL_SCANCODE_LEFT ] & player->getActive())
        {
            player->setIdle(false);
            player->setDownMov(true);
            player->setLeftMov(true);
            player->setUpMov(false);
            player->setRightMov(false);
        }
        if(currentKeyStates[ SDL_SCANCODE_DOWN ] & currentKeyStates[ SDL_SCANCODE_RIGHT ] & player->getActive())
        {
            player->setIdle(false);
            player->setDownMov(true);
            player->setLeftMov(false);
            player->setUpMov(false);
            player->setRightMov(true);
        }

        if(currentKeyStates[ SDL_SCANCODE_Z ] & player->getActive() & objButtonHover->getNewGame())
        {
            player->setIdle(false);
            player->setAttack(true);
        }
        if(currentKeyStates[ SDL_SCANCODE_X ] & player->getActive() & ((player->getStamina()) >= 25) & objButtonHover->getNewGame())
        {
            player->setIdle(false);
            player->setDodge(true);
        }

        if (currentKeyStates[ SDL_SCANCODE_RETURN ])
        {
            objButtonHover->setClicked(true);
        }

        if (objButtonHover->getQuit())
            isRunning = false;

        if (currentKeyStates[ SDL_SCANCODE_ESCAPE ])
        {
            objButtonHover->setInstruction(false);
        }
}

void Game::update()
{

    SDL_RenderPresent(renderer);



    SDL_Rect tempRect;
    tempRect = player->camera();
    if (!objButtonHover->getNewGame() & !objButtonHover->getInstruction())
    {
        objButton->Update(frame, tempRect, 2, 2, player->getHitbox());
        objButton2->Update(frame, tempRect, 2, 2, player->getHitbox());
        objButton3->Update(frame, tempRect, 2, 2, player->getHitbox());
        objButton4->Update(frame, tempRect, 2, 2, player->getHitbox());
        objButtonHover->Update(frame, tempRect, 2, 2, player->getHitbox());
    }

    else if (objButtonHover->getInstruction())
    {
        objInstruction->Update(frame, tempRect, 2, 2, player->getHitbox());
    }
    else if (objButtonHover->getNewGame())
    {
        q->Move(frame, tempRect, player->getX(), player->getY(), player->getHitbox());
        player->Update(frame, tempRect,  player->getX(), player->getY(), player->getHitbox());
        //player->setHit(objEnemy->getHit());
        objElevator -> Update(frame, tempRect,  0, 0, player->getHitbox());
    }
    frame++;
}

void Game::render()
{
    SDL_RenderClear(renderer);
    if (!objButtonHover->getNewGame() & !objButtonHover->getInstruction())
    {
        objButton->draw();
        objButton2->draw();
        objButton3->draw();
        objButton4->draw();
        objButtonHover->draw();
    }
    else if (objButtonHover->getInstruction())
    {
        objInstruction->draw();
    }
    else
    {
        q->Draw();
        objElevator->draw();
        player->draw();
    }
}

void Game::clean()
{
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
    Mix_FreeMusic( gMusic );
    gMusic = NULL;
    SDL_Quit();
    std::cout << "Game cleaned" << std::endl;
}

Game* Game::getInstance()
{
    if (instance == NULL)
        instance = new Game();
    return instance;
}

