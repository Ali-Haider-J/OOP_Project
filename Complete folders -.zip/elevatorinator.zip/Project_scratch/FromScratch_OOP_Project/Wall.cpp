#include "Wall.h"

Wall::Wall()
{
     this->x = 0;
     this->y = 0;
     destRect.x = destRect.y = 0;
     wallTex =  TextureManager::LoadTexture("Images/boundary_hidden.png");
     hit = false;
}


Wall::~Wall()
{


}


void Wall::draw()
{

     SDL_RenderCopyEx(Game::renderer, wallTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);

}

void Wall::Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target)
{


}
