#ifndef ELEVATOR_H
#define ELEVATOR_H


class Elevator
{
    public:
        Elevator();
        virtual ~Elevator();

    protected:

    private:
};

#endif // ELEVATOR_H
