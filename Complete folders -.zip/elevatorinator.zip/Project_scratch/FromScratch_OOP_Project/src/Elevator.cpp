#include "Elevator.h"

Elevator::Elevator()
{
    //ctor
}

Elevator::~Elevator()
{
    //dtor
}
