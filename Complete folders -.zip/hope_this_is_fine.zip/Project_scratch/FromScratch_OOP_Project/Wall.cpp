#include "Wall.h"

Wall::Wall()
{
     x = 0;
     y = 0;
     near = false;
     wallTex =  TextureManager::LoadTexture("Images/1.png");
     hit = false;
}


Wall::~Wall()
{


}


void Wall::draw()
{

     SDL_RenderCopyEx(Game::renderer, wallTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);

}

void Wall::Update(long int frame, SDL_Rect tempRect)
{
    x = tempRect.x;
    y = tempRect.y;

    if (destRect.x >= 365)
    {
       // destRect.x = 378;
        hit = true;
    }
    else
        hit = false;

    if (destRect.x >= 360 & destRect.x < 365 )
        reached = true;
    else
        reached = false;

    if (destRect.x >= 350 & destRect.x < 365 & !reached)
        there = true;
    else
        there = false;

    if (destRect.x >= 310 & destRect.x < 365 & !there)
        reaching = true;
    else
        reaching = false;

    if (destRect.x >= 270 & destRect.x < 365 & !reaching)
        nearly = true;
    else
        nearly = false;

    if (destRect.x >= 250 & destRect.x < 365 & !nearly)
        mid = true;
    else
        mid = false;

    if (destRect.x >= 200 & destRect.x < 363 & !mid)// & !nearly & x > -40)
    {
        near = true;
    }
    else
        near = false;





    srcRect.h = 250;
    srcRect.w = 45;
    srcRect.x = 0;
    srcRect.y = 0;
    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x = destRect.x + x;
    destRect.y = destRect.y + y;


    std::cout << "Near is:" << near << std::endl;
    std::cout << "Hit is: " << hit << std::endl;
    std::cout << "Wall x is:" << destRect.x << std::endl;

    std::cout << "Wall y is:" << destRect.y << std::endl;


   /* if (speedX == 0)
    {
        destRect.x = 20;
    }
    if (speedX == 0)
    {
        destRect.x = -20;
    }*/
    //destRect = camera(x, y, 2, speedX, speedY);
}
