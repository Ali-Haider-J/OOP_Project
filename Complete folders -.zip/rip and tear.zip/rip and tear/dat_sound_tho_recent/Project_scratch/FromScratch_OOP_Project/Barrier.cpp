#include "Barrier.h"

Barrier::Barrier(int x, int y, int type)
{
    this->hitU = this->hitL = false;
    this->x = x;
    this->y = y;
    this->hitbox.x = x;
    this->hitbox.y = y;
    this->hitbox.w = 60;
    this->hitbox.h = 126;
    this->type = type;
    this->objTexture = TextureManager::LoadTexture("Images/main_ss.png");
}

Barrier::~Barrier()
{

}

void Barrier::draw()
{
    SDL_RenderCopyEx(Game::renderer, objTexture, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);
    //SDL_RenderDrawRect( Game::renderer, &this->hitbox );
}

void Barrier::Update(long int frame, SDL_Rect tempRect, int, int, SDL_Rect Target)
{
        //WALL_LOCKED
        //frame 0
        spriteClips_locked[0].x = 79;
        spriteClips_locked[0].y = 829;
        spriteClips_locked[0].w = 30;
        spriteClips_locked[0].h = 63;

        //WALL_OPEN
        //frame 0
        spriteClips_open[0].x = 54;
        spriteClips_open[0].y = 830;
        spriteClips_open[0].w = 25;
        spriteClips_open[0].h = 63;

    srcRect = spriteClips_locked[frame%1];

    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x = tempRect.x + x;
    destRect.y = tempRect.y + y;

    hitbox.x = destRect.x;
    hitbox.y = destRect.y;


    if ((((hitbox.x + hitbox.w > Target.x + Target.w) & (hitbox.x < Target.x + Target.w)) or ((hitbox.x + hitbox.w < Target.x + Target.w) & (hitbox.x > Target.x)) or ((hitbox.x + hitbox.w < Target.x + Target.w) & (hitbox.x + hitbox.w > Target.x )))
        & (((hitbox.y + hitbox.h >= Target.y + Target.h) & (hitbox.y < Target.y + Target.h)) or ((hitbox.y + hitbox.h >= Target.y + Target.h) & (hitbox.y < Target.y)) or ((hitbox.y + hitbox.h <= Target.y + Target.h) & (hitbox.y + hitbox.h > Target.y ))))
    {
       //if (type == 1)
            this->hitU = true;
            this->hitL = true;
         std::cout << "-------------------------------HIT WALL--------------------" << std::endl;
    }
    else
    {
        this->hitU = false;
        this->hitL = false;
    }

}

bool Barrier::getHitL()
{
    return hitL;
}

bool Barrier::getHitU()
{
    return hitU;
}

int Barrier::getY()
{
    return this->y;
}
