#include "bullet.h"

Bullet::Bullet(int x, int y)
{
    this->hit = false;
    this-> x = x;
    this-> y = y;
    this->hitbox.x = x;
    this->hitbox.y = y ;
    this->hitbox.w = 72;
    this->hitbox.h = 35;
    this->bulletTex = TextureManager::LoadTexture("Images/main_ss.png");
    SDL_Init( SDL_INIT_AUDIO );
    Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 2, 2048 );
    gburn = Mix_LoadWAV( "sound/burn.wav" );
    indFrame = 0;
}

Bullet::~Bullet()
{
    Mix_FreeChunk( gburn );
    gburn = NULL;
    Mix_Quit();
}

void Bullet::draw()
{
    SDL_RenderCopyEx(Game::renderer, bulletTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_HORIZONTAL);
    //SDL_RenderDrawRect( Game::renderer, &this->hitbox );
}

bool Bullet::getHit()
{
    return hit;
}

void Bullet::Update(long int frame, SDL_Rect tempRect, int, int, SDL_Rect Target)
{
        hit = false;
        {
            //BULLET
            //frame 0
            spriteBullets[ 0 ].x = 200;
            spriteBullets[ 0 ].y = 123;
            spriteBullets[ 0 ].w = 18;
            spriteBullets[ 0 ].h = 14;

            //frame 1
            spriteBullets[ 1 ].x = 200;
            spriteBullets[ 1 ].y = 123;
            spriteBullets[ 1 ].w = 18;
            spriteBullets[ 1 ].h = 14;

            //frame 2
            spriteBullets[ 2 ].x = 220;
            spriteBullets[ 2 ].y = 123;
            spriteBullets[ 2 ].w = 18;
            spriteBullets[ 2 ].h = 14;

            //frame 3
            spriteBullets[ 3 ].x = 220;
            spriteBullets[ 3 ].y = 123;
            spriteBullets[ 3 ].w = 18;
            spriteBullets[ 3 ].h = 14;

            //frame 4
            spriteBullets[ 4 ].x = 243;
            spriteBullets[ 4 ].y = 123;
            spriteBullets[ 4 ].w = 16;
            spriteBullets[ 4 ].h = 14;

            //frame 5
            spriteBullets[ 5 ].x = 243;
            spriteBullets[ 5 ].y = 123;
            spriteBullets[ 5 ].w = 16;
            spriteBullets[ 5 ].h = 14;

            //frame 6
            spriteBullets[ 6 ].x = 263;
            spriteBullets[ 6 ].y = 123;
            spriteBullets[ 6 ].w = 16;
            spriteBullets[ 6 ].h = 14;

            //frame 7
            spriteBullets[ 7 ].x = 263;
            spriteBullets[ 7 ].y = 123;
            spriteBullets[ 7 ].w = 16;
            spriteBullets[ 7 ].h = 14;

            //frame 8
            spriteBullets[ 8 ].x = 283;
            spriteBullets[ 8 ].y = 123;
            spriteBullets[ 8 ].w = 18;
            spriteBullets[ 8 ].h = 14;

            //frame 9
            spriteBullets[ 9 ].x = 283;
            spriteBullets[ 9 ].y = 123;
            spriteBullets[ 9 ].w = 18;
            spriteBullets[ 9 ].h = 14;

            //frame 10
            spriteBullets[ 10 ].x = 305;
            spriteBullets[ 10 ].y = 123;
            spriteBullets[ 10 ].w = 17;
            spriteBullets[ 10 ].h = 14;

            //frame 11
            spriteBullets[ 11 ].x = 305;
            spriteBullets[ 11 ].y = 123;
            spriteBullets[ 11 ].w = 17;
            spriteBullets[ 11 ].h = 14;

            //frame 12
            spriteBullets[ 12 ].x = 326;
            spriteBullets[ 12 ].y = 121;
            spriteBullets[ 12 ].w = 13;
            spriteBullets[ 12 ].h = 14;

            //frame 13
            spriteBullets[ 13 ].x = 326;
            spriteBullets[ 13 ].y = 121;
            spriteBullets[ 13 ].w = 13;
            spriteBullets[ 13 ].h = 14;

            //frame 14
            spriteBullets[ 14 ].x = 344;
            spriteBullets[ 14 ].y = 120;
            spriteBullets[ 14 ].w = 15;
            spriteBullets[ 14 ].h = 14;

            //frame 15
            spriteBullets[ 15 ].x = 344;
            spriteBullets[ 15 ].y = 120;
            spriteBullets[ 15 ].w = 15;
            spriteBullets[ 15 ].h = 14;

            //frame 16
            spriteBullets[ 16 ].x = 367;
            spriteBullets[ 16 ].y = 120;
            spriteBullets[ 16 ].w = 12;
            spriteBullets[ 16 ].h = 14;

            //frame 17
            spriteBullets[ 17 ].x = 367;
            spriteBullets[ 17 ].y = 120;
            spriteBullets[ 17 ].w = 12;
            spriteBullets[ 17 ].h = 14;

            //frame 18
            spriteBullets[ 18 ].x = 391;
            spriteBullets[ 18 ].y = 120;
            spriteBullets[ 18 ].w = 9;
            spriteBullets[ 18 ].h = 14;

            //frame 19
            spriteBullets[ 19 ].x = 391;
            spriteBullets[ 19 ].y = 120;
            spriteBullets[ 19 ].w = 9;
            spriteBullets[ 19 ].h = 14;
        }
    srcRect = spriteBullets[indFrame];
    destRect.h = srcRect.h * 4;
    destRect.w = srcRect.w * 4;
    destRect.x = tempRect.x + x;
    destRect.y = tempRect.y + y;

    indFrame++;

    x -= 10;

    if (indFrame == 20)
        indFrame = 0;

    if (x == 3000)
        x = 3200;
    hitbox.x = destRect.x;
    hitbox.y = destRect.y + 8;
    if (indFrame >= 13 & indFrame <= 18)
    {
        hitbox.h = 46;
        hitbox.w = 50;
    }
    else
        hitbox.h = 35;

    if ((((hitbox.x + hitbox.w > Target.x + Target.w) & (hitbox.x < Target.x + Target.w)) or ((hitbox.x + hitbox.w < Target.x + Target.w) & (hitbox.x > Target.x)) or ((hitbox.x + hitbox.w < Target.x + Target.w) & (hitbox.x + hitbox.w > Target.x )))
        & (((hitbox.y + hitbox.h >= Target.y + Target.h) & (hitbox.y < Target.y + Target.h)) or ((hitbox.y + hitbox.h >= Target.y + Target.h) & (hitbox.y < Target.y)) or ((hitbox.y + hitbox.h <= Target.y + Target.h) & (hitbox.y + hitbox.h > Target.y ))))
    {
        Mix_HaltChannel(-1);
        Mix_PlayChannel( -1, gburn, 0 );
        this->hit = true;
    }
}
