#include "Elevator.h"

Elevator::Elevator(int x, int y)
{
    this->active = false;
    this->x = x;
    this->y = y;
    elevatorTex =  TextureManager::LoadTexture("Images/main_ss.png");
    hitbox.x = x;
    hitbox.y = y;
    hitbox.w = 66 * 2;
    hitbox.h = 60 * 2;
}

Elevator::~Elevator()
{

}

void Elevator::draw()
{
    SDL_RenderCopyEx(Game::renderer, elevatorTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);
    //SDL_RenderDrawRect( Game::renderer, &this->hitbox );
}

void Elevator::Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target)
{
    //Elevator
    elevator[ 0 ].x = 69;
    elevator[ 0 ].y = 993;
    elevator[ 0 ].w = 96;
    elevator[ 0 ].h = 97;

    srcRect = elevator[0];

    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x = tempRect.x + x;
    destRect.y = tempRect.y + y;

    hitbox.x = destRect.x + 30;
    hitbox.y = destRect.y;

    if ((((hitbox.x + hitbox.w > Target.x + Target.w) & (hitbox.x < Target.x + Target.w)) or ((hitbox.x + hitbox.w < Target.x + Target.w) & (hitbox.x > Target.x)) or ((hitbox.x + hitbox.w < Target.x + Target.w) & (hitbox.x + hitbox.w > Target.x )))
    & (((hitbox.y + hitbox.h >= Target.y + Target.h) & (hitbox.y < Target.y + Target.h)) or ((hitbox.y + hitbox.h >= Target.y + Target.h) & (hitbox.y < Target.y)) or ((hitbox.y + hitbox.h <= Target.y + Target.h) & (hitbox.y + hitbox.h > Target.y ))))
    {
        active = true;
        std::cout << "-------------------------------HIT X & HIT Y--------------------" << std::endl;
    }

    if(active && this->y >= 1400)
    {
        y -= 12;
    }
}
