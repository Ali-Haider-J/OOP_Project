#include "turret.h"

Turret::Turret(int x, int y)
{

    this->x = x;
    this->y = y;
    this->objTexture = TextureManager::LoadTexture("Images/main_ss.png");
}

Turret::~Turret()
{

}

void Turret::draw()
{
    SDL_RenderCopyEx(Game::renderer, objTexture, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);
}

void Turret::Update(long int frame, SDL_Rect tempRect, int , int , SDL_Rect Target)
{

    spriteTurret.x = 0;
    spriteTurret.y = 990;
    spriteTurret.w = 69;
    spriteTurret.h = 43;

    srcRect = spriteTurret;
    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x = tempRect.x + x;
    destRect.y = tempRect.y + y;

}
