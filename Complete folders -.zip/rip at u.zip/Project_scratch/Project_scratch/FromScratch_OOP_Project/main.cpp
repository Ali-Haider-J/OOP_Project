#include "Game.h"

Game* game = NULL;
Game* Game::instance = NULL;

int main(int argc, char* argv[])
{

    const int FPS = 24;
    const int frameDelay = 1000 / FPS;

    Uint32 frameStart;
    int frameTime;

    game = Game::getInstance();
    game->init("Rip and Tear", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1024, 768, false);
    while (game->running())
    {
        frameStart = SDL_GetTicks();

        game->handleEvents();
        game->update();
        game->render();

        frameTime = SDL_GetTicks() - frameStart;

        if (frameDelay > frameTime)
        {
            SDL_Delay(frameDelay - frameTime);
        }

    }
    game->clean();
    return 0;

}
