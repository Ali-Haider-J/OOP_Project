#pragma once
#include "Menu.h"

class Button
{
public:
    Button();
    ~Button();
    bool clicked;
};
