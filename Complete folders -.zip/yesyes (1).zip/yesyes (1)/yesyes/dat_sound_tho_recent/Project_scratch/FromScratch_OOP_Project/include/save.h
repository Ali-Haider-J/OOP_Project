#ifndef SAVE_H
#define SAVE_H


class save
{
    public:
        save();
        virtual ~save();

    protected:

    private:
        spriteClips_animation[0]
};

#endif // SAVE_H
