#include "Game.h"
#include "TextureManager.h"
#include "Player.h"
#include "Room.h"
#include "EnemyFactory.h"
#include "Wall.h"

//Object* objPlayer;
Player* player;
Player* Player::instance = NULL;
//Room* room = NULL;
EnemyFactory* enemyFactory = NULL;
Enemy* enemy = NULL;
Object* objEnemy = NULL;
Object* objRoom = NULL;
Object* objWall = NULL;
SDL_Event e;
long int frame = 0;
SDL_Renderer* Game::renderer = NULL;


Game::Game()
{

}
Game::~Game()
{


}

void Game::init(const char* title, int xpos, int ypos, int width, int height, bool fullscreen)
{

    if ( SDL_Init(SDL_INIT_EVERYTHING) == 0 )
    {
        std::cout << "Subsystems initialized!" << std::endl;
        window = SDL_CreateWindow( title, xpos, ypos, width, height, false );
        {
            std::cout << "Window created!" << std::endl;
        }
        renderer = SDL_CreateRenderer(window, -1, 0);
        if (renderer)
        {
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            std::cout << "Renderer created!" << std::endl;

        }
        isRunning = true;
    }

    else
    {
        isRunning = false;
    }


   player = Player::getInstance();
   objRoom = new Room();
   enemyFactory = new EnemyFactory();

   objWall = new Wall();
   /// enemy = enemyFactory->getEnemy("EnemyOne", 200, 2200);
   // enemy = new EnemyOne(200, 2200);
}

void Game::handleEvents()
{

    SDL_RenderPresent(renderer);
    SDL_Event event;
    SDL_PollEvent(&event);

    player->setIdle(true);
    player->setRightMov(false);
    player->setLeftMov(false);
    player->setUpMov(false);
    player->setDownMov(false);
   /// player->setAttack(false);

    while( SDL_PollEvent( &e ) != 0 )   //Handle events on queue
    {
        //User requests quit
        if( e.type == SDL_QUIT )
        {
            isRunning = false;
        }
//        if (e.type == SDL_KEYDOWN)
//        {
//             if (e.key.keysym.sym == SDLK_z & player->getActive())
//                {
//                     player->setIdle(false);
//                     player->setAttack(true);
//                     std::cout << "ATTACKED ---------------------->" << std::endl;
//                     std::cout << "ATTACKED ---------------------->" << std::endl;
//                     std::cout << "ATTACKED ---------------------->" << std::endl;
//                     std::cout << "ATTACKED ---------------------->" << std::endl;std::cout << "ATTACKED ---------------------->" << std::endl;std::cout << "ATTACKED ---------------------->" << std::endl;
//                     std::cout << "ATTACKED ---------------------->" << std::endl;
//                     std::cout << "ATTACKED ---------------------->" << std::endl;
//                }
//        }


    }


    const Uint8* currentKeyStates = SDL_GetKeyboardState( NULL );

        if(currentKeyStates[ SDL_SCANCODE_RIGHT ] & player->getActive())
        {
            player->setIdle(false);

            player->setRightMov(true);
            player->setDownMov(false);
            player->setUpMov(false);
            player->setLeftMov(false);

        }

        if(currentKeyStates[ SDL_SCANCODE_LEFT ] & player->getActive())
        {
            player->setIdle(false);

            player->setLeftMov(true);
            player->setDownMov(false);
            player->setRightMov(false);
            player->setUpMov(false);


        }

        if(currentKeyStates[ SDL_SCANCODE_UP ] & player->getActive())
        {
            //plane->downRight = true;
            player->setIdle(false);

            player->setUpMov(true);
            player->setDownMov(false);
            player->setLeftMov(false);
            player->setRightMov(false);
            //cout << plane->up << endl;

        }

        if(currentKeyStates[ SDL_SCANCODE_DOWN ] & player->getActive())
        {
            //plane->upLeft = true;
            player->setIdle(false);
            player->setDownMov(true);
            player->setLeftMov(false);
            player->setUpMov(false);
            player->setRightMov(false);
            //cout << plane->up << endl;

        }

        if(currentKeyStates[ SDL_SCANCODE_UP ] & currentKeyStates[ SDL_SCANCODE_RIGHT ] & player->getActive())
        {
            //plane->upLeft = true;
            player->setIdle(false);

            player->setLeftMov(false);
            player->setUpMov(true);
            player->setRightMov(true);
            player->setDownMov(false);
            //cout << plane->up << endl;

        }
        if(currentKeyStates[ SDL_SCANCODE_UP ] & currentKeyStates[ SDL_SCANCODE_LEFT ] & player->getActive())
        {
            //plane->upLeft = true;
            player->setIdle(false);

            player->setLeftMov(true);
            player->setUpMov(true);
            player->setRightMov(false);
            player->setDownMov(false);
            //cout << plane->up << endl;

        }
        if(currentKeyStates[ SDL_SCANCODE_DOWN ] & currentKeyStates[ SDL_SCANCODE_LEFT ] & player->getActive())
        {
            //plane->upLeft = true;
            player->setIdle(false);
            player->setDownMov(true);
            player->setLeftMov(true);
            player->setUpMov(false);
            player->setRightMov(false);
            //cout << plane->up << endl;

        }
        if(currentKeyStates[ SDL_SCANCODE_DOWN ] & currentKeyStates[ SDL_SCANCODE_RIGHT ] & player->getActive())
        {
            //plane->upLeft = true;
            player->setIdle(false);
            player->setDownMov(true);
            player->setLeftMov(false);
            player->setUpMov(false);
            player->setRightMov(true);
            //cout << plane->up << endl;

        }
        if(currentKeyStates[ SDL_SCANCODE_Z ] & player->getActive())
        {
            player->setIdle(false);
            player->setAttack(true);
        }


}

void Game::update()
{

    SDL_RenderPresent(renderer);

    SDL_Rect tempRect;
    tempRect = player->camera();
    objWall->Update(frame, tempRect, player->newX, player->newY);
    player->hitWall(objWall->hitL, objWall->hitU, objWall->hitR, objWall->hitD);

    player->Update(frame, tempRect,  player->newX, player->newY);
    objRoom->Update(frame, tempRect, player->newX, player->newY);

  ///  enemy->Update(frame, tempRect, player->getX(), player->getY());
    frame++;
}

void Game::render()
{
    SDL_RenderClear(renderer);
    objRoom->draw();
    player->draw();
    objWall->draw();
 ///   enemy->draw();
}

void Game::clean()
{
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
    SDL_Quit();
    std::cout << "Game cleaned" << std::endl;
}

Game* Game::getInstance()
{
    if (instance == NULL)
        instance = new Game();
    return instance;
}

