#pragma once
#include "Button.h"

Button::Button()
{
    this->x=this->y=0;

    this->active = true;
//        clicked= false;
    buttonTex =  TextureManager::LoadTexture("Images/main_ss.png");
    counterUp = 1;
    counterDown = 1;

}
Button::Button(int buttonChoice, int x, int y)
{
    this->x = x;

    this->y = y;
//        clicked= false;
    buttonTex =  TextureManager::LoadTexture("Images/main_ss.png");

    this->buttonChoice = buttonChoice;
    counterUp = 1;
    counterDown = 1;

}

Button::~Button()
{


}

void Button::draw()
{
     SDL_RenderCopyEx(Game::renderer, buttonTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);
}


void Button::Update(long int frame, SDL_Rect tempRect, int a, int b)
{

            //new game
        buttonOptions[ 0 ].x = 171;
        buttonOptions[ 0 ].y = 1666;
        buttonOptions[ 0 ].w = 91;
        buttonOptions[ 0 ].h = 14;

        //load game
        buttonOptions[ 1 ].x = 69;
        buttonOptions[ 1 ].y = 1666;
        buttonOptions[ 1 ].w = 103;
        buttonOptions[ 1 ].h = 14;

        //Instructions
        buttonOptions[ 2 ].x = 125;
        buttonOptions[ 2 ].y = 1637;
        buttonOptions[ 2 ].w = 138;
        buttonOptions[ 2 ].h = 14;

        //Quit
        buttonOptions[ 3 ].x = 82;
        buttonOptions[ 3 ].y = 1637;
        buttonOptions[ 3 ].w = 44;
        buttonOptions[ 3 ].h = 31;

        //Hover
        buttonOptions[ 4 ].x = 262;
        buttonOptions[ 4 ].y = 1636;
        buttonOptions[ 4 ].w = 194;
        buttonOptions[ 4 ].h = 39;

    srcRect = buttonOptions[buttonChoice];
    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x =  x;
    destRect.y = y;

    if (upMov & this->active)// & counterUp > 0)
    {
        if (y > (768/2)-60)
        {
            //counterDown = 2;
            srcRect = buttonOptions [4];
            this->active = false;
            y = y-60;

        }
    }
    else if (downMov & this->active)// & counterDown > 0)
    {
        if (y < (768/2)+60)
        {
            //counterUp = 2;
            srcRect = buttonOptions [4];
            this->active = false;
            y = y+60;

        }
    }
    else
        this->active = true;

//    if (counterUp >= 2)
//        counterUp++;
//    if (counterDown >= 2)
//        counterDown++;
//    if (counterUp == 20)
//        counterUp = 0;
//    if (counterDown == 20)
//        counterDown = 0;

}

void Button::setUpMov(bool up)
{
    upMov = up;

}
void Button::setDownMov(bool down)
{
    downMov = down;
}
