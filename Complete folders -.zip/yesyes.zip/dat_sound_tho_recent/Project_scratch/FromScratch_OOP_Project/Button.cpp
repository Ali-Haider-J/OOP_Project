#include "Button.h"

Button::Button()
{
    this->x=this->y=0;

    this->active = true;
//        clicked= false;
    buttonTex =  TextureManager::LoadTexture("Images/main_ss.png");
    counter = 1;
    clicked = newGame = instruction = quit = false;

}
Button::Button(int buttonChoice, int x, int y)
{
    this->x = x;

    this->y = y;
//        clicked= false;
    buttonTex =  TextureManager::LoadTexture("Images/main_ss.png");

    this->buttonChoice = buttonChoice;
    counter = 1;
    clicked = newGame = instruction = quit = false;

}

Button::~Button()
{


}

void Button::draw()
{
     SDL_RenderCopyEx(Game::renderer, buttonTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);
}


void Button::Update(long int frame, SDL_Rect tempRect, int a, int b)
{

            //new game
        buttonOptions[ 0 ].x = 171;
        buttonOptions[ 0 ].y = 1666;
        buttonOptions[ 0 ].w = 91;
        buttonOptions[ 0 ].h = 14;

        //load game
        buttonOptions[ 1 ].x = 69;
        buttonOptions[ 1 ].y = 1666;
        buttonOptions[ 1 ].w = 102;
        buttonOptions[ 1 ].h = 14;

        //Instructions
        buttonOptions[ 2 ].x = 125;
        buttonOptions[ 2 ].y = 1637;
        buttonOptions[ 2 ].w = 137;
        buttonOptions[ 2 ].h = 14;

        //Quit
        buttonOptions[ 3 ].x = 82;
        buttonOptions[ 3 ].y = 1637;
        buttonOptions[ 3 ].w = 43;
        buttonOptions[ 3 ].h = 28;

        //Hover
        buttonOptions[ 4 ].x = 262;
        buttonOptions[ 4 ].y = 1636;
        buttonOptions[ 4 ].w = 193;
        buttonOptions[ 4 ].h = 39;

    srcRect = buttonOptions[buttonChoice];
    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x =  x;
    destRect.y = y;

    if (upMov & this->active)// & counterUp > 0)
    {
        if (y > (768/2)-60)
        {
            counter = 1;
            srcRect = buttonOptions [4];
            this->active = false;
            y = y-60;

        }
    }
    else if (downMov & this->active)// & counterDown > 0)
    {
        if (y < (768/2)+60)
        {
            counter = 1;
            srcRect = buttonOptions [4];
            this->active = false;
            y = y+60;

        }
    }
    else
        this->active = true;

    if (counter >= 1)
    {
        active = false;
        counter++;
    }

    if (counter == 5)
    {
        active = true;
        counter = 0;
    }
    if (srcRect == buttonOptions[4])
        std::cout << "hoverY is" << this->y << std::endl;
    if (clicked & (srcRect == buttonOptions[4]) & (y == 294))
    {
        newGame = true;
        std::cout << "newGAME" << std::endl;
    }
    else if (clicked & (srcRect == buttonOptions[4]) & (y == 354))
    {
        std::cout << "Load Game" << std::endl;
    }
    else if (clicked & (srcRect == buttonOptions[4]) & (y == 414))
    {
        instruction = true;
        std::cout << "Instructions" << std::endl;
    }
    else if (clicked & (srcRect == buttonOptions[4]) & (y == 474))
    {
        quit = true;
        std::cout << "QUIT!" << std::endl;
    }
}

void Button::setUpMov(bool up)
{
    upMov = up;

}
void Button::setDownMov(bool down)
{
    downMov = down;
}

void Button::setClicked(bool clicked)
{
    this->clicked = clicked;
}

bool Button::getNewGame()
{
    return newGame;
}

bool Button::getQuit()
{
    return quit;
}

bool Button::getInstruction()
{
    return instruction;
}

void Button::setInstruction(bool instruction)
{
    this->instruction = instruction;
}
