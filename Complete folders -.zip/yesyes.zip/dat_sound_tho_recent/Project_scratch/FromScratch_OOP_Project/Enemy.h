#pragma once
#include "Unit.h"

class Enemy : public Unit
{
protected:


public:
    Enemy();
    ~Enemy();
    virtual void draw() = 0;
    virtual void Update(long int frame, SDL_Rect tempRect, int, int) = 0;
    virtual void attack(int, int) = 0;
    void move() ;
    virtual int getX() = 0;
    virtual int getY() = 0;
    virtual void setX(float x) = 0;
    virtual void setY(float y) = 0;
    virtual void setUpMov(bool) = 0;
    virtual void setDownMov(bool) = 0;
    virtual void setRightMov(bool) = 0;
    virtual void setLeftMov(bool) = 0;
    virtual void setIdle(bool) = 0;
    virtual bool getActive() = 0;
    virtual void setAttack(bool) = 0;
    virtual SDL_Rect camera() = 0;
    virtual void hitWall(bool, bool, bool, bool) = 0;

};
