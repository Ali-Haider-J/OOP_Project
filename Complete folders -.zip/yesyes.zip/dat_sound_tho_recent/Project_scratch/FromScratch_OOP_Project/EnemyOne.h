#pragma once
#include "Enemy.h"
#include "Player.h"
#include "SDL_mixer.h"

class EnemyOne : public Enemy
{
private:
    int enemyX;
    int enemyY;
    SDL_Texture* EnemyOneTex;
    SDL_Rect spriteClips_spawn_animation[9];
    SDL_Rect spriteClips_enemy_eye_blink_right[7];
    SDL_Rect spriteClips_enemy_eye_blink_left[7];
    SDL_Rect spriteClips_enemy_move_right[3];
    SDL_Rect spriteClips_enemy_move_left[3];
    SDL_Rect spriteClips_enemy_move_up_right[5];
    SDL_Rect spriteClips_enemy_move_up_left[5];
    SDL_Rect spriteClips_enemy_move_down_right[5];
    SDL_Rect spriteClips_enemy_move_down_left[5];
    Mix_Chunk *gspawn = NULL;
    Mix_Chunk *gwhoosh = NULL;

    int delay;
    bool active;
    bool inMotion;
    int counter;
    int tempx;
    int tempy;
    int proximityX;
    int proximityY;
    bool spawned;


public:
    EnemyOne();
    EnemyOne(int posx, int posy);
    ~EnemyOne();
    int getX(){};
    int getY(){};
    void setX(float){};
    void setY(float){};
    void setUpMov(bool){};
    void setDownMov(bool){};
    void setRightMov(bool){};
    void setLeftMov(bool){};
    void setIdle(bool){};
    bool getActive(){};
    void hitWall(bool, bool, bool, bool){};
    void draw();
    SDL_Rect camera(){};
    void setAttack(bool){};
    void Update(long int frame, SDL_Rect tempRect, int, int);
    int attack_state;
    void attack(int, int);

};
