#pragma once
#include "Enemy.h"

class EnemyThree : public Enemy
{
private:
//    int enemyThreeX;
//    int enemyThreeY;
public:
    EnemyThree(int x, int y);
    ~EnemyThree();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int);
    void attack(int, int);

};
