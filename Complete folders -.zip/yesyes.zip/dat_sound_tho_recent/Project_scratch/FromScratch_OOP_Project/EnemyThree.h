#pragma once
#include "Enemy.h"

class EnemyThree : public Enemy
{
private:
    int enemyThreeX;
    int enemyThreeY;
public:
    EnemyThree(int x, int y);
    ~EnemyThree();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int);
    void attack(int, int);
    int getX(){};
    int getY(){};
    void setX(float){};
    void setY(float){};
    void setUpMov(bool){};
    void setDownMov(bool){};
    void setRightMov(bool){};
    void setLeftMov(bool){};
    void setIdle(bool){};
    bool getActive(){};
    void setAttack(bool){};
    SDL_Rect camera(){};
    void hitWall(bool, bool, bool, bool){};
};
