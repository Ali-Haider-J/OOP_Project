#pragma once
#include "Enemy.h"

class EnemyTwo : public Enemy
{
private:
    int enemyTwoX;
    int enemyTwoY;
public:
    EnemyTwo(int x, int y);
    ~EnemyTwo();
    void draw();
    int getX(){};
    int getY(){};
    void setX(float){};
    void setY(float){};
    void setUpMov(bool){};
    void setDownMov(bool){};
    void setRightMov(bool){};
    void setLeftMov(bool){};
    void setIdle(bool){};
    bool getActive(){};
    void Update(long int frame, SDL_Rect tempRect, int, int);
    void attack(int, int);
    void setAttack(bool){};
    SDL_Rect camera(){};
    void hitWall(bool, bool, bool, bool){};
};
