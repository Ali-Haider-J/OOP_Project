#pragma once
#include "Enemy.h"

class EnemyTwo : public Enemy
{
private:
//    int enemyTwoX;
//    int enemyTwoY;
public:
    EnemyTwo(int x, int y);
    ~EnemyTwo();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int);
    void attack(int, int);

};
