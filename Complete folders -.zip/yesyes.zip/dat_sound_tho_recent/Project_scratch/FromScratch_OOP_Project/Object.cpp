#include "Object.h"

Object::Object()
{


}

Object::~Object()
{


}

int Object::getX()
{


}

int Object::getY()
{

}

void Object::setX(float x)
{

}

void Object::setY(float y)
{

}

void Object::setUpMov(bool)
{

}

void Object::setDownMov(bool)
{

}

void Object::setRightMov(bool)
{


}

void Object::setLeftMov(bool)
{

}

void Object::setIdle(bool)
{

}

bool Object::getActive()
{

}

void Object::setAttack(bool)
{

}

SDL_Rect Object::camera()
{

}

void Object::Update(long int frame, SDL_Rect tempRect, int, int)
{


}

void Object::hitWall(bool, bool, bool, bool)
{

}

void Object::draw()
{


}
