#pragma once
#include <math.h>
#include <stdlib.h>
#include "SDL.h"

class Object
{
protected:
    bool solidX;
    bool solidY;
    bool solidL;
    bool solidD;
    SDL_Texture* objTexture;
    SDL_Rect srcRect, destRect;


public:

    bool hitD;
    bool hitL;
    bool hitR;
    bool hitU;
    bool hit;
    Object();
    ~Object();
    virtual int getX() = 0;
    virtual int getY() = 0;
//    void setSpeedX(float x);
//    void setSpeedY(float y);
//    float getSpeedX();
//    float getSpeedY();
    virtual void setX(float x) = 0;
    virtual void setY(float y) = 0;
    virtual void setUpMov(bool) = 0;
    virtual void setDownMov(bool) = 0;
    virtual void setRightMov(bool) = 0;
    virtual void setLeftMov(bool) = 0;
    virtual void setIdle(bool) = 0;
    virtual bool getActive() = 0;
    virtual void setAttack(bool) = 0;
    virtual SDL_Rect camera() = 0;
    //SDL_Rect camera(int x, int y, int zoom, int speedx, int speedy);
    virtual void draw() = 0;
    virtual void Update(long int frame, SDL_Rect tempRect, int, int) = 0;
    virtual void hitWall(bool, bool, bool, bool) = 0;

};
