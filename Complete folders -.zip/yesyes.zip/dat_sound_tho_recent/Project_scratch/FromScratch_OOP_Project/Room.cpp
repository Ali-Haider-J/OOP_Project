#include "Room.h"
#include "TextureManager.h"

Room::Room()
{

    wallR = false;
    wallL = false;
    roomNo = 1;
    roomTex =  TextureManager::LoadTexture("Images/map_layout.png");
    this->x = 0;
    this->y = 0;
}

Room::~Room()
{


}

void Room::draw()
{

     SDL_RenderCopyEx(Game::renderer, roomTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);

}

void Room::Update(long int frame, SDL_Rect tempRect, int a, int b)
{
    x = tempRect.x;
    y = tempRect.y;
    std::cout << "Room X is: -->" << x << std::endl;
    std::cout << "Room Y is: -->" << y << std::endl;
    //destRect = camera(x, y, 2, speedX, speedY);
/*
    if ( destRect.x < -1000 )//or x == 0)
    {
        wallR = true;
    }
    else
    {
        wallR = false;
    }

    if ( destRect.x > -20 )
    {
        wallL = true;
    }
    else
    {
        wallL = false;
    }
    if ( destRect.y > 0 )
    {
        wallU = true;
    }
    else
    {
        wallU = false;
    }
    if ( destRect.y < -750 )
    {
        wallD = true;
    }
    else
    {
        wallD = false;
    }
*/

    srcRect.h = 1300;
    srcRect.w = 1800;
    srcRect.x = srcRect.y = 0;
    destRect.h = srcRect.h * tempRect.h;
    destRect.w = srcRect.w * tempRect.h;
    destRect.x = tempRect.x;
    destRect.y = tempRect.y;


    //destRect = camera(x, y, 2, speedX, speedY);
}

bool Room::getWallR()
{
    return wallR;
}

bool Room::getWallL()
{
    return wallL;
}

bool Room::getWallU()
{
    return wallU;
}

bool Room::getWallD()
{
    return wallD;
}
