#pragma once
#include "Object.h"
#include "Game.h"

class Room : public Object
{
private:
    int roomX;
    int roomY;
    bool wallR;
    bool wallL;
    bool wallU;
    bool wallD;
    int roomNo;
public:
    Room();
    ~Room();
    bool getWallR();
    bool getWallL();
    bool getWallU();
    bool getWallD();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int);
    SDL_Texture* roomTex;
    int getX(){};
    int getY(){};
    void setX(float){};
    void setY(float){};
    void setUpMov(bool){};
    void setDownMov(bool){};
    void setRightMov(bool){};
    void setLeftMov(bool){};
    void setIdle(bool){};
    bool getActive(){};
    void setAttack(bool){};
    SDL_Rect camera(){};
    void hitWall(bool, bool, bool, bool){};

};
