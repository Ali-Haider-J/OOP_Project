#pragma once
#include "Object.h"

class Save : public Object
{
public:
    Save();
    ~Save();
    void save();
    void draw();
    void Update();
    SDL_Rect spriteClips_animation[22];
};
