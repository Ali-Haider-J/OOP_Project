#include "Wall.h"

Wall::Wall()
{
     this->x = 0;
     this->y = 0;
     destRect.x = destRect.y = 0;
     wallTex =  TextureManager::LoadTexture("Images/boundary_hidden.png");
     hit = false;
}


Wall::~Wall()
{


}


void Wall::draw()
{

     SDL_RenderCopyEx(Game::renderer, wallTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);

}

void Wall::Update(long int frame, SDL_Rect tempRect, int a, int b)
{

    x = tempRect.x;
    y = tempRect.y;

    int e = 0;//16;

    if (destRect.x >= 361)
    {
        hitL = true;
    }
    else if (destRect.x >= -578 & destRect.x <= -100 & destRect.y >= -1828 & destRect.y <= -1550)
    {
        hitL = true;
    }
    else if (destRect.x >= -780 & destRect.y >= -1640 & destRect.y <= -1016 & destRect.x <= -650)
    {
        hitL = true;
    }
    else if (destRect.x >= -750 & destRect.y <= -956 & destRect.y >= -1016 & destRect.x <= -618)
        hitL = true;
    else if (destRect.x >= -616 & destRect.x <= -444 & destRect.y >= -1000 & destRect.y <= 0)
        hitL = true;
    else if (destRect.x >= -1148 & destRect.x <= -1085 & destRect.y <= -225 & destRect.y >= -313)
        hitL = true;
    else if (destRect.x >= -1141 & destRect.x <= -1085 & destRect.y <= -416 & destRect.y >= -1010)
        hitL = true;
    else if (destRect.y >= -253 & destRect.x >= -1762 & destRect.x <= -1702)
        hitL = true;
    else if (destRect.x >= -2526 & destRect.x <= -2448 & destRect.y <= -190 & destRect.y >= -1082)
        hitL = true;
    else if (destRect.y >= -2000 & destRect.x >= -1593 & destRect.y <= -1030 & destRect.x <= -1300)
        hitL = true;
    else
        hitL = false;


    if (destRect.y >= -1721 and destRect.x >= -100 & destRect.y <= -1200)
    {
        hitU = true;
    }
    else if (destRect.x <= -6 & destRect.y >= -1850 & destRect.y <= -1200 & destRect.x >= -555)
    {
        hitU = true;
    }
    else if (destRect.x >= -760 & destRect.x <= -530 & destRect.y >= -1661 & destRect.y <= -1200)
    {
        hitU = true;
    }
    else if (destRect.x <= -884 & destRect.x >= -1090 & destRect.y >= -1661 & destRect.y <= -1200)
    {
        hitU = true;
    }
    else if (destRect.y >= -270 & destRect.x >= -1729 & destRect.y <= -240)
        hitU = true;
    else if (destRect.y >= -333 & destRect.x <= -1046 & destRect.x >= -1125)
        hitU = true;
    else if (destRect.x <= -1873 & destRect.y >= -270 & destRect.y <= -214 & destRect.x >= -2460)
        hitU = true;
    else if (destRect.y >= 45 & destRect.x >= -3000)
        hitU = true;
    else if (destRect.x <= -1400 & destRect.y >= -1105 & destRect.y <= -1065 & destRect.x >= -2498)
        hitU = true;
    else
    {
        hitU = false;
    }


    if (destRect.y < -2000)
    {
        hitD = true;
    }
    else if (destRect.x <= -885 & destRect.x >= -930 & destRect.y <= -1004 & destRect.y >= -1120)
        hitD = true;
    else if (destRect.x >= -785 & destRect.x <= -720 & destRect.y <= -1004 & destRect.y >= -1100)
        hitD = true;
    else if (destRect.x <= -925 & destRect.y <= -936 & destRect.y >= -1111 & destRect.x >= -1085)
        hitD = true;
    else if (destRect.x >= -731 & destRect.y <= -936 & destRect.y >= -1111 & destRect.x <= -555)
        hitD = true;
    else if (destRect.x <= -1046 & destRect.x >= -1125 & destRect.y <= -394 & destRect.y >= -427)
        hitD = true;
    else if (destRect.x <= -1120 & destRect.y <= -875 & destRect.y >= -1031 & destRect.x >= -2491)
        hitD = true;
    else if (destRect.y <= -167 & destRect.y >= -232 & destRect.x <= -1846 & destRect.x >= -2500)
        hitD = true;
    else if (destRect.y <= -1922 & destRect.y >= -2000 & destRect.x >= -3000 & destRect.x <= -1300)
        hitD = true;
    else
        hitD = false;

    if (destRect.x <= 9 & destRect.y >= -1828 & destRect.x >= -100)
    {
        hitR = true;
    }
    else if (destRect.x <= -1050 & destRect.y <= -1550 & destRect.x >= -1300)
        hitR = true;
    else if (destRect.x <= -860 & destRect.y >= -1640 & destRect.y <= -1016 & destRect.x >= -950)
        hitR = true;
    else if (destRect.x <= -904 & destRect.x >= -950 & destRect.y <= -956 & destRect.y >= -1016)
        hitR = true;
    else if (destRect.x <= -1022 & destRect.x >= -1084 & destRect.y >= -1000 & destRect.y <= -416)
        hitR = true;
    else if (destRect.x <= -1022 & destRect.x >= -1060 & destRect.y <= -225 & destRect.y >= -313)
        hitR = true;
    else if (destRect.x <= -2402 & destRect.x >= -2485 & destRect.y >= -928 & destRect.y <= -211)
        hitR = true;
    else if (destRect.y >= -253 & destRect.x <= -1846 & destRect.x >= -1899 & destRect.y <= -187)
        hitR = true;
    else if (destRect.x <= -2849)
        hitR = true;
    else
        hitR = false;

    srcRect.h = 250;
    srcRect.w = 45;
    srcRect.x = 0;
    srcRect.y = 0;
    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x = x;
    destRect.y = y;



    std::cout << "Wall x is:" << destRect.x << std::endl;

    std::cout << "Wall y is:" << destRect.y << std::endl;

}
