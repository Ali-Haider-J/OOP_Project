#pragma once
#include "Object.h"
#include "TextureManager.h"

class Wall : public Object
{
protected:
    int wallX;
    int wallY;
     SDL_Texture* wallTex;
     SDL_Rect hitbox;
public:
     Wall();
    ~Wall();
    int getX(){};
    int getY(){};
    void setX(float){};
    void setY(float){};
    void setUpMov(bool){};
    void setDownMov(bool){};
    void setRightMov(bool){};
    void setLeftMov(bool){};
    void setIdle(bool){};
    bool getActive(){};
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int);
    void setAttack(bool){};
    SDL_Rect camera(){};
    void hitWall(bool, bool, bool, bool){};
};
