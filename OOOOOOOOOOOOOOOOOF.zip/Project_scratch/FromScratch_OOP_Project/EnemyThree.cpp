#include "EnemyThree.h"

EnemyThree::EnemyThree(int posx, int posy)
{
    std::cout << "EnemyThree spawned!" << std::endl;
    x = posx;
    y = posy;

}

EnemyThree::~EnemyThree()
{

}

void EnemyThree::draw()
{


}

void EnemyThree::Update(long int frame, SDL_Rect tempRect, int a, int b)
{

}

void EnemyThree::attack(int x, int y)
{

}
