#include"Enemy.h"

Enemy::Enemy()
{

}

Enemy::~Enemy()
{
    cout<<"Enemy Deallocated"<<endl;
}

Enemy::Enemy(LTexture* image, float x, float y):Unit(image, x, y)
{
    spriteSheetTexture = image;


    //Frame 0
    spriteClips[ 0 ].x =  0;
    spriteClips[ 0 ].y = 66;
    spriteClips[ 0 ].w = 25;
    spriteClips[ 0 ].h = 25;

    //Frame 1
    spriteClips[ 1 ].x = 27;
    spriteClips[ 1 ].y = 66;
    spriteClips[ 1 ].w = 25;
    spriteClips[ 1 ].h = 25;

    //Frame 2
    spriteClips[ 2 ].x = 54;
    spriteClips[ 2 ].y = 66;
    spriteClips[ 2 ].w = 25;
    spriteClips[ 2 ].h = 25;

    //Frame 3
    spriteClips[ 3 ].x = 81;
    spriteClips[ 3 ].y = 66;
    spriteClips[ 3 ].w = 25;
    spriteClips[ 3 ].h = 25;

    //Frame 4
    spriteClips[ 4 ].x = 108;
    spriteClips[ 4 ].y = 66;
    spriteClips[ 4 ].w = 25;
    spriteClips[ 4 ].h = 25;

    //Frame 5
    spriteClips[ 5 ].x =  0;
    spriteClips[ 5 ].y = 66;
    spriteClips[ 5 ].w = 25;
    spriteClips[ 5 ].h = 25;

    //Frame 6
    spriteClips[ 6 ].x = 0;
    spriteClips[ 6 ].y = 66;
    spriteClips[ 6 ].w = 25;
    spriteClips[ 6 ].h = 25;

    //Frame 7
    spriteClips[ 7 ].x = 27;
    spriteClips[ 7 ].y = 66;
    spriteClips[ 7 ].w = 25;
    spriteClips[ 7 ].h = 25;

    //Frame 8
    spriteClips[ 8 ].x = 54;
    spriteClips[ 8 ].y = 66;
    spriteClips[ 8 ].w = 25;
    spriteClips[ 8 ].h = 25;

    //Frame 9
    spriteClips[ 9 ].x = 81;
    spriteClips[ 9 ].y = 66;
    spriteClips[ 9 ].w = 25;
    spriteClips[ 9 ].h = 25;

     //Frame 10
    spriteClips[ 10 ].x = 81;
    spriteClips[ 10 ].y = 66;
    spriteClips[ 10 ].w = 25;
    spriteClips[ 10 ].h = 25;

    //Frame 11
    spriteClips[ 11 ].x = 108;
    spriteClips[ 11 ].y = 66;
    spriteClips[ 11 ].w = 25;
    spriteClips[ 11 ].h = 25;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;
}


void Enemy::Move()
{
     //speedx = speedx * friction;
     //speedy = speedy * friction;

     //x = x + speedx;
     y = y + 2; //speedy;
     if(y > 900)
     {
         SetAlive(false);
     }
}

void Enemy::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    spriteSheetTexture->Render( x- width/2 , y - height/2, &spriteClips[ frame % FLYING_FRAMES ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    if(debug == true)
    {
        SDL_Rect rect = { x - width/2, y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}
