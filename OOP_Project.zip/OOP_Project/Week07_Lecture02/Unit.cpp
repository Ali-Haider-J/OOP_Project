#include "Unit.h"

Unit::Unit()
{

}

Unit::Unit(LTexture* image, float x, float y)
{
    spriteSheetTexture = image;


        cout << "UP IS" << up << endl;
        //Frame 0
        spriteClips[ 0 ].x =   0;
        spriteClips[ 0 ].y =   0;
        spriteClips[ 0 ].w = 16;
        spriteClips[ 0 ].h = 30;

        //Frame 1
        spriteClips[ 1 ].x =  17;
        spriteClips[ 1 ].y =   0;
        spriteClips[ 1 ].w = 14;
        spriteClips[ 1 ].h = 30;

        //Frame 2
        spriteClips[ 2 ].x = 34;
        spriteClips[ 2 ].y =   0;
        spriteClips[ 2 ].w = 12;
        spriteClips[ 2 ].h = 30;

        //Frame 3
        spriteClips[ 3 ].x = 49;
        spriteClips[ 3 ].y =   0;
        spriteClips[ 3 ].w = 13;
        spriteClips[ 3 ].h = 30;

        //Frame 4
        spriteClips[ 4 ].x = 67;
        spriteClips[ 4 ].y = 0;
        spriteClips[ 4 ].w = 14;
        spriteClips[ 4 ].h = 30;

        //Frame 5
        spriteClips[ 5 ].x = 85;
        spriteClips[ 5 ].y = 0;
        spriteClips[ 5 ].w = 14;
        spriteClips[ 5 ].h = 30;

        //Frame 6
        spriteClips[ 6 ].x = 102;
        spriteClips[ 6 ].y = 0;
        spriteClips[ 6 ].w = 15 ;
        spriteClips[ 6 ].h = 30;


        //Frame 7
        spriteClips[ 7 ].x = 120;
        spriteClips[ 7 ].y = 0;
        spriteClips[ 7 ].w = 16;
        spriteClips[ 7 ].h = 30;

        //Frame 8
        spriteClips[ 8 ].x = 139;
        spriteClips[ 8 ].y = 0;
        spriteClips[ 8 ].w = 16;
        spriteClips[ 8 ].h = 30;

        //Frame 9
        spriteClips[ 9 ].x = 157;
        spriteClips[ 9 ].y = 0;
        spriteClips[ 9 ].w = 14;
        spriteClips[ 9 ].h = 30;

        //Frame 10
        spriteClips[ 10 ].x = 174;
        spriteClips[ 10 ].y = 0;
        spriteClips[ 10 ].w = 14;
        spriteClips[ 10 ].h = 30;

        //Frame 11
        spriteClips[ 11 ].x = 192;
        spriteClips[ 11 ].y =   0;
        spriteClips[ 11 ].w = 15;
        spriteClips[ 11 ].h = 30;

        //down movement
        //Frame 0
        spriteClips_down[ 0 ].x =   0;
        spriteClips_down[ 0 ].y =  30;
        spriteClips_down[ 0 ].w = 16;
        spriteClips_down[ 0 ].h = 30;

        //Frame 1
        spriteClips_down[ 1 ].x =  17;
        spriteClips_down[ 1 ].y =   30;
        spriteClips_down[ 1 ].w = 16;
        spriteClips_down[ 1 ].h = 30;

        //Frame 2
        spriteClips_down[ 2 ].x = 34;
        spriteClips_down[ 2 ].y =   30;
        spriteClips_down[ 2 ].w = 15;
        spriteClips_down[ 2 ].h = 30;

        //Frame 3
        spriteClips_down[ 3 ].x = 50;
        spriteClips_down[ 3 ].y =   30;
        spriteClips_down[ 3 ].w = 16;
        spriteClips_down[ 3 ].h = 30;

        //Frame 4
        spriteClips_down[ 4 ].x = 67;
        spriteClips_down[ 4 ].y = 30;
        spriteClips_down[ 4 ].w = 17;
        spriteClips_down[ 4 ].h = 30;

        //Frame 5
        spriteClips_down[ 5 ].x = 85;
        spriteClips_down[ 5 ].y = 30;
        spriteClips_down[ 5 ].w = 18;
        spriteClips_down[ 5 ].h = 30;

        //Frame 6
        spriteClips_down[ 6 ].x = 104;
        spriteClips_down[ 6 ].y = 30;
        spriteClips_down[ 6 ].w = 17 ;
        spriteClips_down[ 6 ].h = 30;


        //Frame 7
        spriteClips_down[ 7 ].x = 122;
        spriteClips_down[ 7 ].y = 30;
        spriteClips_down[ 7 ].w = 16;
        spriteClips_down[ 7 ].h = 30;

        //Frame 8
        spriteClips_down[ 8 ].x = 139;
        spriteClips_down[ 8 ].y = 30;
        spriteClips_down[ 8 ].w = 16;
        spriteClips_down[ 8 ].h = 30;

        //Frame 9
        spriteClips_down[ 9 ].x = 156;
        spriteClips_down[ 9 ].y = 30;
        spriteClips_down[ 9 ].w = 16;
        spriteClips_down[ 9 ].h = 30;

        //Frame 10
        spriteClips_down[ 10 ].x = 173;
        spriteClips_down[ 10 ].y = 30;
        spriteClips_down[ 10 ].w = 17;
        spriteClips_down[ 10 ].h = 30;

        //Frame 11
        spriteClips_down[ 11 ].x = 191;
        spriteClips_down[ 11 ].y =   30;
        spriteClips_down[ 11 ].w = 17;
        spriteClips_down[ 11 ].h = 30;


    this->x = x;
    this->y = y;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;

    friction = 0.75f;
    speedx = 0;
    speedy = 0;
    alive  = true;
}


Unit::~Unit()
{
    spriteSheetTexture = NULL;
}

void Unit::SetAlive(bool alive)
{
    this->alive = alive;
}

bool Unit::GetAlive()
{
    return alive;
}

void Unit::Move(int direction)
{

    if(direction==LEFT)
    {
        speedx = -2;
        x+=speedx;
    }

    if(direction==RIGHT)
    {
        speedx = 2;
        x+=speedx;
    }

    if(direction==UP)
    {
        speedy = -2;
        y+=speedy;
    }

    if(direction==DOWN)
    {
        speedy = 2;
        y+=speedy;
    }

}

void Unit::Move()
{
     speedx = speedx * friction;
     speedy = speedy * friction;

     x = x + speedx;
     y = y + speedy;
}

void Unit::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    if (up == true)
    {
        spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame % FLYING_FRAMES ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    }
    else if ( up == false)
    {
        spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips_down[ frame % FLYING_FRAMES ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    }
    if(debug == true)
    {
        SDL_Rect rect = { x - width/2, y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}

int Unit::GetWidth()
{
    return width;
}

int Unit::GetHeight()
{
    return height;
}

float Unit::GetX()
{
    return x;
}
float Unit::GetY()
{
    return y;
}
