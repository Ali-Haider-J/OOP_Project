#include "Unit.h"

Unit::Unit()
{

}

Unit::Unit(LTexture* image, float x, float y)
{
    spriteSheetTexture = image;

        //UP movement
        //Frame 0
        spriteClips[ 0 ].x =  2;
        spriteClips[ 0 ].y =  0;
        spriteClips[ 0 ].w = 17;
        spriteClips[ 0 ].h = 31;

        //Frame 1
        spriteClips[ 1 ].x =  24;
        spriteClips[ 1 ].y =  0;
        spriteClips[ 1 ].w = 17;
        spriteClips[ 1 ].h = 31;

        //Frame 2
        spriteClips[ 2 ].x = 46;
        spriteClips[ 2 ].y =  0;
        spriteClips[ 2 ].w = 17;
        spriteClips[ 2 ].h = 31;

        //Frame 3
        spriteClips[ 3 ].x = 68;
        spriteClips[ 3 ].y =  0;
        spriteClips[ 3 ].w = 17;
        spriteClips[ 3 ].h = 31;

        //Frame 4
        spriteClips[ 4 ].x = 90;
        spriteClips[ 4 ].y = 0;
        spriteClips[ 4 ].w = 17;
        spriteClips[ 4 ].h = 31;

        //Frame 5
        spriteClips[ 5 ].x = 112;
        spriteClips[ 5 ].y = 0;
        spriteClips[ 5 ].w = 17;
        spriteClips[ 5 ].h = 31;

        //Frame 6
        spriteClips[ 6 ].x = 134;
        spriteClips[ 6 ].y = 0;
        spriteClips[ 6 ].w = 17 ;
        spriteClips[ 6 ].h = 31;


        //Frame 7
        spriteClips[ 7 ].x = 156;
        spriteClips[ 7 ].y = 0;
        spriteClips[ 7 ].w = 17;
        spriteClips[ 7 ].h = 31;

        //Frame 8
        spriteClips[ 8 ].x = 178;
        spriteClips[ 8 ].y = 0;
        spriteClips[ 8 ].w = 17;
        spriteClips[ 8 ].h = 31;

        //Frame 9
        spriteClips[ 9 ].x = 200;
        spriteClips[ 9 ].y = 0;
        spriteClips[ 9 ].w = 17;
        spriteClips[ 9 ].h = 31;

        //Frame 10
        spriteClips[ 10 ].x = 222;
        spriteClips[ 10 ].y = 0;
        spriteClips[ 10 ].w = 17;
        spriteClips[ 10 ].h = 31;

        //Frame 11
        spriteClips[ 11 ].x = 244;
        spriteClips[ 11 ].y =  0;
        spriteClips[ 11 ].w = 17;
        spriteClips[ 11 ].h = 31;

        //DOWN movement
        //Frame 0
        spriteClips_down[ 0 ].x =   2;
        spriteClips_down[ 0 ].y =  36;
        spriteClips_down[ 0 ].w = 19;
        spriteClips_down[ 0 ].h = 34;

        //Frame 1
        spriteClips_down[ 1 ].x =  26;
        spriteClips_down[ 1 ].y =  36;
        spriteClips_down[ 1 ].w = 19;
        spriteClips_down[ 1 ].h = 34;

        //Frame 2
        spriteClips_down[ 2 ].x = 50;
        spriteClips_down[ 2 ].y =  36;
        spriteClips_down[ 2 ].w = 19;
        spriteClips_down[ 2 ].h = 34;

        //Frame 3
        spriteClips_down[ 3 ].x = 74;
        spriteClips_down[ 3 ].y = 36;
        spriteClips_down[ 3 ].w = 19;
        spriteClips_down[ 3 ].h = 34;

        //Frame 4
        spriteClips_down[ 4 ].x = 98;
        spriteClips_down[ 4 ].y = 36;
        spriteClips_down[ 4 ].w = 19;
        spriteClips_down[ 4 ].h = 34;

        //Frame 5
        spriteClips_down[ 5 ].x = 122;
        spriteClips_down[ 5 ].y = 36;
        spriteClips_down[ 5 ].w = 19;
        spriteClips_down[ 5 ].h = 34;

        //Frame 6
        spriteClips_down[ 6 ].x = 146;
        spriteClips_down[ 6 ].y = 36;
        spriteClips_down[ 6 ].w = 19;
        spriteClips_down[ 6 ].h = 34;


        //Frame 7
        spriteClips_down[ 7 ].x = 170;
        spriteClips_down[ 7 ].y = 36;
        spriteClips_down[ 7 ].w = 19;
        spriteClips_down[ 7 ].h = 34;

        //Frame 8
        spriteClips_down[ 8 ].x = 194;
        spriteClips_down[ 8 ].y = 36;
        spriteClips_down[ 8 ].w = 19;
        spriteClips_down[ 8 ].h = 34;

        //Frame 9
        spriteClips_down[ 9 ].x = 218;
        spriteClips_down[ 9 ].y = 36;
        spriteClips_down[ 9 ].w = 19;
        spriteClips_down[ 9 ].h = 34;

        //Frame 10
        spriteClips_down[ 10 ].x = 242;
        spriteClips_down[ 10 ].y = 36;
        spriteClips_down[ 10 ].w = 19;
        spriteClips_down[ 10 ].h = 34;

        //Frame 11
        spriteClips_down[ 11 ].x = 266;
        spriteClips_down[ 11 ].y =  36;
        spriteClips_down[ 11 ].w = 19;
        spriteClips_down[ 11 ].h = 34;

        //RIGHT movement
        //Frame 0
        spriteClips_right[ 0 ].x = 290;
        spriteClips_right[ 0 ].y =  2;
        spriteClips_right[ 0 ].w = 25;
        spriteClips_right[ 0 ].h = 31;

        //Frame 1
        spriteClips_right[ 1 ].x =  320;
        spriteClips_right[ 1 ].y =  2;
        spriteClips_right[ 1 ].w = 25;
        spriteClips_right[ 1 ].h = 31;

        //Frame 2
        spriteClips_right[ 2 ].x = 350;
        spriteClips_right[ 2 ].y =  2;
        spriteClips_right[ 2 ].w = 25;
        spriteClips_right[ 2 ].h = 31;

        //Frame 3
        spriteClips_right[ 3 ].x = 380;
        spriteClips_right[ 3 ].y =  2;
        spriteClips_right[ 3 ].w = 25;
        spriteClips_right[ 3 ].h = 31;

        //Frame 4
        spriteClips_right[ 4 ].x = 410;
        spriteClips_right[ 4 ].y = 2;
        spriteClips_right[ 4 ].w = 25;
        spriteClips_right[ 4 ].h = 31;

        //Frame 5
        spriteClips_right[ 5 ].x = 441;
        spriteClips_right[ 5 ].y = 2;
        spriteClips_right[ 5 ].w = 25;
        spriteClips_right[ 5 ].h = 31;

        //Frame 6
        spriteClips_right[ 6 ].x = 471;
        spriteClips_right[ 6 ].y = 2;
        spriteClips_right[ 6 ].w = 25;
        spriteClips_right[ 6 ].h = 31;


        //Frame 7
        spriteClips_right[ 7 ].x = 501;
        spriteClips_right[ 7 ].y = 2;
        spriteClips_right[ 7 ].w = 25;
        spriteClips_right[ 7 ].h = 31;

        //Frame 8
        spriteClips_right[ 8 ].x = 531;
        spriteClips_right[ 8 ].y = 2;
        spriteClips_right[ 8 ].w = 25;
        spriteClips_right[ 8 ].h = 31;

        //Frame 9
        spriteClips_right[ 9 ].x = 562;
        spriteClips_right[ 9 ].y = 2;
        spriteClips_right[ 9 ].w = 25;
        spriteClips_right[ 9 ].h = 31;

        //Frame 10
        spriteClips_right[ 10 ].x = 592;
        spriteClips_right[ 10 ].y = 2;
        spriteClips_right[ 10 ].w = 25;
        spriteClips_right[ 10 ].h = 31;

        //Frame 11
        spriteClips_right[ 11 ].x = 622;
        spriteClips_right[ 11 ].y =  2;
        spriteClips_right[ 11 ].w = 25;
        spriteClips_right[ 11 ].h = 31;

        //LEFT movement
        //Frame 0
        spriteClips_left[ 0 ].x = 290;
        spriteClips_left[ 0 ].y =  38;
        spriteClips_left[ 0 ].w = 25;
        spriteClips_left[ 0 ].h = 31;

        //Frame 1
        spriteClips_left[ 1 ].x =  320;
        spriteClips_left[ 1 ].y =  38;
        spriteClips_left[ 1 ].w = 25;
        spriteClips_left[ 1 ].h = 31;

        //Frame 2
        spriteClips_left[ 2 ].x = 350;
        spriteClips_left[ 2 ].y =  38;
        spriteClips_left[ 2 ].w = 25;
        spriteClips_left[ 2 ].h = 31;

        //Frame 3
        spriteClips_left[ 3 ].x = 380;
        spriteClips_left[ 3 ].y =  38;
        spriteClips_left[ 3 ].w = 25;
        spriteClips_left[ 3 ].h = 31;

        //Frame 4
        spriteClips_left[ 4 ].x = 410;
        spriteClips_left[ 4 ].y = 38;
        spriteClips_left[ 4 ].w = 25;
        spriteClips_left[ 4 ].h = 31;

        //Frame 5
        spriteClips_left[ 5 ].x = 441;
        spriteClips_left[ 5 ].y = 38;
        spriteClips_left[ 5 ].w = 25;
        spriteClips_left[ 5 ].h = 31;

        //Frame 6
        spriteClips_left[ 6 ].x = 471;
        spriteClips_left[ 6 ].y = 38;
        spriteClips_left[ 6 ].w = 25;
        spriteClips_left[ 6 ].h = 31;


        //Frame 7
        spriteClips_left[ 7 ].x = 501;
        spriteClips_left[ 7 ].y = 38;
        spriteClips_left[ 7 ].w = 25;
        spriteClips_left[ 7 ].h = 31;

        //Frame 8
        spriteClips_left[ 8 ].x = 531;
        spriteClips_left[ 8 ].y = 38;
        spriteClips_left[ 8 ].w = 25;
        spriteClips_left[ 8 ].h = 31;

        //Frame 9
        spriteClips_left[ 9 ].x = 562;
        spriteClips_left[ 9 ].y = 38;
        spriteClips_left[ 9 ].w = 25;
        spriteClips_left[ 9 ].h = 31;

        //Frame 10
        spriteClips_left[ 10 ].x = 592;
        spriteClips_left[ 10 ].y = 38;
        spriteClips_left[ 10 ].w = 25;
        spriteClips_left[ 10 ].h = 31;

        //Frame 11
        spriteClips_left[ 11 ].x = 622;
        spriteClips_left[ 11 ].y = 38;
        spriteClips_left[ 11 ].w = 25;
        spriteClips_left[ 11 ].h = 31;

        //IDLE
        //IDLE_LEFT
        //frame 0
        spriteClips_idle_left[ 0 ].x = 652;
        spriteClips_idle_left[ 0 ].y = 2;
        spriteClips_idle_left[ 0 ].w = 14;
        spriteClips_idle_left[ 0 ].h = 30;

        //frame 1
        spriteClips_idle_left[ 1 ].x = 652;
        spriteClips_idle_left[ 1 ].y = 2;
        spriteClips_idle_left[ 1 ].w = 14;
        spriteClips_idle_left[ 1 ].h = 30;

        //frame 2
        spriteClips_idle_left[ 2 ].x = 652;
        spriteClips_idle_left[ 2 ].y = 2;
        spriteClips_idle_left[ 2 ].w = 14;
        spriteClips_idle_left[ 2 ].h = 30;

        //frame3
        spriteClips_idle_left[ 3 ].x = 652;
        spriteClips_idle_left[ 3 ].y = 2;
        spriteClips_idle_left[ 3 ].w = 14;
        spriteClips_idle_left[ 3 ].h = 30;

        //frame 4
        spriteClips_idle_left[ 4 ].x = 652;
        spriteClips_idle_left[ 4 ].y = 2;
        spriteClips_idle_left[ 4 ].w = 14;
        spriteClips_idle_left[ 4 ].h = 30;

        //frame 5
        spriteClips_idle_left[ 5 ].x = 652;
        spriteClips_idle_left[ 5 ].y = 2;
        spriteClips_idle_left[ 5 ].w = 14;
        spriteClips_idle_left[ 5 ].h = 30;

        //frame 6
        spriteClips_idle_left[ 6 ].x = 652;
        spriteClips_idle_left[ 6 ].y = 2;
        spriteClips_idle_left[ 6 ].w = 14;
        spriteClips_idle_left[ 6 ].h = 30;

        //frame 7
        spriteClips_idle_left[ 7 ].x = 652;
        spriteClips_idle_left[ 7 ].y = 2;
        spriteClips_idle_left[ 7 ].w = 14;
        spriteClips_idle_left[ 7 ].h = 30;

        //frame 8
        spriteClips_idle_left[ 8 ].x = 652;
        spriteClips_idle_left[ 8 ].y = 2;
        spriteClips_idle_left[ 8 ].w = 14;
        spriteClips_idle_left[ 8 ].h = 30;

        //frame 9
        spriteClips_idle_left[ 9 ].x = 652;
        spriteClips_idle_left[ 9 ].y = 2;
        spriteClips_idle_left[ 9 ].w = 14;
        spriteClips_idle_left[ 9 ].h = 30;

        //frame 10
        spriteClips_idle_left[ 10 ].x = 652;
        spriteClips_idle_left[ 10 ].y = 2;
        spriteClips_idle_left[ 10 ].w = 14;
        spriteClips_idle_left[ 10 ].h = 30;

        //frame 11
        spriteClips_idle_left[ 11 ].x = 652;
        spriteClips_idle_left[ 11 ].y = 2;
        spriteClips_idle_left[ 11 ].w = 14;
        spriteClips_idle_left[ 11 ].h = 30;

        //IDLE_RIGHT
        //frame 0
        spriteClips_idle_right[ 0 ].x = 652;
        spriteClips_idle_right[ 0 ].y = 36;
        spriteClips_idle_right[ 0 ].w = 14;
        spriteClips_idle_right[ 0 ].h = 32;

        //frame 1
        spriteClips_idle_right[ 1 ].x = 652;
        spriteClips_idle_right[ 1 ].y = 36;
        spriteClips_idle_right[ 1 ].w = 14;
        spriteClips_idle_right[ 1 ].h = 32;

        //frame 2
        spriteClips_idle_right[ 2 ].x = 652;
        spriteClips_idle_right[ 2 ].y = 36;
        spriteClips_idle_right[ 2 ].w = 14;
        spriteClips_idle_right[ 2 ].h = 32;

        //frame3
        spriteClips_idle_right[ 3 ].x = 652;
        spriteClips_idle_right[ 3 ].y = 36;
        spriteClips_idle_right[ 3 ].w = 14;
        spriteClips_idle_right[ 3 ].h = 32;

        //frame 4
        spriteClips_idle_right[ 4 ].x = 652;
        spriteClips_idle_right[ 4 ].y = 36;
        spriteClips_idle_right[ 4 ].w = 14;
        spriteClips_idle_right[ 4 ].h = 32;

        //frame 5
        spriteClips_idle_right[ 5 ].x = 652;
        spriteClips_idle_right[ 5 ].y = 36;
        spriteClips_idle_right[ 5 ].w = 14;
        spriteClips_idle_right[ 5 ].h = 32;

        //frame 6
        spriteClips_idle_right[ 6 ].x = 652;
        spriteClips_idle_right[ 6 ].y = 36;
        spriteClips_idle_right[ 6 ].w = 14;
        spriteClips_idle_right[ 6 ].h = 32;

        //frame 7
        spriteClips_idle_right[ 7 ].x = 652;
        spriteClips_idle_right[ 7 ].y = 36;
        spriteClips_idle_right[ 7 ].w = 14;
        spriteClips_idle_right[ 7 ].h = 32;

        //frame 8
        spriteClips_idle_right[ 8 ].x = 652;
        spriteClips_idle_right[ 8 ].y = 36;
        spriteClips_idle_right[ 8 ].w = 14;
        spriteClips_idle_right[ 8 ].h = 32;

        //frame 9
        spriteClips_idle_right[ 9 ].x = 652;
        spriteClips_idle_right[ 9 ].y = 36;
        spriteClips_idle_right[ 9 ].w = 14;
        spriteClips_idle_right[ 9 ].h = 32;

        //frame 10
        spriteClips_idle_right[ 10 ].x = 652;
        spriteClips_idle_right[ 10 ].y = 36;
        spriteClips_idle_right[ 10 ].w = 14;
        spriteClips_idle_right[ 10 ].h = 32;

        //frame 11
        spriteClips_idle_right[ 11 ].x = 652;
        spriteClips_idle_right[ 11 ].y = 36;
        spriteClips_idle_right[ 11 ].w = 14;
        spriteClips_idle_right[ 11 ].h = 32;

        //IDLE_UP
        //frame 0
        spriteClips_idle_up[ 0 ].x = 671;
        spriteClips_idle_up[ 0 ].y = 2;
        spriteClips_idle_up[ 0 ].w = 15;
        spriteClips_idle_up[ 0 ].h = 30;

        //frame 1
        spriteClips_idle_up[ 1 ].x = 671;
        spriteClips_idle_up[ 1 ].y = 2;
        spriteClips_idle_up[ 1 ].w = 15;
        spriteClips_idle_up[ 1 ].h = 30;

        //frame 2
        spriteClips_idle_up[ 2 ].x = 671;
        spriteClips_idle_up[ 2 ].y = 2;
        spriteClips_idle_up[ 2 ].w = 15;
        spriteClips_idle_up[ 2 ].h = 30;

        //frame3
        spriteClips_idle_up[ 3 ].x = 671;
        spriteClips_idle_up[ 3 ].y = 2;
        spriteClips_idle_up[ 3 ].w = 15;
        spriteClips_idle_up[ 3 ].h = 30;

        //frame 4
        spriteClips_idle_up[ 4 ].x = 671;
        spriteClips_idle_up[ 4 ].y = 2;
        spriteClips_idle_up[ 4 ].w = 15;
        spriteClips_idle_up[ 4 ].h = 30;

        //frame 5
        spriteClips_idle_up[ 5 ].x = 671;
        spriteClips_idle_up[ 5 ].y = 2;
        spriteClips_idle_up[ 5 ].w = 15;
        spriteClips_idle_up[ 5 ].h = 30;

        //frame 6
        spriteClips_idle_up[ 6 ].x = 671;
        spriteClips_idle_up[ 6 ].y = 2;
        spriteClips_idle_up[ 6 ].w = 15;
        spriteClips_idle_up[ 6 ].h = 30;

        //frame 7
        spriteClips_idle_up[ 7 ].x = 671;
        spriteClips_idle_up[ 7 ].y = 2;
        spriteClips_idle_up[ 7 ].w = 15;
        spriteClips_idle_up[ 7 ].h = 30;

        //frame 8
        spriteClips_idle_up[ 8 ].x = 671;
        spriteClips_idle_up[ 8 ].y = 2;
        spriteClips_idle_up[ 8 ].w = 15;
        spriteClips_idle_up[ 8 ].h = 30;

        //frame 9
        spriteClips_idle_up[ 9 ].x = 671;
        spriteClips_idle_up[ 9 ].y = 2;
        spriteClips_idle_up[ 9 ].w = 15;
        spriteClips_idle_up[ 9 ].h = 30;

        //frame 10
        spriteClips_idle_up[ 10 ].x = 671;
        spriteClips_idle_up[ 10 ].y = 2;
        spriteClips_idle_up[ 10 ].w = 15;
        spriteClips_idle_up[ 10 ].h = 30;

        //frame 11
        spriteClips_idle_up[ 11 ].x = 671;
        spriteClips_idle_up[ 11 ].y = 2;
        spriteClips_idle_up[ 11 ].w = 15;
        spriteClips_idle_up[ 11 ].h = 30;

        //IDLE_DOWN
        //frame 0
        spriteClips_idle_down[ 0 ].x = 671;
        spriteClips_idle_down[ 0 ].y = 36;
        spriteClips_idle_down[ 0 ].w = 15;
        spriteClips_idle_down[ 0 ].h = 32;

        //frame 1
        spriteClips_idle_down[ 1 ].x = 671;
        spriteClips_idle_down[ 1 ].y = 36;
        spriteClips_idle_down[ 1 ].w = 15;
        spriteClips_idle_down[ 1 ].h = 32;

        //frame 2
        spriteClips_idle_down[ 2 ].x = 671;
        spriteClips_idle_down[ 2 ].y = 36;
        spriteClips_idle_down[ 2 ].w = 15;
        spriteClips_idle_down[ 2 ].h = 32;

        //frame3
        spriteClips_idle_down[ 3 ].x = 671;
        spriteClips_idle_down[ 3 ].y = 36;
        spriteClips_idle_down[ 3 ].w = 15;
        spriteClips_idle_down[ 3 ].h = 32;

        //frame 4
        spriteClips_idle_down[ 4 ].x = 671;
        spriteClips_idle_down[ 4 ].y = 36;
        spriteClips_idle_down[ 4 ].w = 15;
        spriteClips_idle_down[ 4 ].h = 32;

        //frame 5
        spriteClips_idle_down[ 5 ].x = 671;
        spriteClips_idle_down[ 5 ].y = 36;
        spriteClips_idle_down[ 5 ].w = 15;
        spriteClips_idle_down[ 5 ].h = 32;

        //frame 6
        spriteClips_idle_down[ 6 ].x = 671;
        spriteClips_idle_down[ 6 ].y = 36;
        spriteClips_idle_down[ 6 ].w = 15;
        spriteClips_idle_down[ 6 ].h = 32;

        //frame 7
        spriteClips_idle_down[ 7 ].x = 671;
        spriteClips_idle_down[ 7 ].y = 36;
        spriteClips_idle_down[ 7 ].w = 15;
        spriteClips_idle_down[ 7 ].h = 32;

        //frame 8
        spriteClips_idle_down[ 8 ].x = 671;
        spriteClips_idle_down[ 8 ].y = 36;
        spriteClips_idle_down[ 8 ].w = 15;
        spriteClips_idle_down[ 8 ].h = 32;

        //frame 9
        spriteClips_idle_down[ 9 ].x = 671;
        spriteClips_idle_down[ 9 ].y = 36;
        spriteClips_idle_down[ 9 ].w = 15;
        spriteClips_idle_down[ 9 ].h = 32;

        //frame 10
        spriteClips_idle_down[ 10 ].x = 671;
        spriteClips_idle_down[ 10 ].y = 36;
        spriteClips_idle_down[ 10 ].w = 15;
        spriteClips_idle_down[ 10 ].h = 32;

        //frame 11
        spriteClips_idle_down[ 11 ].x = 671;
        spriteClips_idle_down[ 11 ].y = 36;
        spriteClips_idle_down[ 11 ].w = 15;
        spriteClips_idle_down[ 11 ].h = 32;
/*
        //BACKGROUND
        //frame 0
        spriteClips_BG[ 0 ].x = 1;
        spriteClips_BG[ 0 ].y = 149;
        spriteClips_BG[ 0 ].w = 999;
        spriteClips_BG[ 0 ].h = 850;

        //frame 1
        spriteClips_BG[ 1 ].x = 1;
        spriteClips_BG[ 1 ].y = 149;
        spriteClips_BG[ 1 ].w = 999;
        spriteClips_BG[ 1 ].h = 850;

        //frame 2
        spriteClips_BG[ 2 ].x = 1;
        spriteClips_BG[ 2 ].y = 149;
        spriteClips_BG[ 2 ].w = 999;
        spriteClips_BG[ 2 ].h = 850;

        //frame3
        spriteClips_BG[ 3 ].x = 1;
        spriteClips_BG[ 3 ].y = 149;
        spriteClips_BG[ 3 ].w = 999;
        spriteClips_BG[ 3 ].h = 850;

        //frame 4
        spriteClips_BG[ 4 ].x = 1;
        spriteClips_BG[ 4 ].y = 149;
        spriteClips_BG[ 4 ].w = 999;
        spriteClips_BG[ 4 ].h = 850;

        //frame 5
        spriteClips_BG[ 5 ].x = 1;
        spriteClips_BG[ 5 ].y = 149;
        spriteClips_BG[ 5 ].w = 999;
        spriteClips_BG[ 5 ].h = 850;

        //frame 6
        spriteClips_BG[ 6 ].x = 1;
        spriteClips_BG[ 6 ].y = 149;
        spriteClips_BG[ 6 ].w = 999;
        spriteClips_BG[ 6 ].h = 850;

        //frame 7
        spriteClips_BG[ 7 ].x = 1;
        spriteClips_BG[ 7 ].y = 149;
        spriteClips_BG[ 7 ].w = 999;
        spriteClips_BG[ 7 ].h = 850;

        //frame 8
        spriteClips_BG[ 8 ].x = 1;
        spriteClips_BG[ 8 ].y = 149;
        spriteClips_BG[ 8 ].w = 999;
        spriteClips_BG[ 8 ].h = 850;

        //frame 9
        spriteClips_BG[ 9 ].x = 1;
        spriteClips_BG[ 9 ].y = 149;
        spriteClips_BG[ 9 ].w = 999;
        spriteClips_BG[ 9 ].h = 850;

        //frame 10
        spriteClips_BG[ 10 ].x = 1;
        spriteClips_BG[ 10 ].y = 149;
        spriteClips_BG[ 10 ].w = 999;
        spriteClips_BG[ 10 ].h = 850;

        //frame 11
        spriteClips_BG[ 11 ].x = 1;
        spriteClips_BG[ 11 ].y = 149;
        spriteClips_BG[ 11 ].w = 999;
        spriteClips_BG[ 11 ].h = 850;

*/
    this->x = x;
    this->y = y;

    this->width = spriteClips[ 0 ].w;
    this->height = spriteClips[ 0 ].h;

    friction = 0.75f;
    speedx = 0;
    speedy = 0;
    alive  = true;
}


Unit::~Unit()
{
    spriteSheetTexture = NULL;
}

void Unit::SetAlive(bool alive)
{
    this->alive = alive;
}

bool Unit::GetAlive()
{
    return alive;
}

void Unit::Move(int direction)
{

    if(direction==LEFT)
    {
        //speedx = -2;
        x+=speedx;
    }

    if(direction==RIGHT)
    {
        //speedx = 2;
        x+=speedx;

    }

    if(direction==UP)
    {
        //speedy = -2;
        y+=speedy;
    }

    if(direction==DOWN)
    {
        //speedy = 2;
        y+=speedy;
    }

}

void Unit::Move()
{

     speedx = speedx * friction;
     speedy = speedy * friction;
    cout << "SPEEDX IS: " << speedx << endl;
     //x = x + speedx;
     //y = y + speedy;
    /*if ( !downRight )
    {
        x = 527;
        y = 400;
    }*/
    cout << chck << endl;
    cout << x << endl;
    /*if (!chck and idle)
    {

            x -= 15;
            if ( x <= 353.5 )
            {
                chck = true;
                discovered_r = true;
                discovered_l = true;

            }

    }
*/
    if ( x > 650 )// & downRight)
    {
        x = 650;

        current = true;
        //discovered_r = true;
    }
    if (chck and idle)
    {
        x -= 2;
    }
    /*if ( !upLeft )
    {
        x = 425;
        y = 300;
    }*/
    if ( x < 100 )// & upLeft)
    {
        x = 100;
        current = false;
        //discovered_l = true;
    }

    if ( y > 450 )// & upLeft)
    {
        y = 450;
        current_v = false;
        discovered_d = true;
        //discovered = false;
    }

    if ( y < 250 )//& upLeft)
    {
        y = 250;

        current_v = true;
        discovered_u = true;
        //discovered = false;
    }
}

void Unit::Render(long int& frame, SDL_Renderer* gRenderer, bool debug)
{
    if ( idle == true )
    {
        if (up == false & left == true & right == false)
            spriteSheetTexture->Render( x - width/2 , y - height/2, &spriteClips_idle_left[ frame % FLYING_FRAMES ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
        else if ( up == false & left == false & right == true)
            spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips_idle_right[ frame % FLYING_FRAMES ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
        else if ( up == true & left == false & right == false)
            spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips_idle_up[ frame % FLYING_FRAMES ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
        else if ( up == false & left == false & right == false)
            spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips_idle_down[ frame % FLYING_FRAMES ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    }
    if ( idle == false & up == true & right == false & left == false)
    {
        spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips[ frame % FLYING_FRAMES ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    }
    if ( idle == false & up == false  & right == false & left == false)
    {
        spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips_down[ frame % FLYING_FRAMES ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    }
    if ( idle == false & right == true & up == false & left == false)
    {
        spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips_right[ frame % FLYING_FRAMES ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    }
    if ( idle == false & left == true & up == false & right == false)
    {
        spriteSheetTexture->Render( x - width/2, y - height/2, &spriteClips_left[ frame % FLYING_FRAMES ], 0.0, NULL, SDL_FLIP_NONE, gRenderer );
    }

    if(debug == true)
    {
        SDL_Rect rect = { x - width/2, y - height/2, width, height };
        SDL_SetRenderDrawColor( gRenderer, 0xFF, 0x00, 0x00, 0xFF );
        SDL_RenderDrawRect( gRenderer, &rect );
    }
}

int Unit::GetWidth()
{
    return width;
}

int Unit::GetHeight()
{
    return height;
}

float Unit::GetX()
{
    return x;
}
float Unit::GetY()
{
    return y;
}
void Unit::setUp(bool u)
{
    up = u;
}
void Unit::setRight(bool r)
{
    right = r;
}
void Unit::setLeft(bool l)
{
    left = l;
}
void Unit::setIdle(bool i)
{
    idle = i;
}
bool Unit::getUp()
{
    return up;
}
bool Unit::getRight()
{
    return right;
}
bool Unit::getLeft()
{
    return left;
}
bool Unit::getIdle()
{
    return idle;
}
