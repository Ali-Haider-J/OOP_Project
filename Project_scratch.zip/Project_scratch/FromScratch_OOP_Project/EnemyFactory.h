#pragma once
#include "Enemy.h"

class EnemyFactory
{
public:
    EnemyFactory();
    ~EnemyFactory();
    Enemy getEnemy();
};
