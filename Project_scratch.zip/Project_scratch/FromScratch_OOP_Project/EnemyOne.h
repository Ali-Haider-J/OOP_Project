#pragma once
#include "Enemy.h"

class EnemyOne : public Enemy
{
public:
    EnemyOne();
    ~EnemyOne();
};
