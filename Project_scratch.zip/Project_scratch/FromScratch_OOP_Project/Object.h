#pragma once
#include "SDL.h"

class Object
{
protected:
    int x;
    int y;
    int hitbox_X;
    int hitbox_Y;
    float speedX;
    float speedY;
    bool solid;
    SDL_Texture* objTexture;
    SDL_Rect srcRect, destRect;

public:
    Object();
    ~Object();
    int getX();
    int getY();
    void setSpeedX(float x);
    void setSpeedY(float y);
    float getSpeedX();
    float getSpeedY();
    void setX(int x);
    void setY(int y);
    //SDL_Rect camera(int x, int y, int zoom, int speedx, int speedy);
    virtual void draw() = 0;
    virtual void Update(long int frame, SDL_Rect tempRect) = 0;

};
