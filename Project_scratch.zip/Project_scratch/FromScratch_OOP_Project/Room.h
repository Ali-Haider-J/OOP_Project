#pragma once
#include "Object.h"
#include "Game.h"

class Room : public Object
{
private:
    bool wallR;
    bool wallL;
    int roomNo;
public:
    Room();
    ~Room();
    bool getWallR();
    bool getWallL();
    void draw();
    void Update(long int frame, SDL_Rect tempRect);
    SDL_Texture* roomTex;
};
