#pragma once
#include "Object.h"
#include "TextureManager.h"

class Unit : public Object
{
private:
    int HP;
    char direction;
    bool ally;
    bool alive;
public:
    Unit();
    ~Unit();
    virtual void attack() = 0;
    virtual void move() = 0;
};
