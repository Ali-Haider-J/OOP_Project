
#pragma once
#include "Button.h"

Button::Button()
    {
        x=y=0;
//        clicked= false;
        buttonTex =  TextureManager::LoadTexture("Images/spritesheet_1.png");


    }
Button::Button(int buttonChoice, int x, int y)
    {
        this->x=x;
        this->y=y;
//        clicked= false;
        buttonTex =  TextureManager::LoadTexture("Images/spritesheet_1.png");

        this->buttonChoice = buttonChoice;


    }

void Button::draw()
{
     SDL_RenderCopyEx(Game::renderer, buttonTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);
}


void Button::Update(long int frame, SDL_Rect tempRect)
{

            //new game
        buttonOptions[ 0 ].x = 171;
        buttonOptions[ 0 ].y = 1666;
        buttonOptions[ 0 ].w = 91;
        buttonOptions[ 0 ].h = 14;

        //load game
        buttonOptions[ 1 ].x = 69;
        buttonOptions[ 1 ].y = 1666;
        buttonOptions[ 1 ].w = 103;
        buttonOptions[ 1 ].h = 14;

        //Instructions
        buttonOptions[ 2 ].x = 125;
        buttonOptions[ 2 ].y = 1637;
        buttonOptions[ 2 ].w = 138;
        buttonOptions[ 2 ].h = 14;

        //Quit
        buttonOptions[ 3 ].x = 82;
        buttonOptions[ 3 ].y = 1637;
        buttonOptions[ 3 ].w = 44;
        buttonOptions[ 3 ].h = 31;

    srcRect = buttonOptions[buttonChoice];
    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x =  x;
    destRect.y = y;




}

