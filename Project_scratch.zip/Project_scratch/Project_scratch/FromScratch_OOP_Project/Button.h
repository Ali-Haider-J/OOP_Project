
#pragma once
#include "Object.h"
#include "TextureManager.h"

class Button : public Object
{
public:

     Button();
     Button(int,int,int );
    ~Button();
    void draw();
    void Update(long int frame, SDL_Rect tempRect);
private:
    SDL_Rect buttonOptions[ 4 ];
    int buttonChoice;
protected:
    SDL_Texture* buttonTex;
};
