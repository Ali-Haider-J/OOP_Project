#pragma once

class List
{
public:
    SDL_Rect rect1;
    SDL_Rect rect2;

};
