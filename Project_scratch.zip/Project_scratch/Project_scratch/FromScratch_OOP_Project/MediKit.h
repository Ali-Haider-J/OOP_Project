#pragma once
#include "Object.h"

class MediKit : public Object
{
public:
    MediKit();
    ~MediKit();
    void healthUp();
    void draw();
    void Update();
};
