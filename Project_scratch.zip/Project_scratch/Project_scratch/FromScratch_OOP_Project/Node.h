#pragma once
#include"Object.h"

struct Node
{
    Object* object;
    Node* next;
    Node* prev;

    //Node();
    ~Node()
    {
        delete object;
    }
};
