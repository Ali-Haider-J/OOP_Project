#include "Object.h"

Object::Object()
{

}

Object::~Object()
{


}



void Object::setX(float x)
{
    this->x = x;
}

void Object::setY(float y)
{
    this->y = y;
}

float Object::getX()
{
    return x;
}

float Object::getY()
{
    return y;
}

void Object::setSpeedX(float x)
{
    this->x = speedX;
}
void Object::setSpeedY(float y)
{
    this->y = speedY;
}

float Object::getSpeedX()
{
    return speedX;
}
float Object::getSpeedY()
{
    return speedY;
}

