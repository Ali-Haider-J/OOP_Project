#pragma once
#include"Node.h"
#include"Object.h"

class Queue
{
private:
    static Queue* instance;
    Node* head;
    Node* tail;
    Queue();
public:

    ~Queue();
    static Queue* getInstance();
    void Enqueue(Object*);
    void Clean();
    void Render(long int& frame, SDL_Renderer* gRenderer, bool debug);
    void Move(long int frame, SDL_Rect tempRect);
    void Draw();
};
