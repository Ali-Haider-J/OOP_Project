#pragma once
#include "Object.h"
#include "Game.h"

class Room : public Object
{
private:
    bool wallR;
    bool wallL;
    bool wallU;
    bool wallD;
    int roomNo;
public:
    Room();
    ~Room();
    bool getWallR();
    bool getWallL();
    bool getWallU();
    bool getWallD();
    void draw();
    void Update(long int frame, SDL_Rect tempRect);
    SDL_Texture* roomTex;

};
