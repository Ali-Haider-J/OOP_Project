#include "EnemyTwo.h"

EnemyTwo::EnemyTwo(int posx, int posy)
{
    std::cout << "EnemyTwo spawned!" << std::endl;
    this->x = posx;
    this->y = posy;
    this->hit = false;
}

EnemyTwo::~EnemyTwo()
{


}

void EnemyTwo::draw()
{

}

void EnemyTwo::Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target)
{
//moving right
//frame 0
    spriteClips_right[0].x = 237;
    spriteClips_right[0].y = 1308;
    spriteClips_right[0].w = 45;
    spriteClips_right[0].h = 2;

//frame 1
    spriteClips_right[1].x = 284;
    spriteClips_right[1].y = 1308;
    spriteClips_right[1].w = 45;
    spriteClips_right[1].h = 2;

//frame 2
    spriteClips_right[2].x = 328;
    spriteClips_right[2].y = 1306;
    spriteClips_right[2].w = 40;
    spriteClips_right[2].h = 2;

//frame 3
    spriteClips_right[3].x = 369;
    spriteClips_right[3].y = 1308;
    spriteClips_right[3].w = 45;
    spriteClips_right[3].h = 43;

//frame 4
    spriteClips_right[4].x = 411;
    spriteClips_right[4].y = 1311;
    spriteClips_right[4].w = 45;
    spriteClips_right[4].h = 43;

//frame 5
    spriteClips_right[5].x =457;
    spriteClips_right[5].y = 1311;
    spriteClips_right[5].w = 41;
    spriteClips_right[5].h = 40;

//moving left
//frame 0
    spriteClips_left[0].x = 238;
    spriteClips_left[0].y = 1357;
    spriteClips_left[0].w = 43;
    spriteClips_left[0].h = 40;

//frame 1
    spriteClips_left[1].x = 282;
    spriteClips_left[1].y = 1356;
    spriteClips_left[1].w = 45;
    spriteClips_left[1].h = 42;

//frame 2
    spriteClips_left[2].x = 327;
    spriteClips_left[2].y = 1306;
    spriteClips_left[2].w = 40;
    spriteClips_left[2].h = 2;

//frame 3
    spriteClips_left[3].x = 369;
    spriteClips_left[3].y = 1351;
    spriteClips_left[3].w = 41;
    spriteClips_left[3].h = 48;

//frame 4
    spriteClips_left[4].x = 411;
    spriteClips_left[4].y = 1351;
    spriteClips_left[4].w = 45;
    spriteClips_left[4].h = 47;

//frame 5
    spriteClips_left[5].x =457;
    spriteClips_left[5].y = 1351;
    spriteClips_left[5].w = 41;
    spriteClips_left[5].h = 46;

//moving up
//frame 0
    spriteClips_up[0].x = 255;
    spriteClips_up[0].y = 1257;
    spriteClips_up[0].w = 36;
    spriteClips_up[0].h = 44;
//frame 1
    spriteClips_up[1].x = 293
    spriteClips_up[1].y = 1257;
    spriteClips_up[1].w = 35;
    spriteClips_up[1].h = 46;
//frame 2
    spriteClips_up[2].x = 329;
    spriteClips_up[2].y = 1256;
    spriteClips_up[2].w = 34;
    spriteClips_up[2].h = 50;
//frame 3
    spriteClips_up[3].x = 363;
    spriteClips_up[3].y = 1256;
    spriteClips_up[3].w = 397;
    spriteClips_up[3].h = 1305;
//frame 4
    spriteClips_up[4].x = 398;
    spriteClips_up[4].y = 1257;
    spriteClips_up[4].w = 34;
    spriteClips_up[4].h = 49;
//frame 5
    spriteClips_up[5].x = 433;
    spriteClips_up[5].y = 1258;
    spriteClips_up[5].w = 39;
    spriteClips_up[5].h = 44;

//moving down
//frame 0
    spriteClips_down[0].x = 255;
    spriteClips_down[0].y = 1207;
    spriteClips_down[0].w = 35;
    spriteClips_down[0].h = 52;
//frame 1
    spriteClips_down[1].x = 289;
    spriteClips_down[1].y = 1207;
    spriteClips_down[1].w = 37;
    spriteClips_down[1].h = 50;
//frame 2
    spriteClips_down[2].x = 326;
    spriteClips_down[2].y = 1208;
    spriteClips_down[2].w = 49 ;
    spriteClips_down[2].h = 49;
//frame 3
    spriteClips_down[3].x = 356;
    spriteClips_down[3].y = 1207;
    spriteClips_down[3].w = 35;
    spriteClips_down[3].h = 49;
//frame 4
    spriteClips_down[4].x = 391;
    spriteClips_down[4].y = 1207;
    spriteClips_down[4].w = 33 ;
    spriteClips_down[4].h = 49;
//frame 5
    spriteClips_down[5].x = 425;
    spriteClips_down[5].y = 1208;
    spriteClips_down[5].w = 43 ;
    spriteClips_down[5].h = 49;

//attack up
//frame 0
    spriteClips_attack_up[0].x =127 ;
    spriteClips_attack_up[0].y = 1396;
    spriteClips_attack_up[0].w = 37;
    spriteClips_attack_up[0].h = 70;

//frame 0
    spriteClips_attack_up[1].x = 163;
    spriteClips_attack_up[1].y = 1395;
    spriteClips_attack_up[1].w = 35;
    spriteClips_attack_up[1].h = 70;

//frame 2
    spriteClips_attack_up[2].x = 199;
    spriteClips_attack_up[2].y = 1395;
    spriteClips_attack_up[2].w = 41;
    spriteClips_attack_up[2].h = 70;

//frame 3
    spriteClips_attack_up[3].x = 240;
    spriteClips_attack_up[3].y = 1399;
    spriteClips_attack_up[3].w = 39;
    spriteClips_attack_up[3].h = 66;

//frame 4
    spriteClips_attack_up[4].x = 279;
    spriteClips_attack_up[4].y = 1400;
    spriteClips_attack_up[4].w = 36 ;
    spriteClips_attack_up[4].h = 65;

//frame 5
    spriteClips_attack_up[5].x = 315;
    spriteClips_attack_up[5].y = 1398;
    spriteClips_attack_up[5].w = 33 ;
    spriteClips_attack_up[5].h = 67;

//attack down
//frame 0
    spriteClips_attack_down[0].x = 350;
    spriteClips_attack_down[0].y = 1411;
    spriteClips_attack_down[0].w = 42;
    spriteClips_attack_down[0].h = 50;

//frame 1
    spriteClips_attack_down[1].x = 389;
    spriteClips_attack_down[1].y = 1398;
    spriteClips_attack_down[1].w = 40;
    spriteClips_attack_down[1].h = 64;

//frame 2
    spriteClips_attack_down[2].x = 427;
    spriteClips_attack_down[2].y = 1398;
    spriteClips_attack_down[2].w = 32;
    spriteClips_attack_down[2].h = 65;

//frame 3
    spriteClips_attack_down[3].x = 459;
    spriteClips_attack_down[3].y = 1397;
    spriteClips_attack_down[3].w = 39 ;
    spriteClips_attack_down[3].h = 66;

//attack right
//frame 0
    spriteClips_attack_right[0].x = 183 ;
    spriteClips_attack_right[0].y = 1475;
    spriteClips_attack_right[0].w = 42 ;
    spriteClips_attack_right[0].h = 69 ;

//frame 1
    spriteClips_attack_right[1].x = 224;
    spriteClips_attack_right[1].y = 1492 ;
    spriteClips_attack_right[1].w = 39 ;
    spriteClips_attack_right[1].h = 52;

//frame 2
    spriteClips_attack_right[2].x = 262;
    spriteClips_attack_right[2].y = 1473;
    spriteClips_attack_right[2].w = 37;
    spriteClips_attack_right[2].h = 71;

//frame 3
    spriteClips_attack_right[3].x = 300;
    spriteClips_attack_right[3].y = 1489;
    spriteClips_attack_right[3].w = 38;
    spriteClips_attack_right[3].h = 55;

//frame 4
    spriteClips_attack_right[4].x = 339;
    spriteClips_attack_right[4].y = 1493;
    spriteClips_attack_right[4].w = 54;
    spriteClips_attack_right[4].h = 51;

//frame 5
    spriteClips_attack_right[5].x = 393 ;
    spriteClips_attack_right[5].y = 1492;
    spriteClips_attack_right[5].w = 53;
    spriteClips_attack_right[5].h = 52;

//frame 6
    spriteClips_attack_right[6].x = 447;
    spriteClips_attack_right[6].y = 1492;
    spriteClips_attack_right[6].w = 50;
    spriteClips_attack_right[6].h = 52;

//attack left
//frame 0
    spriteClips_attack_left[0].x = 186 ;
    spriteClips_attack_left[0].y = 1567;
    spriteClips_attack_left[0].w = 239;
    spriteClips_attack_left[0].h = 1626;

//frame 1
    spriteClips_attack_left[1].x =  238 ;
    spriteClips_attack_left[1].y = 1568;
    spriteClips_attack_left[1].w = 53;
    spriteClips_attack_left[1].h = 58;

//frame 2
    spriteClips_attack_left[2].x =  291;
    spriteClips_attack_left[2].y = 1566;
    spriteClips_attack_left[2].w = 52;
    spriteClips_attack_left[2].h = 60;

//frame 3
    spriteClips_attack_left[3].x = 344 ;
    spriteClips_attack_left[3].y = 1564;
    spriteClips_attack_left[3].w = 38;
    spriteClips_attack_left[3].h = 62;

//frame 4
    spriteClips_attack_left[4].x =  382;
    spriteClips_attack_left[4].y = 1555;
    spriteClips_attack_left[4].w = 40;
    spriteClips_attack_left[4].h = 48;

//frame 5
    spriteClips_attack_left[5].x =  422;
    spriteClips_attack_left[5].y = 1578;
    spriteClips_attack_left[5].w = 38;
    spriteClips_attack_left[5].h = 48;

//frame 6
    spriteClips_attack_left[6].x = 460 ;
    spriteClips_attack_left[6].y = 1554;
    spriteClips_attack_left[6].w = 37;
    spriteClips_attack_left[6].h = 72;

//attack dead
//frame 0
    spriteClips_attack_dead[0].x = 455;
    spriteClips_attack_dead[0].y = 1663;
    spriteClips_attack_dead[0].w = 43;
    spriteClips_attack_dead[0].h = 51;

}

void EnemyTwo::attack(int, int)
{

}

bool EnemyTwo::getHit()
{
    return this->hit;
}
