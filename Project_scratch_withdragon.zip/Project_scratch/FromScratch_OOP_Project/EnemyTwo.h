#pragma once
#include "Enemy.h"

class EnemyTwo : public Enemy
{
private:
//    int enemyTwoX;
//    int enemyTwoY;
    SDL_Rect spriteClips_left[6];
    SDL_Rect spriteClips_right[6];
    SDL_Rect spriteClips_up[6];
    SDL_Rect spriteClips_down[6];
    SDL_Rect spriteClips_attack_up[6];
    SDL_Rect spriteClips_attack_down[4];
    SDL_Rect spriteClips_attack_right[7];
    SDL_Rect spriteClips_attack_left[7];
    SDL_Rect spriteClips_attack_dead[1];
public:
    EnemyTwo(int x, int y);
    ~EnemyTwo();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target);
    void attack(int, int);
    bool getHit();
};
