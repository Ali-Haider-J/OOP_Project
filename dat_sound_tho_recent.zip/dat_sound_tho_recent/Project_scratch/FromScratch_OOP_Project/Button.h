#pragma once
#include "Object.h"
#include "TextureManager.h"
#include "OperatorOverloading.h"

class Button : public Object
{
public:

     Button();
     Button(int,int,int );
    ~Button();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int, SDL_Rect Target);
    void setDownMov(bool);
    void setUpMov(bool);
    void setClicked(bool);
    bool getNewGame();
    bool getInstruction();
    bool getQuit();
    void setInstruction(bool);
    bool getLoad();
    void setLoad(bool);
    void setNewGame(bool);
private:
    SDL_Rect buttonOptions[ 5 ];
    int buttonChoice;
    bool upMov = false;
    bool downMov = false;
    bool active;
    int counter;
    bool clicked;
    bool newGame;
    bool load;
    bool instruction;
    bool quit;
protected:
    SDL_Texture* buttonTex;
};
