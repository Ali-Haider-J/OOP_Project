#include "EnemyThree.h"

EnemyThree::EnemyThree(int posx, int posy)
{
    std::cout << "EnemyThree spawned!" << std::endl;
    this->x = posx;
    this->y = posy;
    this->hit = false;

}

EnemyThree::~EnemyThree()
{

}

void EnemyThree::draw()
{


}

void EnemyThree::Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target)
{

}

void EnemyThree::attack(int x, int y)
{

}

bool EnemyThree::getHit()
{
    return this->hit;
}
