#include "EnemyTwo.h"

EnemyTwo::EnemyTwo(int posx, int posy)
{
    std::cout << "EnemyTwo spawned!" << std::endl;
    this->x = posx;
    this->y = posy;
    this->hit = false;
}

EnemyTwo::~EnemyTwo()
{


}

void EnemyTwo::draw()
{

}

void EnemyTwo::Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target)
{

}

void EnemyTwo::attack(int, int)
{

}

bool EnemyTwo::getHit()
{
    return this->hit;
}
