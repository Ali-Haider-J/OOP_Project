#include "bullet.h"

Bullet::Bullet(int x, int y)
{
    this->hit = false;
    this-> x = x;
    this-> y = y;
    this->hitbox.x = x;
    this->hitbox.y = y;
    this->hitbox.w = 30;
    this->hitbox.h = 30;
    BulletTexture = TextureManager::LoadTexture("Images/main_ss.png");

    //ctor
}

Bullet::~Bullet()
{
    //dtor
}

void Bullet::draw()
{
    SDL_RenderCopyEx(Game::renderer, BulletTexture, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);

    SDL_RenderDrawRect( Game::renderer, &this->hitbox );

}

bool Bullet::getHit()
{
    return hit;
}

void Bullet::Update(long int frame, SDL_Rect tempRect, int, int, SDL_Rect Target)
{

        spriteBullets[ 0 ].x = 199;
        spriteBullets[ 0 ].y = 123;
        spriteBullets[ 0 ].w = 21;
        spriteBullets[ 0 ].h = 12;

        //load game
        spriteBullets[ 1 ].x = 219;
        spriteBullets[ 1 ].y = 123;
        spriteBullets[ 1 ].w = 21;
        spriteBullets[ 1 ].h = 12;

        //Instructions
        spriteBullets[ 2 ].x = 241;
        spriteBullets[ 2 ].y = 123;
        spriteBullets[ 2 ].w = 21;
        spriteBullets[ 2 ].h = 12;

        //Quit
        spriteBullets[ 3 ].x = 262;
        spriteBullets[ 3 ].y = 123;
        spriteBullets[ 3 ].w = 21;
        spriteBullets[ 3 ].h = 12;

        //Hover
        spriteBullets[ 4 ].x = 282;
        spriteBullets[ 4 ].y = 123;
        spriteBullets[ 4 ].w = 21;
        spriteBullets[ 4 ].h = 12;
       //new game
        spriteBullets[ 5 ].x = 305;
        spriteBullets[ 5 ].y = 123;
        spriteBullets[ 5 ].w = 21;
        spriteBullets[ 5 ].h = 12;

        //load game
        spriteBullets[ 6 ].x = 324;
        spriteBullets[ 6 ].y = 119;
        spriteBullets[ 6 ].w = 21;
        spriteBullets[ 6 ].h = 12;

        //Instructions
        spriteBullets[ 7 ].x = 343;
        spriteBullets[ 7 ].y = 119;
        spriteBullets[ 7 ].w = 17;
        spriteBullets[ 7 ].h = 17;

        //Quit
        spriteBullets[ 8 ].x = 363;
        spriteBullets[ 8 ].y = 119;
        spriteBullets[ 8 ].w = 17;
        spriteBullets[ 8 ].h = 17;

    srcRect = spriteBullets[frame%9];
    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x =   tempRect.x +x;
    destRect.y = tempRect.y+ y;

hitbox.x = destRect.x;
hitbox.y = destRect.y;


}
