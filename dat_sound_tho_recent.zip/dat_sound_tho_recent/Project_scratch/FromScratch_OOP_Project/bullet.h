#ifndef BULLET_H
#define BULLET_H

#include "Object.h"
#include "TextureManager.h"
#include "OperatorOverloading.h"
class Bullet : public Object
{
private:
    bool hit;
public:
    Bullet(int, int);
    ~Bullet();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int, SDL_Rect Target);
    SDL_Rect spriteBullets[9];
    bool getHit();

protected:
//    int wallX;
//    int wallY;
     SDL_Texture* BulletTexture;
     SDL_Rect hitbox;

};

#endif // BULLET_H
