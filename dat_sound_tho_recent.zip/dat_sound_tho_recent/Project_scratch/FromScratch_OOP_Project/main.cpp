#include "Game.h"

Game* game = NULL;
Game* Game::instance = NULL;

int *arrayObjects = NULL;

void sortedArray(int NoOfObjects)
{
    arrayObjects = new int[NoOfObjects];

    int i;
    int j;
    int temp;
    for (i=0; i<NoOfObjects; i++)
    {
        for (j=i+1; j<NoOfObjects; j++)
        {
            if (arrayObjects[j] < arrayObjects[i])
            {
                temp = arrayObjects[i];
                arrayObjects[i] = arrayObjects[j];
                arrayObjects[j] = temp;
            }
        }
    }


}


int main(int argc, char* argv[])
{

    const int FPS = 24;
    const int frameDelay = 1000 / FPS;

    Uint32 frameStart;
    int frameTime;

    game = Game::getInstance();
    game->init("Project", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1024, 768, false);
    while (game->running())
    {
        frameStart = SDL_GetTicks();

        game->handleEvents();
        game->update();
        game->render();

        frameTime = SDL_GetTicks() - frameStart;

        if (frameDelay > frameTime)
        {
            SDL_Delay(frameDelay - frameTime);
        }

    }
    game->clean();
    return 0;

}
