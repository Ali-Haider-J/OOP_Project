#include "turret.h"

Turret::Turret(int x, int y)
{
    this->hit = false;
    this-> x = x;
    this-> y = y;
    this->hitbox.x = x;
    this->hitbox.y = y;
    this->hitbox.w = 30;
    this->hitbox.h = 30;
    TurretTexture = TextureManager::LoadTexture("Images/main_ss.png");
    //ctor
}

Turret::~Turret()
{
    //dtor
}

void Turret::draw()
{
    SDL_RenderCopyEx(Game::renderer, TurretTexture, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);

    SDL_RenderDrawRect( Game::renderer, &this->hitbox );
}

bool Turret::getHit()
{
    return hit;
}

void Turret::Update(long int frame, SDL_Rect tempRect, int , int , SDL_Rect Target)
{
        spriteTurret.x = 0;
        spriteTurret.y = 990;
        spriteTurret.w = 69;
        spriteTurret.h = 43;

    srcRect = spriteTurret;
    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x =   tempRect.x +x;
    destRect.y = tempRect.y+ y;

hitbox.x = destRect.x;
hitbox.y = destRect.y;

}
