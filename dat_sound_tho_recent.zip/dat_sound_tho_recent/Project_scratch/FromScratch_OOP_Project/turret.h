#ifndef TURRET_H
#define TURRET_H

#include "Object.h"
#include "TextureManager.h"
#include "OperatorOverloading.h"

class Turret : public Object
{
private:
    bool hit;
public:
    Turret(int, int);
    ~Turret();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int, SDL_Rect Target);
    SDL_Rect spriteTurret;
    bool getHit();

protected:
//    int wallX;
//    int wallY;
     SDL_Texture* TurretTexture;
     SDL_Rect hitbox;

};

#endif // TURRET_H
