#include "EnemyOne.h"

EnemyOne::EnemyOne()
{


}

EnemyOne::EnemyOne(int posx, int posy)
{
    this->dying = -1;
    this->HP = 3;
    this->alive = true;
    this->x = posx;
    this->y = posy;
    proximityX = 400;
    proximityY = 250;
    active = false;
    inMotion = false;
    counter = 0;
    destRect.x = destRect.y = 0;
    delay = 0;
    attack_state = 0;

    spawned = true;
    EnemyOneTex =  TextureManager::LoadTexture("Images/main_ss.png");
    SDL_Init( SDL_INIT_AUDIO );
    Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 2, 2048 );
    gspawn = Mix_LoadWAV( "sound/spawn.wav" );
    gwhoosh = Mix_LoadWAV("sound/whoosh.wav");
    this->hit = false;
}


EnemyOne::~EnemyOne()
{
    std::cout << "DESTRUCTOR CALLED " << std::endl;
    Mix_FreeChunk( gspawn );
    gspawn = NULL;
    Mix_Quit();


}


void EnemyOne::draw()
{

     SDL_RenderCopyEx(Game::renderer, EnemyOneTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);
     SDL_SetRenderDrawColor( Game::renderer, 0x00, 0x00, 0x00, 0x00 );
     SDL_RenderDrawRect( Game::renderer, &this->hitbox );
}

void EnemyOne::Update(long int frame, SDL_Rect tempRect, int xpos, int ypos, SDL_Rect Target)
{

    hit = false;
    if (HP == 0)
        dying = 0;


    std::cout << "Enemy NUMBER " << enemyNo << std::endl;
   // std::cout << "YPOS IS :               " << ypos << std::endl;
    if (xpos >= x + proximityX or xpos <= x - proximityX or abs(ypos) >= abs(y) + proximityY or abs(ypos) <= abs(y) - proximityY or delay <= 1)
    {
        active = false;
    }
    else
    {

        active = true;
    }

    if (dying == 0)
    {
        active = false;
        inMotion = false;
    }

    if (active & !inMotion)
    {

        tempx = xpos;
        tempy = ypos;
        if (frame % 7 == 0)           ///proportional to the number of times enemy blinks before launching
        {
            attack_state++;
        }
        if (attack_state == 5)
        {

            inMotion = true;


        }
    }
    if (active & inMotion)
    {
        if (counter == 1)
        {
            Mix_PlayChannel( -1, gwhoosh, 0 );
            Mix_Volume(-1, 8);
        }
        for (int i = counter; i <= counter; i++)
            attack(tempx,tempy);
        counter++;
    }

   // std::cout << "ACTIVE  : " << active << std::endl;
   // std::cout << "x      " << x << std::endl;

    if (spawned)
    {
    //SPAWN_ANIMATION
    //frame 0
    spriteClips_spawn_animation[0].x = 0;
    spriteClips_spawn_animation[0].y = 787;
    spriteClips_spawn_animation[0].w = 50;
    spriteClips_spawn_animation[0].h = 42;

    //frame 1
    spriteClips_spawn_animation[1].x = 50;
    spriteClips_spawn_animation[1].y = 787;
    spriteClips_spawn_animation[1].w = 50;
    spriteClips_spawn_animation[1].h = 42;

    //frame 2
    spriteClips_spawn_animation[2].x = 100;
    spriteClips_spawn_animation[2].y = 787;
    spriteClips_spawn_animation[2].w = 50;
    spriteClips_spawn_animation[2].h = 42;

    //frame 3
    spriteClips_spawn_animation[3].x = 150;
    spriteClips_spawn_animation[3].y = 787;
    spriteClips_spawn_animation[3].w = 50;
    spriteClips_spawn_animation[3].h = 42;

    //frame 4
    spriteClips_spawn_animation[4].x = 200;
    spriteClips_spawn_animation[4].y = 787;
    spriteClips_spawn_animation[4].w = 50;
    spriteClips_spawn_animation[4].h = 42;

    //frame 5
    spriteClips_spawn_animation[5].x = 250;
    spriteClips_spawn_animation[5].y = 787;
    spriteClips_spawn_animation[5].w = 50;
    spriteClips_spawn_animation[5].h = 42;

    //frame 6
    spriteClips_spawn_animation[6].x = 300;
    spriteClips_spawn_animation[6].y = 787;
    spriteClips_spawn_animation[6].w = 50;
    spriteClips_spawn_animation[6].h = 42;

    //frame 7
    spriteClips_spawn_animation[7].x = 350;
    spriteClips_spawn_animation[7].y = 787;
    spriteClips_spawn_animation[7].w = 50;
    spriteClips_spawn_animation[7].h = 42;

    //frame 8
    spriteClips_spawn_animation[8].x = 400;
    spriteClips_spawn_animation[8].y = 787;
    spriteClips_spawn_animation[8].w = 50;
    spriteClips_spawn_animation[8].h = 42;

    srcRect = spriteClips_spawn_animation[frame % 9];
  //  std::cout << "Delay is :" << delay << std::endl;
    delay++;

    }

    {
    //ENEMY_EYE_BLINK_RIGHT
    //frame 0
    spriteClips_enemy_eye_blink_right[0].x = 63;
    spriteClips_enemy_eye_blink_right[0].y = 1210;
    spriteClips_enemy_eye_blink_right[0].w = 24;
    spriteClips_enemy_eye_blink_right[0].h = 24;

    //frame 1
    spriteClips_enemy_eye_blink_right[1].x = 87;
    spriteClips_enemy_eye_blink_right[1].y = 1210;
    spriteClips_enemy_eye_blink_right[1].w = 24;
    spriteClips_enemy_eye_blink_right[1].h = 24;

    //frame 2
    spriteClips_enemy_eye_blink_right[2].x = 111;
    spriteClips_enemy_eye_blink_right[2].y = 1210;
    spriteClips_enemy_eye_blink_right[2].w = 24;
    spriteClips_enemy_eye_blink_right[2].h = 24;

    //frame 3
    spriteClips_enemy_eye_blink_right[3].x = 135;
    spriteClips_enemy_eye_blink_right[3].y = 1210;
    spriteClips_enemy_eye_blink_right[3].w = 24;
    spriteClips_enemy_eye_blink_right[3].h = 24;

    //frame 4
    spriteClips_enemy_eye_blink_right[4].x = 135;
    spriteClips_enemy_eye_blink_right[4].y = 1210;
    spriteClips_enemy_eye_blink_right[4].w = 24;
    spriteClips_enemy_eye_blink_right[4].h = 24;

    //frame 5
    spriteClips_enemy_eye_blink_right[5].x = 111;
    spriteClips_enemy_eye_blink_right[5].y = 1210;
    spriteClips_enemy_eye_blink_right[5].w = 24;
    spriteClips_enemy_eye_blink_right[5].h = 24;

    //frame 6
    spriteClips_enemy_eye_blink_right[6].x = 87;
    spriteClips_enemy_eye_blink_right[6].y = 1210;
    spriteClips_enemy_eye_blink_right[6].w = 24;
    spriteClips_enemy_eye_blink_right[6].h = 24;

    //ENEMY_EYE_BLINK_LEFT
    //frame 0
    spriteClips_enemy_eye_blink_left[0].x = 231;
    spriteClips_enemy_eye_blink_left[0].y = 1210;
    spriteClips_enemy_eye_blink_left[0].w = 24;
    spriteClips_enemy_eye_blink_left[0].h = 24;

    //frame 1
    spriteClips_enemy_eye_blink_left[1].x = 207;
    spriteClips_enemy_eye_blink_left[1].y = 1210;
    spriteClips_enemy_eye_blink_left[1].w = 24;
    spriteClips_enemy_eye_blink_left[1].h = 24;

    //frame 2
    spriteClips_enemy_eye_blink_left[2].x = 183;
    spriteClips_enemy_eye_blink_left[2].y = 1210;
    spriteClips_enemy_eye_blink_left[2].w = 24;
    spriteClips_enemy_eye_blink_left[2].h = 24;

    //frame 3
    spriteClips_enemy_eye_blink_left[3].x = 159;
    spriteClips_enemy_eye_blink_left[3].y = 1210;
    spriteClips_enemy_eye_blink_left[3].w = 24;
    spriteClips_enemy_eye_blink_left[3].h = 24;

    //frame 4
    spriteClips_enemy_eye_blink_left[4].x = 159;
    spriteClips_enemy_eye_blink_left[4].y = 1210;
    spriteClips_enemy_eye_blink_left[4].w = 24;
    spriteClips_enemy_eye_blink_left[4].h = 24;

    //frame 5
    spriteClips_enemy_eye_blink_left[5].x = 183;
    spriteClips_enemy_eye_blink_left[5].y = 1210;
    spriteClips_enemy_eye_blink_left[5].w = 24;
    spriteClips_enemy_eye_blink_left[5].h = 24;

    //frame 6
    spriteClips_enemy_eye_blink_left[6].x = 207;
    spriteClips_enemy_eye_blink_left[6].y = 1210;
    spriteClips_enemy_eye_blink_left[6].w = 24;
    spriteClips_enemy_eye_blink_left[6].h = 24;


    //ENEMY_MOVE_RIGHT
    //frame 0
    spriteClips_enemy_move_right[0].x = 63;
    spriteClips_enemy_move_right[0].y = 1234;
    spriteClips_enemy_move_right[0].w = 24;
    spriteClips_enemy_move_right[0].h = 24;

    //frame 1
    spriteClips_enemy_move_right[1].x = 87;
    spriteClips_enemy_move_right[1].y = 1234;
    spriteClips_enemy_move_right[1].w = 24;
    spriteClips_enemy_move_right[1].h = 24;

    //frame 2
    spriteClips_enemy_move_right[2].x = 111;
    spriteClips_enemy_move_right[2].y = 1234;
    spriteClips_enemy_move_right[2].w = 24;
    spriteClips_enemy_move_right[2].h = 24;

    //ENEMY_MOVE_LEFT
    //frame 0
    spriteClips_enemy_move_left[0].x = 231;
    spriteClips_enemy_move_left[0].y = 1234;
    spriteClips_enemy_move_left[0].w = 24;
    spriteClips_enemy_move_left[0].h = 24;

    //frame 1
    spriteClips_enemy_move_left[1].x = 207;
    spriteClips_enemy_move_left[1].y = 1234;
    spriteClips_enemy_move_left[1].w = 24;
    spriteClips_enemy_move_left[1].h = 24;

    //frame 2
    spriteClips_enemy_move_left[2].x = 183;
    spriteClips_enemy_move_left[2].y = 1234;
    spriteClips_enemy_move_left[2].w = 24;
    spriteClips_enemy_move_left[2].h = 24;

    //ENEMY_MOVE_UP_RIGHT
    //frame 0
    spriteClips_enemy_move_up_right[0].x = 63;
    spriteClips_enemy_move_up_right[0].y = 1258;
    spriteClips_enemy_move_up_right[0].w = 24;
    spriteClips_enemy_move_up_right[0].h = 24;

    //frame 1
    spriteClips_enemy_move_up_right[1].x = 87;
    spriteClips_enemy_move_up_right[1].y = 1258;
    spriteClips_enemy_move_up_right[1].w = 24;
    spriteClips_enemy_move_up_right[1].h = 24;

    //frame 2
    spriteClips_enemy_move_up_right[2].x = 111;
    spriteClips_enemy_move_up_right[2].y = 1258;
    spriteClips_enemy_move_up_right[2].w = 24;
    spriteClips_enemy_move_up_right[2].h = 24;

    //frame 3
    spriteClips_enemy_move_up_right[3].x = 63;
    spriteClips_enemy_move_up_right[3].y = 1282;
    spriteClips_enemy_move_up_right[3].w = 24;
    spriteClips_enemy_move_up_right[3].h = 24;

    //frame 4
    spriteClips_enemy_move_up_right[4].x = 87;
    spriteClips_enemy_move_up_right[4].y = 1282;
    spriteClips_enemy_move_up_right[4].w = 24;
    spriteClips_enemy_move_up_right[4].h = 24;

    //ENEMY_MOVE_UP_LEFT
    //frame 0
    spriteClips_enemy_move_up_left[0].x = 231;
    spriteClips_enemy_move_up_left[0].y = 1258;
    spriteClips_enemy_move_up_left[0].w = 24;
    spriteClips_enemy_move_up_left[0].h = 24;

    //frame 1
    spriteClips_enemy_move_up_left[1].x = 207;
    spriteClips_enemy_move_up_left[1].y = 1258;
    spriteClips_enemy_move_up_left[1].w = 24;
    spriteClips_enemy_move_up_left[1].h = 24;

    //frame 2
    spriteClips_enemy_move_up_left[2].x = 183;
    spriteClips_enemy_move_up_left[2].y = 1258;
    spriteClips_enemy_move_up_left[2].w = 24;
    spriteClips_enemy_move_up_left[2].h = 24;

    //frame 3
    spriteClips_enemy_move_up_left[3].x = 231;
    spriteClips_enemy_move_up_left[3].y = 1282;
    spriteClips_enemy_move_up_left[3].w = 24;
    spriteClips_enemy_move_up_left[3].h = 24;

    //frame 4
    spriteClips_enemy_move_up_left[4].x = 207;
    spriteClips_enemy_move_up_left[4].y = 1282;
    spriteClips_enemy_move_up_left[4].w = 24;
    spriteClips_enemy_move_up_left[4].h = 24;

    //ENEMY_MOVE_DOWN_RIGHT
    //frame 0
    spriteClips_enemy_move_down_right[0].x = 231;
    spriteClips_enemy_move_down_right[0].y = 1282;
    spriteClips_enemy_move_down_right[0].w = 24;
    spriteClips_enemy_move_down_right[0].h = 24;

    //frame 1
    spriteClips_enemy_move_down_right[1].x = 183;
    spriteClips_enemy_move_down_right[1].y = 1258;
    spriteClips_enemy_move_down_right[1].w = 24;
    spriteClips_enemy_move_down_right[1].h = 24;

    //frame 2
    spriteClips_enemy_move_down_right[2].x = 207;
    spriteClips_enemy_move_down_right[2].y = 1258;
    spriteClips_enemy_move_down_right[2].w = 24;
    spriteClips_enemy_move_down_right[2].h = 24;

    //frame 3
    spriteClips_enemy_move_down_right[3].x = 231;
    spriteClips_enemy_move_down_right[3].y = 1258;
    spriteClips_enemy_move_down_right[3].w = 24;
    spriteClips_enemy_move_down_right[3].h = 24;

    //frame 4
    spriteClips_enemy_move_down_right[4].x = 231;
    spriteClips_enemy_move_down_right[4].y = 1258;
    spriteClips_enemy_move_down_right[4].w = 24;
    spriteClips_enemy_move_down_right[4].h = 24;

    //ENEMY_MOVE_DOWN_LEFT
    //frame 0
    spriteClips_enemy_move_down_left[0].x = 63;
    spriteClips_enemy_move_down_left[0].y = 1282;
    spriteClips_enemy_move_down_left[0].w = 24;
    spriteClips_enemy_move_down_left[0].h = 24;

    //frame 1
    spriteClips_enemy_move_down_left[1].x = 111;
    spriteClips_enemy_move_down_left[1].y = 1258;
    spriteClips_enemy_move_down_left[1].w = 24;
    spriteClips_enemy_move_down_left[1].h = 24;

    //frame 2
    spriteClips_enemy_move_down_left[2].x = 87;
    spriteClips_enemy_move_down_left[2].y = 1258;
    spriteClips_enemy_move_down_left[2].w = 24;
    spriteClips_enemy_move_down_left[2].h = 24;

    //frame 3
    spriteClips_enemy_move_down_left[3].x = 63;
    spriteClips_enemy_move_down_left[3].y = 1258;
    spriteClips_enemy_move_down_left[3].w = 24;
    spriteClips_enemy_move_down_left[3].h = 24;

    //frame 4
    spriteClips_enemy_move_down_left[4].x = 63;
    spriteClips_enemy_move_down_left[4].y = 1258;
    spriteClips_enemy_move_down_left[4].w = 24;
    spriteClips_enemy_move_down_left[4].h = 24;


    //EXPLOSION
    //frame 0
    spriteClips_enemy_explosion[0].x = 26;
    spriteClips_enemy_explosion[0].y = 1546;
    spriteClips_enemy_explosion[0].w = 24;
    spriteClips_enemy_explosion[0].h = 24;

    //frame 1
    spriteClips_enemy_explosion[1].x = 50;
    spriteClips_enemy_explosion[1].y = 1544;
    spriteClips_enemy_explosion[1].w = 30;
    spriteClips_enemy_explosion[1].h = 30;

    //frame 2
    spriteClips_enemy_explosion[2].x = 81;
    spriteClips_enemy_explosion[2].y = 1544;
    spriteClips_enemy_explosion[2].w = 28;
    spriteClips_enemy_explosion[2].h = 30;


    //frame 3
    spriteClips_enemy_explosion[3].x = 110;
    spriteClips_enemy_explosion[3].y = 1544;
    spriteClips_enemy_explosion[3].w = 27;
    spriteClips_enemy_explosion[3].h = 30;


    //frame 4
    spriteClips_enemy_explosion[4].x = 138;
    spriteClips_enemy_explosion[4].y = 1544;
    spriteClips_enemy_explosion[4].w = 28;
    spriteClips_enemy_explosion[4].h = 30;


    //frame 5
    spriteClips_enemy_explosion[5].x = 167;
    spriteClips_enemy_explosion[5].y = 1544;
    spriteClips_enemy_explosion[5].w = 28;
    spriteClips_enemy_explosion[5].h = 30;


    }

    if(spawned && (frame % 9 == 0))
    {
        Mix_PlayChannel( -1, gspawn, 0 );
        Mix_Volume(-1, 8);
    }
    if (!spawned)
    {
        if (!active)
            srcRect = spriteClips_enemy_eye_blink_left[3];
        else if ((active) & (!inMotion) & (xpos <= x))
            srcRect = spriteClips_enemy_eye_blink_left[frame % 7];
        else if ((active) & (!inMotion) & (xpos >= x))
            srcRect = spriteClips_enemy_eye_blink_right[frame % 7];
        else
        {
            if (xpos >= x)
            {
                if ((abs(xpos) - abs(x) <= abs(y) - abs(ypos)))
                    srcRect = spriteClips_enemy_move_right[frame % 3];
                else if ((abs(x) - abs(xpos) >= abs(y) - abs(ypos)) & (ypos - y >= 0))
                    srcRect = spriteClips_enemy_move_up_right[frame % 5];
                else if ((abs(xpos) - abs(x) >= abs(y) - abs(ypos)) & (ypos - y <= 0))
                    srcRect = spriteClips_enemy_move_down_right[frame % 5];
            }

            else if (xpos <= x)
            {
                if (abs(xpos) - abs(x) <= abs(y) - abs(ypos))
                  srcRect = spriteClips_enemy_move_left[frame % 3];
                else if ((abs(x) - abs(x) >= abs(y) - abs(ypos)) & (ypos - y >= 0))
                  srcRect = spriteClips_enemy_move_up_left[frame % 5];
                else if ((abs(xpos) - abs(x) >= abs(y) - abs(ypos)) & (ypos - y <= 0))
                  srcRect = spriteClips_enemy_move_down_left[frame % 5];
            }
        }

    }

    int adjustX = 0;
    int adjustY = 0;
    if ((srcRect.x == spriteClips_spawn_animation[frame % 9].x) & (srcRect.y == spriteClips_spawn_animation[frame % 9].y) & (srcRect.w == spriteClips_spawn_animation[frame % 9].w) & (srcRect.h == spriteClips_spawn_animation[frame % 9].h))
    {
        adjustX = -33;
        adjustY = -20;
    }

    if (dying >= 0)
    {
        srcRect = spriteClips_enemy_explosion[dying];
        HP = -1;
        dying++;
    }

    if (dying == 5)
    {
        this->alive = false;
    }

    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x = x + tempRect.x + adjustX;
    destRect.y = y + tempRect.y + adjustY;

    this->hitbox.x = destRect.x;
    this->hitbox.y = destRect.y;
    this->hitbox.w = 50;
    this->hitbox.h = 50;


    if ((spawned) & (delay >= 9))    ///initial delay before launching for the portal animation to complete
        spawned = false;

    if (inMotion)
    {
        if ((((hitbox.x + hitbox.w > Target.x + Target.w) & (hitbox.x < Target.x + Target.w)) or ((hitbox.x + hitbox.w < Target.x + Target.w) & (hitbox.x > Target.x)) or ((hitbox.x + hitbox.w < Target.x + Target.w) & (hitbox.x + hitbox.w > Target.x )))
        & (((hitbox.y + hitbox.h >= Target.y + Target.h) & (hitbox.y < Target.y + Target.h)) or ((hitbox.y + hitbox.h >= Target.y + Target.h) & (hitbox.y < Target.y)) or ((hitbox.y + hitbox.h <= Target.y + Target.h) & (hitbox.y + hitbox.h > Target.y ))))
        {
            this->hit = true;
            std::cout << "-------------------------------HIT X & HIT Y--------------------" << std::endl;
        }
    }



}

void EnemyOne::attack(int targetX, int targetY)
{

       // std::cout << "---------------------------------Enemy Y is : " << y << std::endl;
    if (targetX >= x)
           x += (abs(targetX)-abs(x))/5;
    else if (targetX <= x)
            x += (abs(targetX)-abs(x))/5;
    // std::cout << "------------------------------------------Enemy X is : " << x << std::endl;
    if (targetY <= -y)
            y += ((abs(targetY)-abs(y))/5)+2;
    else if (targetY >= -y)
            y += ((abs(targetY)-abs(y))/5)+2;
    attack_state = 0;
    if (counter == 15)              ///delay between the enemy's launches
    {
        inMotion = false;
        counter = 0;
    }
}

bool EnemyOne::getHit()
{
    return hit;
}

void EnemyOne::gotAttacked(SDL_Rect Target)
{
    if ((((hitbox.x + hitbox.w > Target.x + Target.w) & (hitbox.x < Target.x + Target.w)) or ((hitbox.x + hitbox.w < Target.x + Target.w) & (hitbox.x > Target.x)) or ((hitbox.x + hitbox.w < Target.x + Target.w) & (hitbox.x + hitbox.w > Target.x )))
    & (((hitbox.y + hitbox.h >= Target.y + Target.h) & (hitbox.y < Target.y + Target.h)) or ((hitbox.y + hitbox.h >= Target.y + Target.h) & (hitbox.y < Target.y)) or ((hitbox.y + hitbox.h <= Target.y + Target.h) & (hitbox.y + hitbox.h > Target.y ))))
    {
        this->HP--;
    }
}

bool EnemyOne::getAlive()
{
    return this->alive;
}

int EnemyOne::getY()
{
    return this->y;
}
