#include "Object.h"

Object::Object()
{


}

Object::~Object()
{


}

int Object::getX()
{


}

int Object::getY()
{

}

void Object::setX(float x)
{

}

void Object::setY(float y)
{

}

void Object::setUpMov(bool)
{

}

void Object::setDownMov(bool)
{

}

void Object::setRightMov(bool)
{


}

void Object::setLeftMov(bool)
{

}

void Object::setIdle(bool)
{

}

bool Object::getActive()
{

}

void Object::setAttack(bool)
{

}

SDL_Rect Object::camera()
{

}

void Object::Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target)
{


}

void Object::hitWall(bool a, bool b, bool c, bool d)
{

}

void Object::draw()
{


}

void Object::gotAttacked(SDL_Rect Target)
{

}

void Object::setClicked(bool clicked)
{

}

bool Object::getNewGame()
{

}

bool Object::getQuit()
{

}

bool Object::getInstruction()
{

}

void Object::setInstruction(bool instruction)
{

}

SDL_Rect Object::getHitbox()
{

}

bool Object::getHit()
{

}

void Object::setHit(bool hit)
{

}

SDL_Rect Object::getAttackbox()
{

}

void Object::save()
{

}

bool Object::getLoad()
{

}

void Object::setLoad(bool load)
{

}

void Object::setNewGame(bool newGame)
{

}

void Object::setDodge(bool)
{

}

int Object::getStamina()
{

}

void Object::hitBarrier(bool hitL, bool hitU)
{

}

bool Object::getHitL()
{

}


bool Object::getHitU()
{

}

void Object::setBarrierTrigger(bool)
{

}

bool Object::getAlive()
{

}

bool Object::enemyChecker(bool)
{

}

bool Object::getBarrierTrigger()
{

}

void Object::setBarrierU(bool)
{

}


void Object::setBarrierL(bool)
{

}

void Object::setEnemySpawn(bool)
{

}

void Object::setfile_empty(bool)
{

}
bool Object::getfile_empty()
{

}

void Object::drawLoad()
{

}

void Object::Update_Load(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target)
{

}
