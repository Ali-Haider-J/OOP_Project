#pragma once
#include "Unit.h"
#include "SDL_mixer.h"

class Player : public Unit
{
private:
    bool barrierL;
    bool barrierU;
    bool save;
    float speedX;
    float speedY;
    float speedD;
    bool dodging;
    static Player* instance;
    bool active;
    int health;
    int stamina;
    Player(const char* textureSheet, int x, int y);
    bool rightMov = false;
    bool upMov = false;
    bool leftMov = false;
    bool idle = true;
    bool downMov = false;
    char lastMov;
    bool attacking = false;
    bool attackAlt = false;
    int c;
    int tempCounter;
    bool invulnerability;

    SDL_Rect attackHitbox;
    Mix_Chunk *gfootstep1 = NULL;
    Mix_Chunk *gfootstep2 = NULL;
    Mix_Chunk *gslash1 = NULL;
    Mix_Chunk *gslash2 = NULL;
    Mix_Chunk *gwhoosh = NULL;

    enum ANIMATION_FRAMES {FLYING_FRAMES = 12};
    SDL_Rect spriteClips[ FLYING_FRAMES ];
    SDL_Rect spriteClips_down[ FLYING_FRAMES ];
    SDL_Rect spriteClips_right[ FLYING_FRAMES ];
    SDL_Rect spriteClips_left[ FLYING_FRAMES ];

    SDL_Rect spriteClips_idle_up[ 1 ];
    SDL_Rect spriteClips_idle_down[ 1 ];
    SDL_Rect spriteClips_idle_right[ 1 ];
    SDL_Rect spriteClips_idle_left[ 1 ];

    SDL_Rect spriteClips_attack_right[7];
    SDL_Rect spriteClips_attack_right_alt[6];
    SDL_Rect spriteClips_attack_left[7];
    SDL_Rect spriteClips_attack_left_alt[6];
    SDL_Rect spriteClips_attack_up[7];
    SDL_Rect spriteClips_attack_up_alt[7];
    SDL_Rect spriteClips_attack_down[7];
    SDL_Rect spriteClips_attack_down_alt[7];

    SDL_Rect spriteClips_dodge_right[8];
    SDL_Rect spriteClips_dodge_left[8];
    SDL_Rect spriteClips_dodge_down[8];
    SDL_Rect spriteClips_dodge_up[8];

    SDL_Rect spriteClips_get_hit_right[4];
    SDL_Rect spriteClips_get_hit_left[4];

    SDL_Rect spriteClips_death[10];
    SDL_Rect spriteClips_UI[1];
    bool elevating;
    int indFrame;
    int dodgeFrame;
    bool barrierTrigger;
    bool enemySpawn;

public:

    int startX;
    int startY;
    void setX(float);
    void setY(float);
    int getX();
    int getY();
    //void hitWall(bool, bool, bool, bool);
    void hitBarrier(bool, bool);
    void setRightMov(bool right);
    void setLeftMov(bool left);
    void setDownMov(bool down);
    void setUpMov(bool up);
    bool getIdle();
    void setIdle(bool idle);
    SDL_Rect camera();
    ~Player();
    static Player* getInstance(int, int);
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target);
    void attack(int, int);
    void setAttack(bool attack);
    bool getActive();
    void getInput();
    void displayUI();
    void dash();
    SDL_Rect getHitbox();
    bool getHit();
    void setHit(bool);
    bool getBarrierTrigger();
    SDL_Rect getAttackbox();
    void setDodge(bool dodge);
    int getStamina();
    void setBarrierTrigger(bool);
    bool enemiesChecker(int);
    bool hitUpWall();
    bool hitDownWall();
    bool hitLeftWall();
    bool hitRightWall();
    void setBarrierL(bool);
    void setBarrierU(bool);
    void setEnemySpawn(bool);
};
