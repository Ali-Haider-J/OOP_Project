#include "Enemy.h"

Enemy::Enemy()
{
    enemyNo++;

}

int Enemy::enemyNo = 0;                                                                             ///Initializing the static truck number with 0

Enemy::~Enemy()
{
    enemyNo--;

}

void Enemy::draw()
{

}
void Enemy::Update(long int frame, SDL_Rect spriteClips_animation, int a, int b, SDL_Rect Target)
{

}

void Enemy::attack(int, int)
{

}

void Enemy::gotAttacked(SDL_Rect player)
{

}

int Enemy::getY()
{

}
