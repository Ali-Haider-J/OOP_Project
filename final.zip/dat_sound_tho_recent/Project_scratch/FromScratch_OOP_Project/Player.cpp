#include "Player.h"

using namespace std;

Player::Player(const char* textureSheet, int x, int y)
{
    this->alive = true;
    this->hit = false;
    elevating = false;
    barrierTrigger2 = false;
    barrierL = barrierU = false;

    dodging = false;
    dodgeFrame = -1;
    lastMov = 'D';
    upMov = false;
    downMov = true;
    rightMov = false;
    leftMov = false;
    objTexture = TextureManager::LoadTexture(textureSheet);
    this->x = x;
    this->y = y;
    speedX = 12;
    speedY = 12;
    speedD = 8;
     this->hitbox.x = x - 10;
    this->hitbox.y = y + 6;
    this->hitbox.w = 28;
    this->hitbox.h = 30;
    attackHitbox.x = attackHitbox.y = attackHitbox.w = attackHitbox.h = 0;
    stamina = 50;
    health = 50;
    indFrame = -1;
    this->active = true;
    SDL_Init( SDL_INIT_AUDIO );
    Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 2, 2048 );
    gfootstep1 = Mix_LoadWAV( "sound/footsteps (1).wav" );
    gslash1 = Mix_LoadWAV( "sound/slash (1).wav" );
    gslash2 = Mix_LoadWAV( "sound/slash (2).wav" );
    gwhoosh = Mix_LoadWAV( "sound/whoosh.wav" );
    gfootstep2 = Mix_LoadWAV( "sound/footsteps (2).wav" );
    this->hit = false;
    this->invulnerability = false;
    c = 0;
    this->tempCounter = 0;
    barrierTrigger = false;
    enemySpawn = false;
}

Player::~Player()
{
    Mix_FreeChunk( gfootstep1 );
    Mix_FreeChunk( gfootstep2 );
    Mix_FreeChunk( gslash1 );
    Mix_FreeChunk( gslash2 );
    Mix_FreeChunk( gwhoosh );
    gfootstep1 = NULL;
    gfootstep2 = NULL;
    gslash1 = NULL;
    gslash2 = NULL;
    gwhoosh = NULL;
    Mix_Quit();
}

void Player::Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target)
{

    if(health <= 0)
    {
        attacking = false;
        invulnerability = true;
        indFrame++;
        hit = false;
        if (indFrame >= 9)
        {
            indFrame = 9;
            alive = false;
        }
        active = false;
        for (int i = indFrame; i <= indFrame; i ++)
        {
            srcRect = spriteClips_death[indFrame];
        }
    }

    if (x >= 2232 & x <= 2388 & y <= -620 & y >= -689)
   {
       barrierTrigger = true;
   }

   if (x >= 3028 & y <= -1491 & x <= 3400 & y >= -1515)
   {
       barrierTrigger2 = true;
   }




    stamina ++;
    if(stamina > 50)
    {
        stamina = 50;
    }




     if(x >= 1260 && x <= 1412 && y >= -2161 && y <= -2043)
    {
        elevating = true;
    }

    if(elevating)
    {
        srcRect = spriteClips_idle_up[0];
        active = false;
        y += 12;
        if(y >= -1327)
        {
            active = true;
            elevating = false;
        }
    }




    if (active)
    {
        if (rightMov & upMov)
        {
            x += speedD;
            y += speedD;
            if(hitRightWall())
            {
                x -= speedD;
            }
            if(hitUpWall())
            {
                y -= speedD;
            }
        }
        else if (leftMov & upMov)
        {
            x -= speedD;
            y += speedD;
            if(hitLeftWall())
            {
                x += speedD;
            }
            if(hitUpWall())
            {
                y -= speedD;
            }
        }
        else if (rightMov & downMov)
        {
            x += speedD;
            y -= speedD;
            if(hitRightWall())
            {
                x -= speedD;
            }
            if(hitDownWall())
            {
                y += speedD;
            }
        }
        else if (leftMov & downMov)
        {
            x -= speedD;
            y -= speedD;
            if(hitLeftWall())
            {
                x += speedD;
            }
            if(hitDownWall())
            {
                y += speedD;
            }
        }
        else if (rightMov)
        {
            x += speedX;
            if(hitRightWall())
            {
                x -= speedX;
            }
        }
        else if (leftMov)
        {
            x -= speedX;
            if(hitLeftWall())
            {
                x += speedX;
            }
        }
        else if (upMov)
        {
            y += speedY;
            if(hitUpWall())
            {
                y -= speedY;
            }
        }
        else if (downMov)
        {
            y -= speedY;
            if(hitDownWall())
            {
                y += speedY;
            }
        }
    }
        {
        //UP movement
        //Frame 0
        spriteClips[ 0 ].x =  0;
        spriteClips[ 0 ].y =  0;
        spriteClips[ 0 ].w = 16;
        spriteClips[ 0 ].h = 30;

        //Frame 1
        spriteClips[ 1 ].x =  16;
        spriteClips[ 1 ].y =  0;
        spriteClips[ 1 ].w = 16;
        spriteClips[ 1 ].h = 30;

        //Frame 2
        spriteClips[ 2 ].x =  32;
        spriteClips[ 2 ].y =  0;
        spriteClips[ 2 ].w = 16;
        spriteClips[ 2 ].h = 30;

        //Frame 3
        spriteClips[ 3 ].x =  48;
        spriteClips[ 3 ].y =  0;
        spriteClips[ 3 ].w = 16;
        spriteClips[ 3 ].h = 30;


        //Frame 4
        spriteClips[ 4 ].x = 64;
        spriteClips[ 4 ].y = 0;
        spriteClips[ 4 ].w = 16;
        spriteClips[ 4 ].h = 30;

        //Frame 5
        spriteClips[ 5 ].x = 80;
        spriteClips[ 5 ].y = 0;
        spriteClips[ 5 ].w = 16;
        spriteClips[ 5 ].h = 30;

        //Frame 6
        spriteClips[ 6 ].x = 96;
        spriteClips[ 6 ].y = 0;
        spriteClips[ 6 ].w = 16 ;
        spriteClips[ 6 ].h = 30;


        //Frame 7
        spriteClips[ 7 ].x = 112;
        spriteClips[ 7 ].y = 0;
        spriteClips[ 7 ].w = 16;
        spriteClips[ 7 ].h = 30;

        //Frame 8
        spriteClips[ 8 ].x = 128;
        spriteClips[ 8 ].y = 0;
        spriteClips[ 8 ].w = 16;
        spriteClips[ 8 ].h = 30;

        //Frame 9
        spriteClips[ 9 ].x = 144;
        spriteClips[ 9 ].y = 0;
        spriteClips[ 9 ].w = 16;
        spriteClips[ 9 ].h = 30;

        //Frame 10
        spriteClips[ 10 ].x = 160;
        spriteClips[ 10 ].y = 0;
        spriteClips[ 10 ].w = 16;
        spriteClips[ 10 ].h = 30;

        //Frame 11
        spriteClips[ 11 ].x = 176;
        spriteClips[ 11 ].y =  0;
        spriteClips[ 11 ].w = 16;
        spriteClips[ 11 ].h = 30;

        //DOWN movement
        //Frame 0
        spriteClips_down[ 0 ].x =   0;
        spriteClips_down[ 0 ].y =  30;
        spriteClips_down[ 0 ].w = 18;
        spriteClips_down[ 0 ].h = 31;

        //Frame 1
        spriteClips_down[ 1 ].x =  18;
        spriteClips_down[ 1 ].y =  30;
        spriteClips_down[ 1 ].w = 18;
        spriteClips_down[ 1 ].h = 31;

        //Frame 2
        spriteClips_down[ 2 ].x =  36;
        spriteClips_down[ 2 ].y =  30;
        spriteClips_down[ 2 ].w = 18;
        spriteClips_down[ 2 ].h = 31;

        //Frame 3
        spriteClips_down[ 3 ].x =  54;
        spriteClips_down[ 3 ].y =  30;
        spriteClips_down[ 3 ].w = 18;
        spriteClips_down[ 3 ].h = 31;

        //Frame 4
        spriteClips_down[ 4 ].x =  72;
        spriteClips_down[ 4 ].y =  30;
        spriteClips_down[ 4 ].w = 18;
        spriteClips_down[ 4 ].h = 31;

        //Frame 5
        spriteClips_down[ 5 ].x =  90;
        spriteClips_down[ 5 ].y =  30;
        spriteClips_down[ 5 ].w = 18;
        spriteClips_down[ 5 ].h = 31;

        //Frame 6
        spriteClips_down[ 6 ].x =  108;
        spriteClips_down[ 6 ].y =  30;
        spriteClips_down[ 6 ].w = 18;
        spriteClips_down[ 6 ].h = 31;


        //Frame 7
        spriteClips_down[ 7 ].x =  126;
        spriteClips_down[ 7 ].y =  30;
        spriteClips_down[ 7 ].w = 18;
        spriteClips_down[ 7 ].h = 31;

        //Frame 8
        spriteClips_down[ 8 ].x =  144;
        spriteClips_down[ 8 ].y =  30;
        spriteClips_down[ 8 ].w = 18;
        spriteClips_down[ 8 ].h = 31;

        //Frame 9
        spriteClips_down[ 9 ].x =  162;
        spriteClips_down[ 9 ].y =  30;
        spriteClips_down[ 9 ].w = 18;
        spriteClips_down[ 9 ].h = 31;

        //Frame 10
        spriteClips_down[ 10 ].x =  180;
        spriteClips_down[ 10 ].y =  30;
        spriteClips_down[ 10 ].w = 18;
        spriteClips_down[ 10 ].h = 31;

        //Frame 11
        spriteClips_down[ 11 ].x =  198;
        spriteClips_down[ 11 ].y =  30;
        spriteClips_down[ 11 ].w = 18;
        spriteClips_down[ 11 ].h = 31;

        //RIGHT movement
        //Frame 0
        spriteClips_right[ 0 ].x = 0;
        spriteClips_right[ 0 ].y =  61;
        spriteClips_right[ 0 ].w = 25;
        spriteClips_right[ 0 ].h = 30;

        //Frame 1
        spriteClips_right[ 1 ].x = 25;
        spriteClips_right[ 1 ].y =  61;
        spriteClips_right[ 1 ].w = 25;
        spriteClips_right[ 1 ].h = 30;

        //Frame 2
        spriteClips_right[ 2 ].x = 50;
        spriteClips_right[ 2 ].y =  61;
        spriteClips_right[ 2 ].w = 25;
        spriteClips_right[ 2 ].h = 30;

        //Frame 3
        spriteClips_right[ 3 ].x = 75;
        spriteClips_right[ 3 ].y =  61;
        spriteClips_right[ 3 ].w = 25;
        spriteClips_right[ 3 ].h = 30;

        //Frame 4
        spriteClips_right[ 4 ].x = 100;
        spriteClips_right[ 4 ].y = 61;
        spriteClips_right[ 4 ].w = 25;
        spriteClips_right[ 4 ].h = 30;

        //Frame 5
        spriteClips_right[ 5 ].x = 125;
        spriteClips_right[ 5 ].y = 61;
        spriteClips_right[ 5 ].w = 25;
        spriteClips_right[ 5 ].h = 30;

        //Frame 6
        spriteClips_right[ 6 ].x = 150;
        spriteClips_right[ 6 ].y = 61;
        spriteClips_right[ 6 ].w = 25;
        spriteClips_right[ 6 ].h = 30;


        //Frame 7
        spriteClips_right[ 7 ].x = 175;
        spriteClips_right[ 7 ].y = 61;
        spriteClips_right[ 7 ].w = 25;
        spriteClips_right[ 7 ].h = 30;

        //Frame 8
        spriteClips_right[ 8 ].x = 200;
        spriteClips_right[ 8 ].y = 61;
        spriteClips_right[ 8 ].w = 25;
        spriteClips_right[ 8 ].h = 30;

        //Frame 9
        spriteClips_right[ 9 ].x = 225;
        spriteClips_right[ 9 ].y = 61;
        spriteClips_right[ 9 ].w = 25;
        spriteClips_right[ 9 ].h = 30;

        //Frame 10
        spriteClips_right[ 10 ].x = 250;
        spriteClips_right[ 10 ].y = 61;
        spriteClips_right[ 10 ].w = 25;
        spriteClips_right[ 10 ].h = 30;

        //Frame 11
        spriteClips_right[ 11 ].x = 275;
        spriteClips_right[ 11 ].y =  61;
        spriteClips_right[ 11 ].w = 25;
        spriteClips_right[ 11 ].h = 30;

        //LEFT movement
        //Frame 0
        spriteClips_left[ 0 ].x = 275;
        spriteClips_left[ 0 ].y =  91;
        spriteClips_left[ 0 ].w = 25;
        spriteClips_left[ 0 ].h = 30;

        //Frame 1
        spriteClips_left[ 1 ].x =  250;
        spriteClips_left[ 1 ].y =  91;
        spriteClips_left[ 1 ].w = 25;
        spriteClips_left[ 1 ].h = 30;

        //Frame 2
        spriteClips_left[ 2 ].x =  225;
        spriteClips_left[ 2 ].y =  91;
        spriteClips_left[ 2 ].w = 25;
        spriteClips_left[ 2 ].h = 30;

        //Frame 3
        spriteClips_left[ 3 ].x =  200;
        spriteClips_left[ 3 ].y =  91;
        spriteClips_left[ 3 ].w = 25;
        spriteClips_left[ 3 ].h = 30;

        //Frame 4
        spriteClips_left[ 4 ].x = 175;
        spriteClips_left[ 4 ].y = 91;
        spriteClips_left[ 4 ].w = 25;
        spriteClips_left[ 4 ].h = 30;

        //Frame 5
        spriteClips_left[ 5 ].x = 150;
        spriteClips_left[ 5 ].y = 91;
        spriteClips_left[ 5 ].w = 25;
        spriteClips_left[ 5 ].h = 30;

        //Frame 6
        spriteClips_left[ 6 ].x = 125;
        spriteClips_left[ 6 ].y = 91;
        spriteClips_left[ 6 ].w = 25;
        spriteClips_left[ 6 ].h = 30;


        //Frame 7
        spriteClips_left[ 7 ].x = 100;
        spriteClips_left[ 7 ].y = 91;
        spriteClips_left[ 7 ].w = 25;
        spriteClips_left[ 7 ].h = 30;

        //Frame 8
        spriteClips_left[ 8 ].x = 75;
        spriteClips_left[ 8 ].y = 91;
        spriteClips_left[ 8 ].w = 25;
        spriteClips_left[ 8 ].h = 30;

        //Frame 9
        spriteClips_left[ 9 ].x = 50;
        spriteClips_left[ 9 ].y = 91;
        spriteClips_left[ 9 ].w = 25;
        spriteClips_left[ 9 ].h = 30;

        //Frame 10
        spriteClips_left[ 10 ].x = 25;
        spriteClips_left[ 10 ].y = 91;
        spriteClips_left[ 10 ].w = 25;
        spriteClips_left[ 10 ].h = 30;

        //Frame 11
        spriteClips_left[ 11 ].x = 0;
        spriteClips_left[ 11 ].y = 91;
        spriteClips_left[ 11 ].w = 25;
        spriteClips_left[ 11 ].h = 30;

        //IDLE
        //IDLE_LEFT
        //frame 0
        spriteClips_idle_left[ 0 ].x = 0;
        spriteClips_idle_left[ 0 ].y = 121;
        spriteClips_idle_left[ 0 ].w = 12;
        spriteClips_idle_left[ 0 ].h = 30;

        //IDLE_RIGHT
        //frame 0
        spriteClips_idle_right[ 0 ].x = 12;
        spriteClips_idle_right[ 0 ].y = 121;
        spriteClips_idle_right[ 0 ].w = 12;
        spriteClips_idle_right[ 0 ].h = 30;

        //IDLE_UP
        //frame 0
        spriteClips_idle_up[ 0 ].x = 24;
        spriteClips_idle_up[ 0 ].y = 121;
        spriteClips_idle_up[ 0 ].w = 12;
        spriteClips_idle_up[ 0 ].h = 30;

        //IDLE_DOWN
        //frame 0
        spriteClips_idle_down[ 0 ].x = 36;
        spriteClips_idle_down[ 0 ].y = 121;
        spriteClips_idle_down[ 0 ].w = 12;
        spriteClips_idle_down[ 0 ].h = 30;

        //ATTACK_RIGHT
        //frame 0
        spriteClips_attack_right[ 0 ].x = 0;
        spriteClips_attack_right[ 0 ].y = 190;
        spriteClips_attack_right[ 0 ].w = 65;
        spriteClips_attack_right[ 0 ].h = 39;

         //frame 1
        spriteClips_attack_right[ 1 ].x = 65;
        spriteClips_attack_right[ 1 ].y = 190;
        spriteClips_attack_right[ 1 ].w = 65;
        spriteClips_attack_right[ 1 ].h = 39;

         //frame 2
        spriteClips_attack_right[ 2 ].x = 130;
        spriteClips_attack_right[ 2 ].y = 190;
        spriteClips_attack_right[ 2 ].w = 65;
        spriteClips_attack_right[ 2 ].h = 39;

        //frame 3
        spriteClips_attack_right[ 3 ].x = 195;
        spriteClips_attack_right[ 3 ].y = 190;
        spriteClips_attack_right[ 3 ].w = 65;
        spriteClips_attack_right[ 3 ].h = 39;

        //frame 4
        spriteClips_attack_right[ 4 ].x = 260;
        spriteClips_attack_right[ 4 ].y = 190;
        spriteClips_attack_right[ 4 ].w = 65;
        spriteClips_attack_right[ 4 ].h = 39;

        //frame 5
        spriteClips_attack_right[ 5 ].x = 325;
        spriteClips_attack_right[ 5 ].y = 190;
        spriteClips_attack_right[ 5 ].w = 65;
        spriteClips_attack_right[ 5 ].h = 39;

        //frame 6
        spriteClips_attack_right[ 6 ].x = 390;
        spriteClips_attack_right[ 6 ].y = 190;
        spriteClips_attack_right[ 6 ].w = 65;
        spriteClips_attack_right[ 6 ].h = 39;

        //ATTACK_RIGHT_ALT
        //frame 0
        spriteClips_attack_right_alt[ 0 ].x = 0;
        spriteClips_attack_right_alt[ 0 ].y = 229;
        spriteClips_attack_right_alt[ 0 ].w = 65;
        spriteClips_attack_right_alt[ 0 ].h = 39;

         //frame 1
        spriteClips_attack_right_alt[ 1 ].x = 65;
        spriteClips_attack_right_alt[ 1 ].y = 229;
        spriteClips_attack_right_alt[ 1 ].w = 65;
        spriteClips_attack_right_alt[ 1 ].h = 39;

         //frame 2
        spriteClips_attack_right_alt[ 2 ].x = 130;
        spriteClips_attack_right_alt[ 2 ].y = 229;
        spriteClips_attack_right_alt[ 2 ].w = 65;
        spriteClips_attack_right_alt[ 2 ].h = 39;

        //frame 3
        spriteClips_attack_right_alt[ 3 ].x = 195;
        spriteClips_attack_right_alt[ 3 ].y = 229;
        spriteClips_attack_right_alt[ 3 ].w = 65;
        spriteClips_attack_right_alt[ 3 ].h = 39;

        //frame 4
        spriteClips_attack_right_alt[ 4 ].x = 260;
        spriteClips_attack_right_alt[ 4 ].y = 229;
        spriteClips_attack_right_alt[ 4 ].w = 65;
        spriteClips_attack_right_alt[ 4 ].h = 39;

        //frame 5
        spriteClips_attack_right_alt[ 5 ].x = 325;
        spriteClips_attack_right_alt[ 5 ].y = 229;
        spriteClips_attack_right_alt[ 5 ].w = 65;
        spriteClips_attack_right_alt[ 5 ].h = 39;

       //ATTACK_LEFT
        //frame 0
        spriteClips_attack_left[ 0 ].x = 403;
        spriteClips_attack_left[ 0 ].y = 268;
        spriteClips_attack_left[ 0 ].w = 65;
        spriteClips_attack_left[ 0 ].h = 39;

         //frame 1
        spriteClips_attack_left[ 1 ].x = 338;
        spriteClips_attack_left[ 1 ].y = 268;
        spriteClips_attack_left[ 1 ].w = 65;
        spriteClips_attack_left[ 1 ].h = 39;

         //frame 2
        spriteClips_attack_left[ 2 ].x = 273;
        spriteClips_attack_left[ 2 ].y = 268;
        spriteClips_attack_left[ 2 ].w = 65;
        spriteClips_attack_left[ 2 ].h = 39;

        //frame 3
        spriteClips_attack_left[ 3 ].x = 208;
        spriteClips_attack_left[ 3 ].y = 268;
        spriteClips_attack_left[ 3 ].w = 65;
        spriteClips_attack_left[ 3 ].h = 39;

        //frame 4
        spriteClips_attack_left[ 4 ].x = 143;
        spriteClips_attack_left[ 4 ].y = 268;
        spriteClips_attack_left[ 4 ].w = 65;
        spriteClips_attack_left[ 4 ].h = 39;
        //frame 5
        spriteClips_attack_left[ 5 ].x = 78;
        spriteClips_attack_left[ 5 ].y = 268;
        spriteClips_attack_left[ 5 ].w = 65;
        spriteClips_attack_left[ 5 ].h = 39;

        //frame 6
        spriteClips_attack_left[ 6 ].x = 13;
        spriteClips_attack_left[ 6 ].y = 268;
        spriteClips_attack_left[ 6 ].w = 65;
        spriteClips_attack_left[ 6 ].h = 39;

        //ATTACK_LEFT_ALT
         //frame 0
        spriteClips_attack_left_alt[ 0 ].x = 403;
        spriteClips_attack_left_alt[ 0 ].y = 307;
        spriteClips_attack_left_alt[ 0 ].w = 65;
        spriteClips_attack_left_alt[ 0 ].h = 39;

         //frame 1
        spriteClips_attack_left_alt[ 1 ].x = 338;
        spriteClips_attack_left_alt[ 1 ].y = 307;
        spriteClips_attack_left_alt[ 1 ].w = 65;
        spriteClips_attack_left_alt[ 1 ].h = 39;

         //frame 2
        spriteClips_attack_left_alt[ 2 ].x = 273;
        spriteClips_attack_left_alt[ 2 ].y = 307;
        spriteClips_attack_left_alt[ 2 ].w = 65;
        spriteClips_attack_left_alt[ 2 ].h = 39;

        //frame 3
        spriteClips_attack_left_alt[ 3 ].x = 208;
        spriteClips_attack_left_alt[ 3 ].y = 307;
        spriteClips_attack_left_alt[ 3 ].w = 65;
        spriteClips_attack_left_alt[ 3 ].h = 39;

        //frame 4
        spriteClips_attack_left_alt[ 4 ].x = 143;
        spriteClips_attack_left_alt[ 4 ].y = 307;
        spriteClips_attack_left_alt[ 4 ].w = 65;
        spriteClips_attack_left_alt[ 4 ].h = 39;

        //frame 5
        spriteClips_attack_left_alt[ 5 ].x = 78;
        spriteClips_attack_left_alt[ 5 ].y = 307;
        spriteClips_attack_left_alt[ 5 ].w = 65;
        spriteClips_attack_left_alt[ 5 ].h = 39;

        //ATTACK_UP
        //frame 0
        spriteClips_attack_up[0].x = 0;
        spriteClips_attack_up[0].y = 347;
        spriteClips_attack_up[0].w = 52;
        spriteClips_attack_up[0].h = 54;

         //frame 1
        spriteClips_attack_up[1].x = 52;
        spriteClips_attack_up[1].y = 347;
        spriteClips_attack_up[1].w = 52;
        spriteClips_attack_up[1].h = 54;

         //frame 2
        spriteClips_attack_up[2].x = 104;
        spriteClips_attack_up[2].y = 347;
        spriteClips_attack_up[2].w = 52;
        spriteClips_attack_up[2].h = 54;

        //frame 3
        spriteClips_attack_up[3].x = 156;
        spriteClips_attack_up[3].y = 347;
        spriteClips_attack_up[3].w = 52;
        spriteClips_attack_up[3].h = 54;

         //frame 4
        spriteClips_attack_up[4].x = 208;
        spriteClips_attack_up[4].y = 347;
        spriteClips_attack_up[4].w = 52;
        spriteClips_attack_up[4].h = 54;

         //frame 5
        spriteClips_attack_up[5].x = 260;
        spriteClips_attack_up[5].y = 347;
        spriteClips_attack_up[5].w = 52;
        spriteClips_attack_up[5].h = 54;

         //frame 6
        spriteClips_attack_up[6].x = 312;
        spriteClips_attack_up[6].y = 347;
        spriteClips_attack_up[6].w = 52;
        spriteClips_attack_up[6].h = 54;

        //ATTACK_UP_ALT
         //frame 0
        spriteClips_attack_up_alt[0].x = 312;
        spriteClips_attack_up_alt[0].y = 401;
        spriteClips_attack_up_alt[0].w = 52;
        spriteClips_attack_up_alt[0].h = 54;

         //frame 1
        spriteClips_attack_up_alt[1].x = 260;
        spriteClips_attack_up_alt[1].y = 401;
        spriteClips_attack_up_alt[1].w = 52;
        spriteClips_attack_up_alt[1].h = 54;

         //frame 2
        spriteClips_attack_up_alt[2].x = 208;
        spriteClips_attack_up_alt[2].y = 401;
        spriteClips_attack_up_alt[2].w = 52;
        spriteClips_attack_up_alt[2].h = 54;

         //frame 3
        spriteClips_attack_up_alt[3].x = 156;
        spriteClips_attack_up_alt[3].y = 401;
        spriteClips_attack_up_alt[3].w = 52;
        spriteClips_attack_up_alt[3].h = 54;

         //frame 4
        spriteClips_attack_up_alt[4].x = 104;
        spriteClips_attack_up_alt[4].y = 401;
        spriteClips_attack_up_alt[4].w = 52;
        spriteClips_attack_up_alt[4].h = 54;

         //frame 5
        spriteClips_attack_up_alt[5].x = 52;
        spriteClips_attack_up_alt[5].y = 401;
        spriteClips_attack_up_alt[5].w = 52;
        spriteClips_attack_up_alt[5].h = 54;

         //frame 6
        spriteClips_attack_up_alt[6].x = 0;
        spriteClips_attack_up_alt[6].y = 401;
        spriteClips_attack_up_alt[6].w = 52;
        spriteClips_attack_up_alt[6].h = 54;

        //ATTACK_DOWN
        //frame 0
        spriteClips_attack_down[0].x = 0;
        spriteClips_attack_down[0].y = 455;
        spriteClips_attack_down[0].w = 52;
        spriteClips_attack_down[0].h = 58;

        //frame 1
        spriteClips_attack_down[1].x = 52;
        spriteClips_attack_down[1].y = 455;
        spriteClips_attack_down[1].w = 52;
        spriteClips_attack_down[1].h = 58;

        //frame 2
        spriteClips_attack_down[2].x = 104;
        spriteClips_attack_down[2].y = 455;
        spriteClips_attack_down[2].w = 52;
        spriteClips_attack_down[2].h = 58;

        //frame 3
        spriteClips_attack_down[3].x = 156;
        spriteClips_attack_down[3].y = 455;
        spriteClips_attack_down[3].w = 52;
        spriteClips_attack_down[3].h = 58;

        //frame 4
        spriteClips_attack_down[4].x = 208;
        spriteClips_attack_down[4].y = 455;
        spriteClips_attack_down[4].w = 52;
        spriteClips_attack_down[4].h = 58;

        //frame 5
        spriteClips_attack_down[5].x = 260;
        spriteClips_attack_down[5].y = 455;
        spriteClips_attack_down[5].w = 52;
        spriteClips_attack_down[5].h = 58;

        //frame 6
        spriteClips_attack_down[6].x = 312;
        spriteClips_attack_down[6].y = 455;
        spriteClips_attack_down[6].w = 52;
        spriteClips_attack_down[6].h = 58;

        //ATTACK_DOWN_ALT
        //frame 0
        spriteClips_attack_down_alt[0].x = 312;
        spriteClips_attack_down_alt[0].y = 513;
        spriteClips_attack_down_alt[0].w = 52;
        spriteClips_attack_down_alt[0].h = 58;

        //frame 1
        spriteClips_attack_down_alt[1].x = 260;
        spriteClips_attack_down_alt[1].y = 513;
        spriteClips_attack_down_alt[1].w = 52;
        spriteClips_attack_down_alt[1].h = 58;

        //frame 2
        spriteClips_attack_down_alt[2].x = 208;
        spriteClips_attack_down_alt[2].y = 513;
        spriteClips_attack_down_alt[2].w = 52;
        spriteClips_attack_down_alt[2].h = 58;

        //frame 3
        spriteClips_attack_down_alt[3].x = 156;
        spriteClips_attack_down_alt[3].y = 513;
        spriteClips_attack_down_alt[3].w = 52;
        spriteClips_attack_down_alt[3].h = 58;

         //frame 4
        spriteClips_attack_down_alt[4].x = 104;
        spriteClips_attack_down_alt[4].y = 513;
        spriteClips_attack_down_alt[4].w = 52;
        spriteClips_attack_down_alt[4].h = 58;

         //frame 5
        spriteClips_attack_down_alt[5].x = 52;
        spriteClips_attack_down_alt[5].y = 513;
        spriteClips_attack_down_alt[5].w = 52;
        spriteClips_attack_down_alt[5].h = 58;

         //frame 6
        spriteClips_attack_down_alt[6].x = 0;
        spriteClips_attack_down_alt[6].y = 513;
        spriteClips_attack_down_alt[6].w = 52;
        spriteClips_attack_down_alt[6].h = 58;

        //DODGE_RIGHT
        //frame 0
        spriteClips_dodge_right[0].x = 0;
        spriteClips_dodge_right[0].y = 571;
        spriteClips_dodge_right[0].w = 36;
        spriteClips_dodge_right[0].h = 30;

        //frame 1
        spriteClips_dodge_right[1].x = 36;
        spriteClips_dodge_right[1].y = 571;
        spriteClips_dodge_right[1].w = 36;
        spriteClips_dodge_right[1].h = 30;

        //frame 2
        spriteClips_dodge_right[2].x = 72;
        spriteClips_dodge_right[2].y = 571;
        spriteClips_dodge_right[2].w = 36;
        spriteClips_dodge_right[2].h = 30;

        //frame 3
        spriteClips_dodge_right[3].x = 108;
        spriteClips_dodge_right[3].y = 571;
        spriteClips_dodge_right[3].w = 36;
        spriteClips_dodge_right[3].h = 30;

        //frame 4
        spriteClips_dodge_right[4].x = 144;
        spriteClips_dodge_right[4].y = 571;
        spriteClips_dodge_right[4].w = 36;
        spriteClips_dodge_right[4].h = 30;

        //frame 5
        spriteClips_dodge_right[5].x = 180;
        spriteClips_dodge_right[5].y = 571;
        spriteClips_dodge_right[5].w = 36;
        spriteClips_dodge_right[5].h = 30;

        //frame 6
        spriteClips_dodge_right[6].x = 216;
        spriteClips_dodge_right[6].y = 571;
        spriteClips_dodge_right[6].w = 36;
        spriteClips_dodge_right[6].h = 30;

        //frame 7
        spriteClips_dodge_right[7].x = 252;
        spriteClips_dodge_right[7].y = 571;
        spriteClips_dodge_right[7].w = 36;
        spriteClips_dodge_right[7].h = 30;

        //DODGE_LEFT
        //frame 0
        spriteClips_dodge_left[0].x = 252;
        spriteClips_dodge_left[0].y = 601;
        spriteClips_dodge_left[0].w = 36;
        spriteClips_dodge_left[0].h = 30;

         //frame 1
        spriteClips_dodge_left[1].x = 216;
        spriteClips_dodge_left[1].y = 601;
        spriteClips_dodge_left[1].w = 36;
        spriteClips_dodge_left[1].h = 30;

        //frame 2
        spriteClips_dodge_left[2].x = 180;
        spriteClips_dodge_left[2].y = 601;
        spriteClips_dodge_left[2].w = 36;
        spriteClips_dodge_left[2].h = 30;

         //frame 3
        spriteClips_dodge_left[3].x = 144;
        spriteClips_dodge_left[3].y = 601;
        spriteClips_dodge_left[3].w = 36;
        spriteClips_dodge_left[3].h = 30;

        //frame 4
        spriteClips_dodge_left[4].x = 108;
        spriteClips_dodge_left[4].y = 601;
        spriteClips_dodge_left[4].w = 36;
        spriteClips_dodge_left[4].h = 30;

        //frame 5
        spriteClips_dodge_left[5].x = 72;
        spriteClips_dodge_left[5].y = 601;
        spriteClips_dodge_left[5].w = 36;
        spriteClips_dodge_left[5].h = 30;

        //frame 6
        spriteClips_dodge_left[6].x = 36;
        spriteClips_dodge_left[6].y = 601;
        spriteClips_dodge_left[6].w = 36;
        spriteClips_dodge_left[6].h = 30;

         //frame 7
        spriteClips_dodge_left[7].x = 0;
        spriteClips_dodge_left[7].y = 601;
        spriteClips_dodge_left[7].w = 36;
        spriteClips_dodge_left[7].h = 30;

        //DODGE_DOWN
        //frame 0
        spriteClips_dodge_down[0].x = 0;
        spriteClips_dodge_down[0].y = 632;
        spriteClips_dodge_down[0].w = 21;
        spriteClips_dodge_down[0].h = 33;

        //frame 1
        spriteClips_dodge_down[1].x = 21;
        spriteClips_dodge_down[1].y = 632;
        spriteClips_dodge_down[1].w = 21;
        spriteClips_dodge_down[1].h = 33;

        //frame 2
        spriteClips_dodge_down[2].x = 42;
        spriteClips_dodge_down[2].y = 632;
        spriteClips_dodge_down[2].w = 21;
        spriteClips_dodge_down[2].h = 33;

        //frame 3
        spriteClips_dodge_down[3].x = 63;
        spriteClips_dodge_down[3].y = 632;
        spriteClips_dodge_down[3].w = 21;
        spriteClips_dodge_down[3].h = 33;

        //frame 4
        spriteClips_dodge_down[4].x = 84;
        spriteClips_dodge_down[4].y = 632;
        spriteClips_dodge_down[4].w = 21;
        spriteClips_dodge_down[4].h = 33;

        //frame 5
        spriteClips_dodge_down[5].x = 105;
        spriteClips_dodge_down[5].y = 632;
        spriteClips_dodge_down[5].w = 21;
        spriteClips_dodge_down[5].h = 33;

        //frame 6
        spriteClips_dodge_down[6].x = 126;
        spriteClips_dodge_down[6].y = 632;
        spriteClips_dodge_down[6].w = 21;
        spriteClips_dodge_down[6].h = 33;

        //frame 7
        spriteClips_dodge_down[7].x = 147;
        spriteClips_dodge_down[7].y = 632;
        spriteClips_dodge_down[7].w = 21;
        spriteClips_dodge_down[7].h = 33;

        //DODGE_UP
        //frame 0
        spriteClips_dodge_up[0].x = 0;
        spriteClips_dodge_up[0].y = 666;
        spriteClips_dodge_up[0].w = 25;
        spriteClips_dodge_up[0].h = 41;

        //frame 1
        spriteClips_dodge_up[1].x = 25;
        spriteClips_dodge_up[1].y = 666;
        spriteClips_dodge_up[1].w = 25;
        spriteClips_dodge_up[1].h = 41;

        //frame 2
        spriteClips_dodge_up[2].x = 50;
        spriteClips_dodge_up[2].y = 666;
        spriteClips_dodge_up[2].w = 25;
        spriteClips_dodge_up[2].h = 41;

        //frame 3
        spriteClips_dodge_up[3].x = 75;
        spriteClips_dodge_up[3].y = 666;
        spriteClips_dodge_up[3].w = 25;
        spriteClips_dodge_up[3].h = 41;

        //frame 4
        spriteClips_dodge_up[4].x = 100;
        spriteClips_dodge_up[4].y = 666;
        spriteClips_dodge_up[4].w = 25;
        spriteClips_dodge_up[4].h = 41;

        //frame 5
        spriteClips_dodge_up[5].x = 125;
        spriteClips_dodge_up[5].y = 666;
        spriteClips_dodge_up[5].w = 25;
        spriteClips_dodge_up[5].h = 41;

        //frame 6
        spriteClips_dodge_up[6].x = 150;
        spriteClips_dodge_up[6].y = 666;
        spriteClips_dodge_up[6].w = 25;
        spriteClips_dodge_up[6].h = 41;

        //frame 7
        spriteClips_dodge_up[7].x = 175;
        spriteClips_dodge_up[7].y = 666;
        spriteClips_dodge_up[7].w = 25;
        spriteClips_dodge_up[7].h = 41;

        //GET_HIT_RIGHT
        //frame 0
        spriteClips_get_hit_right[0].x = 0;
        spriteClips_get_hit_right[0].y = 757;
        spriteClips_get_hit_right[0].w = 30;
        spriteClips_get_hit_right[0].h = 30;

        //frame 1
        spriteClips_get_hit_right[1].x = 30;
        spriteClips_get_hit_right[1].y = 757;
        spriteClips_get_hit_right[1].w = 30;
        spriteClips_get_hit_right[1].h = 30;

        //frame 2
        spriteClips_get_hit_right[2].x = 60;
        spriteClips_get_hit_right[2].y = 757;
        spriteClips_get_hit_right[2].w = 30;
        spriteClips_get_hit_right[2].h = 30;

        //frame 3
        spriteClips_get_hit_right[3].x = 90;
        spriteClips_get_hit_right[3].y = 757;
        spriteClips_get_hit_right[3].w = 30;
        spriteClips_get_hit_right[3].h = 30;

        //GET_HIT_LEFT
        //frame 0
        spriteClips_get_hit_left[0].x = 120;
        spriteClips_get_hit_left[0].y = 757;
        spriteClips_get_hit_left[0].w = 30;
        spriteClips_get_hit_left[0].h = 30;

        //frame 1
        spriteClips_get_hit_left[1].x = 150;
        spriteClips_get_hit_left[1].y = 757;
        spriteClips_get_hit_left[1].w = 30;
        spriteClips_get_hit_left[1].h = 30;

        //frame 2
        spriteClips_get_hit_left[2].x = 180;
        spriteClips_get_hit_left[2].y = 757;
        spriteClips_get_hit_left[2].w = 30;
        spriteClips_get_hit_left[2].h = 30;

         //frame 3
        spriteClips_get_hit_left[3].x = 210;
        spriteClips_get_hit_left[3].y = 757;
        spriteClips_get_hit_left[3].w = 30;
        spriteClips_get_hit_left[3].h = 30;

        //DEATH
        //frame 0
        spriteClips_death[0].x = 0;
        spriteClips_death[0].y = 707;
        spriteClips_death[0].w = 36;
        spriteClips_death[0].h = 50;

        //frame 1
        spriteClips_death[1].x = 36;
        spriteClips_death[1].y = 707;
        spriteClips_death[1].w = 36;
        spriteClips_death[1].h = 50;

        //frame 2
        spriteClips_death[2].x = 72;
        spriteClips_death[2].y = 707;
        spriteClips_death[2].w = 36;
        spriteClips_death[2].h = 50;

        //frame 3
        spriteClips_death[3].x = 108;
        spriteClips_death[3].y = 707;
        spriteClips_death[3].w = 36;
        spriteClips_death[3].h = 50;

        //frame 4
        spriteClips_death[4].x = 144;
        spriteClips_death[4].y = 707;
        spriteClips_death[4].w = 36;
        spriteClips_death[4].h = 50;

        //frame 5
        spriteClips_death[5].x = 180;
        spriteClips_death[5].y = 707;
        spriteClips_death[5].w = 36;
        spriteClips_death[5].h = 50;

        //frame 6
        spriteClips_death[6].x = 216;
        spriteClips_death[6].y = 707;
        spriteClips_death[6].w = 36;
        spriteClips_death[6].h = 50;

        //frame 7
        spriteClips_death[7].x = 252;
        spriteClips_death[7].y = 707;
        spriteClips_death[7].w = 36;
        spriteClips_death[7].h = 50;

        //frame 8
        spriteClips_death[8].x = 288;
        spriteClips_death[8].y = 707;
        spriteClips_death[8].w = 36;
        spriteClips_death[8].h = 50;

        //frame 9
        spriteClips_death[9].x = 324;
        spriteClips_death[9].y = 707;
        spriteClips_death[9].w = 36;
        spriteClips_death[9].h = 50;

        //UI
        //frame 0
        spriteClips_UI[0].x = 0;
        spriteClips_UI[0].y = 1429;
        spriteClips_UI[0].w = 81;
        spriteClips_UI[0].h = 30;


        }

    if (active)
    {

        if (!idle)
        {
            if (upMov)
                lastMov = 'U';
            else if (downMov)
                lastMov = 'D';
            else if (rightMov)
                lastMov = 'R';
            else if (leftMov)
                lastMov = 'L';
        }

        if (idle)
        {
            if (lastMov == 'U')
            {
                srcRect = spriteClips_idle_up[0];
            }
            else if (lastMov == 'R')
            {
                srcRect = spriteClips_idle_right[0];
            }
            else if (lastMov == 'L')
            {
                srcRect = spriteClips_idle_left[0];
            }

            else if (lastMov == 'D')
            {
                srcRect = spriteClips_idle_down[0];
            }

        }
            else if (upMov)
            {
                srcRect = spriteClips[frame % FLYING_FRAMES];
                if (frame % 12 == 11)
                {
                    Mix_PlayChannel( -1, gfootstep1, 0 );
                    Mix_Volume(-1, 16);
                }
                else if (frame%12 == 5)
                {
                    Mix_PlayChannel( -1, gfootstep2, 0 );
                    Mix_Volume(-1, 16);
                }
            }
            else if (downMov)
            {
                srcRect = spriteClips_down[frame % FLYING_FRAMES];
                if (frame % 12 == 11)
                {
                    Mix_PlayChannel( -1, gfootstep1, 0 );
                    Mix_Volume(-1, 16);
                }
                else if (frame%12 == 5)
                {
                    Mix_PlayChannel( -1, gfootstep2, 0 );
                    Mix_Volume(-1, 16);
                }
            }
            else if (rightMov)
            {
                srcRect = spriteClips_right[frame % FLYING_FRAMES];
                if (frame % 12 == 11)
                {
                    Mix_PlayChannel( -1, gfootstep1, 0 );
                    Mix_Volume(-1, 16);
                }
                else if (frame%12 == 5)
                {
                    Mix_PlayChannel( -1, gfootstep2, 0 );
                    Mix_Volume(-1, 16);
                }
            }

            else if (leftMov)
            {
                srcRect = spriteClips_left[frame % FLYING_FRAMES];
                if (frame % 12 == 11)
                {
                    Mix_PlayChannel( -1, gfootstep1, 0 );
                    Mix_Volume(-1, 16);
                }
                else if (frame%12 == 5)
                {
                    Mix_PlayChannel( -1, gfootstep2, 0 );
                    Mix_Volume(-1, 16);
                }
            }

    }



    if (attacking)
    {
        indFrame++;
        active = false;
        for (int i = indFrame; i <= indFrame; i ++)
        {
            if(attacking && (lastMov == 'D' || downMov) && !attackAlt)
            {

                srcRect = spriteClips_attack_down[indFrame%7];
                if (indFrame % 7 == 1)
                {
                    Mix_PlayChannel( -1, gslash1, 0 );
                }
                else if (indFrame % 7 == 3)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                }

            }
            else if(attacking && (lastMov == 'D' || downMov) && attackAlt)
            {
                srcRect = spriteClips_attack_down_alt[indFrame%7];
                if (indFrame % 7 == 1)
                {
                    Mix_PlayChannel( -1, gslash2, 0 );
                }
                else if (indFrame % 7 == 3)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                }



            }
            else if(attacking && (lastMov == 'U' || upMov) && !attackAlt)
            {
                srcRect = spriteClips_attack_up[indFrame%7];
                if (indFrame % 7 == 1)
                {
                    Mix_PlayChannel( -1, gslash1, 0 );
                }
                else if (indFrame % 7 == 3)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                }

            }
            else if(attacking && (lastMov == 'U' || upMov) && attackAlt)
            {

                srcRect = spriteClips_attack_up_alt[indFrame%7];
                if (indFrame % 7 == 1)
                {
                    Mix_PlayChannel( -1, gslash2, 0 );
                }
                else if (indFrame % 7 == 3)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                }

            }
            else if(attacking && (lastMov == 'L' || leftMov) && !attackAlt)
            {
                srcRect = spriteClips_attack_left[indFrame%7];
                if (indFrame % 7 == 1)
                {
                    Mix_PlayChannel( -1, gslash1, 0 );
                }
                else if (indFrame % 7 == 3)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                }

            }
            else if(attacking && (lastMov == 'L' || leftMov) && attackAlt)
            {
                srcRect = spriteClips_attack_left_alt[indFrame%6];
                if (indFrame % 7 == 1)
                {
                    Mix_PlayChannel( -1, gslash2, 0 );
                }
                else if (indFrame % 7 == 3)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                }

            }
            else if(attacking && (lastMov == 'R' || rightMov) && !attackAlt)
            {
                srcRect = spriteClips_attack_right[indFrame%7];
                if (indFrame % 7 == 1)
                {
                    Mix_PlayChannel( -1, gslash1, 0 );
                }
                else if (indFrame % 7 == 3)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                }

            }
            else if(attacking && (lastMov == 'R' || rightMov) && attackAlt)
            {
                srcRect = spriteClips_attack_right_alt[indFrame%6];
                if (indFrame % 7 == 1)
                {
                    Mix_PlayChannel( -1, gslash2, 0 );
                }
                else if (indFrame % 7 == 3)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                }


            }

        }

    }


    destRect.h = srcRect.h * 2;
    destRect.w = srcRect.w * 2;
    destRect.x = x + tempRect.x;
    destRect.y = -y + tempRect.y;

    if(rightMov && !upMov && !downMov)
        destRect.x -= 18;
    if (upMov)
    {
        destRect.x -= 4;
    }
    if (downMov)
        destRect.x -= 6;
    if (leftMov && !upMov && !downMov)
        destRect.x -= 6;

    if(attacking && (lastMov == 'D' || downMov))
    {
        destRect.x -= 40;
        destRect.y -= 6;

    }
    if(attacking && (lastMov == 'U' || upMov))
    {
        destRect.x -= 40;
        destRect.y -= 40;
    }
    if(attacking && (lastMov == 'L' || leftMov))
    {
        destRect.x -= 80;
        destRect.y -= 8;
    }
    if(attacking && (lastMov == 'R' || rightMov))
    {
        destRect.x -= 20;
        destRect.y -= 8;
    }
    if(attacking && (((lastMov == 'L') & (upMov || downMov)) || (leftMov & (upMov || downMov))))
    {
        destRect.x += 80;
        destRect.y += 8;
    }


     if (attacking)
    {
        if (lastMov == 'U')
       {
           if (indFrame == 1)
            {
                attackHitbox.x = destRect.x + 3;
               attackHitbox.y = destRect.y + 3;
               attackHitbox.w = 100;
               attackHitbox.h = 50;
            }
            else
            {
                this->attackHitbox.w = this->attackHitbox.h = 0;
            }


            this->hitbox.x = destRect.x + 38;
            this->hitbox.y = destRect.y + 76;
       }
       else if (lastMov == 'D')
       {
           if (indFrame == 1)
            {
                attackHitbox.x = destRect.x + 3;
               attackHitbox.y = destRect.y + 70;
               attackHitbox.w = 100;
                attackHitbox.h = 50;
            }

            else
            {
                this->attackHitbox.w = this->attackHitbox.h = 0;
            }

            this->hitbox.x = destRect.x + 38;
            this->hitbox.y = destRect.y + 42;
       }
       else if (lastMov == 'R')
       {
           if (indFrame == 1)
            {
                attackHitbox.x = destRect.x + 60;
               attackHitbox.y = destRect.y + 7;
               attackHitbox.w = 70;
               attackHitbox.h = 70;
            }

              else
            {
                this->attackHitbox.w = this->attackHitbox.h = 0;
            }

            this->hitbox.x = destRect.x + 18;
            this->hitbox.y = destRect.y + 44;
       }
       else if (lastMov == 'L')
       {

            if (indFrame == 1)
            {
                attackHitbox.x = destRect.x + 3;
               attackHitbox.y = destRect.y + 7;
               attackHitbox.w = 70;
               attackHitbox.h = 70;
            }
              else
            {
                this->attackHitbox.w = this->attackHitbox.h = 0;
            }

            this->hitbox.x = destRect.x + 78;
            this->hitbox.y = destRect.y + 44;
       }
    }
   else if (upMov)
   {
            attackHitbox.x = attackHitbox.y = attackHitbox.w = attackHitbox.h = 0;
            this->hitbox.x = destRect.x + 2;
            this->hitbox.y = destRect.y + 36;
   }
   else if (downMov)
   {
            attackHitbox.x = attackHitbox.y = attackHitbox.w = attackHitbox.h = 0;
            this->hitbox.x = destRect.x + 4;
            this->hitbox.y = destRect.y + 36;
   }
   else if (rightMov)
   {
            attackHitbox.x = attackHitbox.y = attackHitbox.w = attackHitbox.h = 0;
            this->hitbox.x = destRect.x + 16;
            this->hitbox.y = destRect.y + 36;
   }
   else if (leftMov)
   {
            attackHitbox.x = attackHitbox.y = attackHitbox.w = attackHitbox.h = 0;
            this->hitbox.x = destRect.x + 4;
            this->hitbox.y = destRect.y + 36;
   }
   else if (idle)
   {
        attackHitbox.x = attackHitbox.y = attackHitbox.w = attackHitbox.h = 0;
        this->hitbox.x = destRect.x - 2;
        this->hitbox.y = destRect.y + 36;
   }


    if (attacking)
    {
         if (attackAlt == false)
           {
                if (indFrame == 6)
                {
                    attacking = false;
                    active = true;
                    indFrame = -1;
                     attackAlt = !attackAlt;
                }
           }
           else if (attackAlt == true)
           {
                if (indFrame == 5)
                {
                    attacking = false;
                    active = true;
                    indFrame = -1;
                    attackAlt = !attackAlt;
                }
           }
    }

    if (dodging)
    {
        dodgeFrame++;
        active = false;
        for (int i = indFrame; i <= dodgeFrame; i ++)
        {
            if (rightMov & upMov)
            {
                srcRect = spriteClips_dodge_up[dodgeFrame%7];
                if (dodgeFrame % 7 == 0)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                    stamina -= 12.5;
                    y += 14;
                    x += 14;
                    if(hitUpWall())
                    {
                        y -= 14;
                    }
                    if(hitRightWall())
                    {
                        x -= 14;
                    }
                }
                else if(dodgeFrame % 7 == 1)
                {
                        y += 10;
                        x += 10;
                        if(hitUpWall())
                        {
                            y -= 10;
                        }
                        if(hitRightWall())
                        {
                            x -= 10;
                        }
                }
            }
            else if (leftMov & upMov)
            {
                srcRect = spriteClips_dodge_up[dodgeFrame%7];
                if (dodgeFrame % 7 == 0)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                    stamina -= 12.5;
                    y += 14;
                    x -= 14;
                    if(hitUpWall())
                    {
                        y -= 14;
                    }
                    if(hitLeftWall())
                    {
                        x += 14;
                    }
                }
                else if(dodgeFrame % 7 == 1)
                {
                    y += 10;
                    x -= 10;
                    if(hitUpWall())
                    {
                        y -= 10;
                    }
                    if(hitLeftWall())
                    {
                        x += 10;
                    }
                }
            }
            else if (rightMov & downMov)
            {
                srcRect = spriteClips_dodge_down[dodgeFrame%7];
                if (dodgeFrame % 7 == 0)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                    stamina -= 12.5;
                    y -= 14;
                    x += 14;
                    if(hitDownWall())
                    {
                        y += 14;
                    }
                    if(hitRightWall())
                    {
                        x -= 14;
                    }
                }
                else if(dodgeFrame % 7 == 1)
                {
                    y -= 10;
                    x += 10;
                    if(hitDownWall())
                    {
                        y += 10;
                    }
                    if(hitRightWall())
                    {
                        x -= 10;
                    }
                }
            }
            else if (leftMov & downMov)
            {
                srcRect = spriteClips_dodge_down[dodgeFrame%7];
                if (dodgeFrame % 7 == 0)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                    stamina -= 12.5;
                    y -= 14;
                    x -= 14;
                    if(hitLeftWall())
                    {
                        x += 14;
                    }
                    if(hitDownWall())
                    {
                        y += 14;
                    }
                }
                else if(dodgeFrame % 7 == 1)
                {
                    y -= 10;
                    x -= 10;
                    if(hitLeftWall())
                    {
                        x += 10;
                    }
                    if(hitDownWall())
                    {
                        y += 10;
                    }
                }
            }
            else if(lastMov == 'D' || downMov)
            {
                srcRect = spriteClips_dodge_down[dodgeFrame%7];
                if (dodgeFrame % 7 == 0)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                    stamina -= 12.5;
                    y -= 24;
                    if(hitDownWall())
                    {
                        y += 24;
                    }
                }
                else if(dodgeFrame % 7 == 1)
                {
                    y -= 14;
                    if(hitDownWall())
                    {
                        y += 14;
                    }
                }
            }
            else if(lastMov == 'U' || upMov)
            {
                srcRect = spriteClips_dodge_up[dodgeFrame%7];
                if (dodgeFrame % 7 == 0)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                    stamina -= 12.5;
                    y += 24;
                    if(hitUpWall())
                    {
                        y -= 24;
                    }
                }
                else if(dodgeFrame % 7 == 1)
                {
                    y += 14;
                    if(hitUpWall())
                    {
                        y -= 14;
                    }
                }
            }
            else if(lastMov == 'L' || leftMov)
            {
                srcRect = spriteClips_dodge_left[dodgeFrame%7];
                if (dodgeFrame % 7 == 0)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                    stamina -= 12.5;
                    x -= 24;
                    if(hitLeftWall())
                    {
                        x += 24;
                    }
                }
                else if(dodgeFrame % 7 == 1)
                {
                    x -= 14;
                    if(hitLeftWall())
                    {
                        x += 24;
                    }
                }
            }
            else if(lastMov == 'R' || rightMov)
            {
                srcRect = spriteClips_dodge_right[dodgeFrame%7];
                if (dodgeFrame % 7 == 0)
                {
                    Mix_PlayChannel( -1, gwhoosh, 0 );
                    stamina -= 12.5;
                    x += 24;
                    if(hitRightWall())
                    {
                        x -= 24;
                    }
                }
                else if(dodgeFrame % 7 == 1)
                {
                    x += 14;
                    if(hitRightWall())
                    {
                        x -= 14;
                    }
                }
            }
        }
    }

    if (dodging)
    {
        if (dodgeFrame >= 6)
        {
            dodging = false;
            active = true;
            dodgeFrame = -1;
        }
    }

    if ((hit && !invulnerability) or (!active & !dodging & !attacking & !elevating & health > 0))
    {

        if (tempCounter < 5)
        {
            srcRect = spriteClips_get_hit_left[tempCounter];

            active = false;
        }
        tempCounter++;
    }

    if (hit && (tempCounter == 1))
    {


        if (health > 0)
            health -= 10;

    }

    if (tempCounter >= 5)
    {
        tempCounter = 0;
        c = 0;
        invulnerability = true;
        active = true;
    }

    if (invulnerability && (c == 0))
    {
        active = true;
        c = 1;
    }

    if (c >= 1)
    {
        c++;
    }

    if (c >= 20)             //frames the player is invulnerable for
    {
        c = 0;
        invulnerability = false;
    }

    cout << "COUNTER IS   " << c << endl;
    destRect.w = srcRect.w * 2;
    destRect.h = srcRect.h * 2;
}

void Player::draw()
{

    SDL_RenderCopyEx(Game::renderer, objTexture, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);

    SDL_Rect UIsrcRect = spriteClips_UI[0];
    SDL_Rect UIdestRect;
    UIdestRect.x =  10;
    UIdestRect.y =  10;
    UIdestRect.w =  UIsrcRect.w * 2;
    UIdestRect.h =  UIsrcRect.h * 2;

    SDL_RenderCopyEx(Game::renderer, objTexture, &UIsrcRect, &UIdestRect, 0.0, NULL, SDL_FLIP_NONE);

    SDL_Rect fillhealth = { 70, 28, health * 2, 4 * 2};
    SDL_SetRenderDrawColor( Game::renderer, 0xFF, 0x00, 0x00, 0xFF );
    SDL_RenderFillRect(Game::renderer, &fillhealth );
    SDL_SetRenderDrawColor( Game::renderer, 0x00, 0x00, 0x00, 0x00 );
    SDL_Rect fillstamina = { 70, 42, stamina * 2, 4 * 2};
    SDL_SetRenderDrawColor( Game::renderer, 0x00, 0xFF, 0x00, 0xFF );
    SDL_RenderFillRect(Game::renderer, &fillstamina );
    SDL_SetRenderDrawColor( Game::renderer, 0x00, 0x00, 0x00, 0x00 );

    SDL_RenderDrawRect( Game::renderer, &this->hitbox );
    SDL_RenderDrawRect( Game::renderer, &attackHitbox );

}

void Player::attack(int x, int y)
{


}

Player* Player::getInstance(int startX, int startY)
{
    if (instance == NULL)
        instance = new Player("Images/main_ss.png", 1024/2 + startX, -786/2 - startY);
    return instance;
}

SDL_Rect Player::camera()
{

    int x_disp = 0;
    int y_disp = 0;
//
    if ((1024/2 - x < 0) or (1024/2 - x > 0))
           x_disp = (1024/2 - x);
//
    if ((768/2 + y > 0) or (768/2 + y < 0))
            y_disp = (768/2 + y);
//
    SDL_Rect tempRect;
    tempRect.x = x_disp;
    tempRect.y = y_disp;
    tempRect.h = 2;

   return tempRect;
}

void Player::setUpMov(bool up)
{
    upMov = up;

}


void Player::setLeftMov(bool left)
{
    leftMov = left;
}

void Player::setDownMov(bool down)
{
    downMov = down;
}

void Player::setX(float x)
{
    this->x = x;
}

void Player::setY(float y)
{
    this->y = y;
}

int Player::getX()
{
    return x;
}

int Player::getY()
{
    return y;
}

void Player::setRightMov(bool right)
{
    rightMov = right;
}

bool Player::getIdle()
{
    return idle;
}

void Player::setIdle(bool idle)
{
    this->idle = idle;

}

void Player::setAttack(bool attack)
{
    attacking = attack;
}

bool Player::getActive()
{
    return active;
}

SDL_Rect Player::getHitbox()
{
    return this->hitbox;
}

bool Player::getHit()
{
    return this->hit;
}

void Player::setHit(bool h)
{
    hit = h;
}


SDL_Rect Player::getAttackbox()
{
    return attackHitbox;
}


void Player::setDodge(bool dodge)
{
    this->dodging = dodge;
}

int Player::getStamina()
{
    return stamina;
}

bool Player::getBarrierTrigger()
{
    return barrierTrigger;
}

void Player::setBarrierTrigger(bool barrierTrigger)
{
    this->barrierTrigger = barrierTrigger;
}

bool Player::enemiesChecker(int enemies)
{
    if (enemySpawn & enemies == 0)
    {
        return true;
    }
    return false;

}
bool Player::hitLeftWall()
{


    if(x <= 142)
    {
        return true;
    }
    else if(x <= 1082 && x >= 512 && y <= -1843 && y >= -2233)
    {
        return true;
    }
    else if(x <= 1126 && y <= -557 && y >= - 1427)
    {
        return true;
    }
    else if(x <= 1646 && x >=1546 && y >= -717)
    {
        return true;
    }
    else if(x <= 1646 && x >=1546 && y <= -787 && y >= -2003)
    {
        return true;
    }
    else if(x <= 2256 && y >= -437)
    {
        return true;
    }
    else if(x <= 2266 && y <= -437 && y >= -657)
    {
        return true;
    }
    else if(x <= 3016 && x >= 2926 && y >= -1487 && y<= -437)
    {
        return true;
    }
    else if(x <= 2096 && x >= 1882 && y <= -1387)
    {
        return true;
    }
    else if (barrierL & x >= 1500 & x <= 1670 & y <= -710 & y >= -795)
    {
        cout << "BARRIER L " << barrierL << endl;
        return true;
    }
    else
    {
        return false;
    }
}

bool Player::hitUpWall()
{
    if(x <= 512 && y >= -2113)
    {
        return true;
    }
    else if(x >= 512 && x <= 1082 && y >= -2233 && y <= -1427)
    {
        return true;
    }
    else if(x >= 982 && x <= 1682 && y >= -2043 && y <= -1427)
    {
        return true;
    }
    else if(x <= 1546 && y >= -657)
    {
        return true;
    }
    else if(x >= 1546 && x <= 1646 && y >= -717)
    {
        return true;
    }
    else if(x >= 1646 && x <= 2266 && y >= -657 && y <= -437)
    {
        return true;
    }
    else if(x >= 2376 && x <= 2996 && y >= -657 && y <= -437)
    {
        return true;
    }
    else if(y >= -337)
    {
        return true;
    }
    else if(x >= 1996 && x <= 3016 && y >= -1487 && y <= -1367)
    {
        return true;
    }
    else if(barrierU)
        return true;
    else if(x <= 3400 & x >= 3252 & y >= -617 & y <= -580)
        return true;
     else if(x <= 3400 & x >= 3252 & y >= -761 & y <= -730)
        return true;
     else if(x <= 3400 & x >= 3252 & y >= -905 & y <= -870)
        return true;
     else if(x <= 3400 & x >= 3252 & y >= -1061 & y <= -1025)
        return true;
    else
    {
        return false;
    }
}

bool Player::hitDownWall()
{
    if(y <= -2393)
    {
        return true;
    }
    else if(x <= 2006 && y <= -1327 && y >= -2003)
    {
        return true;
    }
    else if(x <= 1646 && x >= 1546 && y <= -787 && y >= -2003)
    {
        return true;
    }
    else if(x <= 2996 && x >=1606 && y <= -1267 && y >= -1487)
    {
        return true;
    }
    else if(x <= 2266 && y <= -437 && y >= -607)
    {
        return true;
    }
    else if(x <= 3016 && x >= 2376 && y <= -437 && y >= -607)
    {
        return true;
    }
    else if(x >= 1796 && y <= -2317)
    {
        return true;
    }
    else if(x <= 3400 & x >= 3252 & y <= -525 & y >= -567)
        return true;
    else if(x <= 3400 & x >= 3252 & y <= -669 & y >= -700)
        return true;
    else if(x <= 3400 & x >= 3252 & y <= -825 & y >= -850)
        return true;
    else if(x <= 3400 & x >= 3252 & y <= -973 & y >= -1000)
        return true;
    else
    {
        return false;
    }
}

bool Player::hitRightWall()
{
    if(x >= 1582 && x <= 2006 && y <= -1746)
    {
        return true;
    }
    else if(x >= 512 && x <= 712 && y >= -2233)
    {
        return true;
    }
    else if(x >= 1546 && x <= 1636 && y >= - 1746 && y <= -787)
    {
        return true;
    }
    else if(x >= 1546 && x <= 1636 && y >= -717)
    {
        return true;
    }
    else if(x >= 2926 && x <= 3006 && y >= -1367 && y <= -487)
    {
        return true;
    }
    else if(x >= 2376 && x <= 3006 && y >= -657 && y <= -437)
    {
        return true;
    }
    else if(x >= 3376)
    {
        return true;
    }
    else if (x >= 3248 & y <= -525 & y >= -605)
        return true;
     else if (x >= 3248 & y <= -669 & y >= -761)
        return true;
     else if (x >= 3248 & y <= -825 & y >= -905)
        return true;
     else if (x >= 3248 & y <= -973 & y >= -1061)
        return true;
    else
    {
        return false;
    }
}

void Player::setBarrierL(bool hitL)
{
    barrierL = hitL;
}

void Player::setBarrierU(bool hitU)
{
    barrierU = hitU;
}

void Player::setEnemySpawn(bool enemySpawn)
{
    this->enemySpawn = enemySpawn;
}

bool Player::getBarrierTrigger2()
{
    return barrierTrigger2;
}

void Player::setBarrierTrigger2(bool barrierTrigger2)
{
    this->barrierTrigger2 = barrierTrigger2;
}

void Player::setHealth(int HP)
{
    health = HP;
}

bool Player::getAlive()
{
    return alive;
}

void Player::setAlive(bool alive)
{
    this->alive = alive;
}
