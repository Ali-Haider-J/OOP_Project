#include "Room.h"
#include "TextureManager.h"

Room::Room()
{
    roomNo = 1;
    roomTex =  TextureManager::LoadTexture("Images/map_layout.png");
    this->x = 0;
    this->y = 0;
}

Room::~Room()
{


}

void Room::draw()
{

     SDL_RenderCopyEx(Game::renderer, roomTex, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);

}

void Room::Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target)
{
    x = tempRect.x;
    y = tempRect.y;


    srcRect.h = 1300;
    srcRect.w = 1800;
    srcRect.x = srcRect.y = 0;
    destRect.h = srcRect.h * tempRect.h;
    destRect.w = srcRect.w * tempRect.h;
    destRect.x = tempRect.x;
    destRect.y = tempRect.y;


}
