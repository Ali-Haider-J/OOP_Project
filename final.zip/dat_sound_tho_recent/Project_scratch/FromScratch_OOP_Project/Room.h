#pragma once
#include "Object.h"
#include "Game.h"

class Room : public Object
{
private:
    int roomNo;
public:
    Room();
    ~Room();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target);
    SDL_Texture* roomTex;

};
