#include "ScreenRender.h"

ScreenRender::ScreenRender()
{
    this->hit = false;
    this->x = 3000;
    this->y = 1800;
    indFrame = 0;
    Save =  TextureManager::LoadTexture("Images/noSave.png");
    Win =  TextureManager::LoadTexture("Images/ss.png");
    Lost = TextureManager::LoadTexture("Images/Lost.jpg");
    Exit = TextureManager::LoadTexture("Images/Win.jpg");
    noSave = win = lost = false;
    this->hitbox.x = x;
    this->hitbox.y = y;
    this->hitbox.w = 55;
    this->hitbox.h = 55;
    exit = false;
}

ScreenRender::~ScreenRender()
{

}


void ScreenRender::Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target)
{


        //Win
        //frame0
        spriteClips_Win.x = 0;
        spriteClips_Win.y = 0;
        spriteClips_Win.w = 1024;
        spriteClips_Win.h = 573;

        //NO_SAVE_STATE
        //frame0
        spriteClips_noSave.x = 0;
        spriteClips_noSave.y = 0;
        spriteClips_noSave.w = 400;
        spriteClips_noSave.h = 100;

        //Lost
        //frame0
        spriteClips_Lost.x = 0;
        spriteClips_Lost.y = 0;
        spriteClips_Lost.w = 848;
        spriteClips_Lost.h = 452;

        //PORTAL
        //frame0
        spriteClips_Portal[0].x = 0;
        spriteClips_Portal[0].y = 787;
        spriteClips_Portal[0].w = 50;
        spriteClips_Portal[0].h = 42;

        //frame 1
        spriteClips_Portal[1].x = 50;
        spriteClips_Portal[1].y = 787;
        spriteClips_Portal[1].w = 50;
        spriteClips_Portal[1].h = 42;

        //frame 2
        spriteClips_Portal[2].x = 100;
        spriteClips_Portal[2].y = 787;
        spriteClips_Portal[2].w = 50;
        spriteClips_Portal[2].h = 42;

        //frame 3
        spriteClips_Portal[3].x = 150;
        spriteClips_Portal[3].y = 787;
        spriteClips_Portal[3].w = 50;
        spriteClips_Portal[3].h = 42;

        //frame 4
        spriteClips_Portal[4].x = 200;
        spriteClips_Portal[4].y = 787;
        spriteClips_Portal[4].w = 50;
        spriteClips_Portal[4].h = 42;

        //frame 5
        spriteClips_Portal[5].x = 250;
        spriteClips_Portal[5].y = 787;
        spriteClips_Portal[5].w = 50;
        spriteClips_Portal[5].h = 42;

        //frame 6
        spriteClips_Portal[6].x = 300;
        spriteClips_Portal[6].y = 787;
        spriteClips_Portal[6].w = 50;
        spriteClips_Portal[6].h = 42;

        //frame 7
        spriteClips_Portal[7].x = 350;
        spriteClips_Portal[7].y = 787;
        spriteClips_Portal[7].w = 50;
        spriteClips_Portal[7].h = 42;

        //frame 8
        spriteClips_Portal[8].x = 400;
        spriteClips_Portal[8].y = 787;
        spriteClips_Portal[8].w = 50;
        spriteClips_Portal[8].h = 42;

        //frame9
        spriteClips_Portal[9].x = 0;
        spriteClips_Portal[9].y = 1955;
        spriteClips_Portal[9].w = 52;
        spriteClips_Portal[9].h = 55;


        //frame10
        spriteClips_Portal[10].x = 53;
        spriteClips_Portal[10].y = 1955;
        spriteClips_Portal[10].w = 52;
        spriteClips_Portal[10].h = 55;


        //frame11
        spriteClips_Portal[11].x = 106;
        spriteClips_Portal[11].y = 1955;
        spriteClips_Portal[11].w = 52;
        spriteClips_Portal[11].h = 55;


        //frame12
        spriteClips_Portal[12].x = 159;
        spriteClips_Portal[12].y = 1955;
        spriteClips_Portal[12].w = 52;
        spriteClips_Portal[12].h = 55;


        //frame13
        spriteClips_Portal[13].x = 212;
        spriteClips_Portal[13].y = 1955;
        spriteClips_Portal[13].w = 52;
        spriteClips_Portal[13].h = 55;


    if ((((hitbox.x + hitbox.w > Target.x + Target.w) & (hitbox.x < Target.x + Target.w)) or ((hitbox.x + hitbox.w < Target.x + Target.w) & (hitbox.x > Target.x)) or ((hitbox.x + hitbox.w < Target.x + Target.w) & (hitbox.x + hitbox.w > Target.x )))
    & (((hitbox.y + hitbox.h >= Target.y + Target.h) & (hitbox.y < Target.y + Target.h)) or ((hitbox.y + hitbox.h >= Target.y + Target.h) & (hitbox.y < Target.y)) or ((hitbox.y + hitbox.h <= Target.y + Target.h) & (hitbox.y + hitbox.h > Target.y ))))
    {
        this->hit = true;

    }


        if (win)
        {
            if (indFrame >= 13)
                srcRect = spriteClips_Portal[13];
            else
                srcRect = spriteClips_Portal[indFrame];


            destRect.h = srcRect.h * 2;
            destRect.w = srcRect.w * 2;
            destRect.x = x + tempRect.x;
            destRect.y = y + tempRect.y;


            this->hitbox.x = destRect.x;
            this->hitbox.y = destRect.y;
            this->hitbox.h = this->hitbox.w = 110;



        }
        else if (lost)
        {
            srcRect = spriteClips_Lost;
            destRect.w = srcRect.w * 1.2;
            destRect.h = srcRect.h * 1.2;
            destRect.x = 5;
            destRect.y = 100;
        }
        else if (noSave)
        {
            srcRect = spriteClips_noSave;
            destRect.w = srcRect.w * 2;
            destRect.h = srcRect.h * 2;
            destRect.x = 125;
            destRect.y = 250;
        }
        else if (exit)
        {
            srcRect = spriteClips_Win;
            destRect.w = srcRect.w * 1.3;
            destRect.h = srcRect.h * 1.3;
            destRect.x = 0;
            destRect.y = 10;
        }
        indFrame++;

}

void ScreenRender::draw()
{
    if (exit)
    {
        SDL_RenderCopyEx(Game::renderer, Exit, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);
    }
    else if (win)
    {
        SDL_RenderDrawRect( Game::renderer, &this->hitbox );

        SDL_RenderCopyEx(Game::renderer, Win, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);
    }
    else if (lost)
        SDL_RenderCopyEx(Game::renderer, Lost, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);

    else if (noSave)
        SDL_RenderCopyEx(Game::renderer, Save, &srcRect, &destRect, 0.0, NULL, SDL_FLIP_NONE);

    noSave = win = lost = false;

}

bool ScreenRender::getNoSave()
{
    return noSave;
}

bool ScreenRender::getWin()
{
    return win;
}

bool ScreenRender::getLost()
{
    return lost;
}

void ScreenRender::setWin(bool win)
{
    this->win = win;
}

void ScreenRender::setLost(bool lost)
{
    this->lost = lost;

}

void ScreenRender::setNoSave(bool save)
{
    this->noSave = save;
}

bool ScreenRender::getHit()
{
    return hit;
}

void ScreenRender::setExit(bool exit)
{
    this->exit = exit;
}
