#pragma once
#include "TextureManager.h"
#include "Object.h"

class ScreenRender : public Object
{
private:
    SDL_Texture* Save;
    SDL_Texture* Win;
    SDL_Texture* Lost;
    SDL_Texture* Exit;
    SDL_Rect spriteClips_noSave;
    SDL_Rect spriteClips_Win;
    SDL_Rect spriteClips_Lost;
    SDL_Rect spriteClips_Portal[14];
    int indFrame;
    bool noSave;
    bool win;
    bool lost;
    bool exit;
public:
    ScreenRender();
    ~ScreenRender();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target);
    bool getNoSave();
    bool getWin();
    bool getLost();
    void setWin(bool);
    void setLost(bool);
    void setNoSave(bool);
    bool getHit();
    void setExit(bool);
};
