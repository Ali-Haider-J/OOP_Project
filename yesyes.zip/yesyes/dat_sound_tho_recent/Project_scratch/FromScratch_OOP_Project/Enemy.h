#pragma once
#include "Unit.h"

class Enemy : public Unit
{
protected:
    bool hit;

public:
    Enemy();
    ~Enemy();
    virtual void draw();
    virtual void Update(long int frame, SDL_Rect tempRect, int, int, SDL_Rect Target);
    virtual void attack(int, int);

};
