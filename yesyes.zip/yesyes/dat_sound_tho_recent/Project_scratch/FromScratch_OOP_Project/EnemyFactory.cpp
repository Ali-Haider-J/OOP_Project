#include "EnemyFactory.h"

EnemyFactory::EnemyFactory()
{

}


EnemyFactory::~EnemyFactory()
{


}

Enemy* EnemyFactory::getEnemy(std::string type, int posx, int posy)
{
    if (type == "EnemyOne")
    {
        enemy = new EnemyOne(posx, posy);
        return enemy;
    }

    else if (type == "EnemyTwo")
    {
        enemy = new EnemyTwo(posx, posy);
        return enemy;
    }
    else if (type == "EnemyThree")
    {
        enemy = new EnemyThree(posx, posy);
        return enemy;
    }

    return NULL;
}
