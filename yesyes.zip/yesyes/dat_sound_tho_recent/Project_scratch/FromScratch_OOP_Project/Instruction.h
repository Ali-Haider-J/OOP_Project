#pragma once
#include "Object.h"
#include "TextureManager.h"

class Instruction : public Object
{
private:
    SDL_Texture* instructionTex;
    SDL_Texture* keysTex;
    SDL_Rect spriteClips[ 12 ];
    SDL_Rect spriteClips_down[ 12 ];
    SDL_Rect spriteClips_right[ 12 ];
    SDL_Rect spriteClips_left[ 12 ];
    SDL_Rect spriteClips_keys[ 1 ];
    SDL_Rect spriteClips_z_key[ 1 ];
    SDL_Rect spriteClips_x_key[ 1 ];
    SDL_Rect spriteClips_dodge_right[ 8 ];

    SDL_Rect keysSrcRect;
    SDL_Rect keysDestRect;
    SDL_Rect keyZSrcRect;
    SDL_Rect keyZDestRect;
    SDL_Rect keyXSrcRect;
    SDL_Rect keyXDestRect;
    SDL_Rect dodgeSrcRect;
    SDL_Rect dodgeDestRect;

    SDL_Rect attackSrcRect;
    SDL_Rect attackDestRect;
    SDL_Rect spriteClips_attack_right[7];
    SDL_Rect spriteClips_attack_right_alt[6];

    bool altAttack;
    int counter;

public:
    Instruction();
    ~Instruction();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int a, int b, SDL_Rect Target);


};
