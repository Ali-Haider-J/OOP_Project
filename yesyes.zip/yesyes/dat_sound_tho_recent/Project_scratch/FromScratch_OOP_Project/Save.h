#pragma once
#include "Object.h"

#include "TextureManager.h"
//#include "OperatorOverloading.h"
class Save : public Object
{


public:
    Save(int, int);
    Save();
    ~Save();
    void save();
    void draw();
    void Update(long int frame, SDL_Rect tempRect, int, int, SDL_Rect Target);
    SDL_Rect spriteClips_animation[22];
};
