#include "Unit.h"

Unit::Unit()
{

}

Unit::~Unit()
{

}

bool Unit::GetAlive()
{


}

void Unit::attack(int, int)
{


}
